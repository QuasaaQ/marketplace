// background.js – Module Worker

const DEFAULT_MANAGERS = ["Петров Владислав Владиславович"];
const DEFAULT_PAIRS = [
    "КЦЕ_НП_Е_Тула_ТКЦ1_ГБ",
    "АП_НП_П_Москва_ГПНК1_ГБ_УД"
];

const REPORT_URL_PATTERN = /https:\/\/report\.action\.group\/Reports\/report\/.*/;
const BADGE_ERROR_TIMEOUT = 3000;

let isRunning = false;
let stateResetTimer = null;   // для отмены таймера

function clearStateTimer() {
    if (stateResetTimer) {
        clearTimeout(stateResetTimer);
        stateResetTimer = null;
    }
}

function setRunningState(running) {
    if (running) {
        chrome.action.setBadgeText({ text: '⏳' });
        chrome.action.setBadgeBackgroundColor({ color: '#FF6600' });
        chrome.action.setTitle({ title: 'Выполняется...' });
    } else {
        chrome.action.setBadgeText({ text: '' });
        chrome.action.setTitle({ title: 'Запустить отчёт' });
    }
    isRunning = running;
}

// Слушаем сообщение из content.js о завершении работы
chrome.runtime.onMessage.addListener((msg, sender) => {
    if (msg.action === 'taskFinished') {
        console.log('Контент-скрипт завершил работу');
        clearStateTimer();
        setRunningState(false);
    }
});

chrome.action.onClicked.addListener(async (tab) => {
    if (isRunning) {
        console.log('Уже выполняется');
        return;
    }

    if (!tab.url.match(REPORT_URL_PATTERN)) {
        chrome.action.setBadgeText({ text: '!' });
        chrome.action.setBadgeBackgroundColor({ color: '#FF0000' });
        setTimeout(() => chrome.action.setBadgeText({ text: '' }), BADGE_ERROR_TIMEOUT);
        console.log('Не на странице отчёта');
        return;
    }

    setRunningState(true);

    try {
        const storage = await chrome.storage.sync.get(['managers', 'pairs']);
        const managers = storage.managers?.length ? storage.managers : DEFAULT_MANAGERS;
        const pairs    = storage.pairs?.length    ? storage.pairs    : DEFAULT_PAIRS;

        const startDate = getCurrentMonthFirstDay();
        console.log(`Установлена дата: ${startDate}`);

        // Отправляем команду в content.js
        await chrome.tabs.sendMessage(tab.id, {
            action: 'fillReport',
            config: { startDate, managers, pairs }
        });

        // Запускаем страховочный таймер (на случай, если content не ответит)
        clearStateTimer();
        stateResetTimer = setTimeout(() => {
            console.log('Таймер сброса: content не ответил вовремя');
            setRunningState(false);
            stateResetTimer = null;
        }, 30000);   // 30 секунд – дольше, чем любое нормальное выполнение

    } catch (err) {
        console.error(err);
        clearStateTimer();
        setRunningState(false);
        chrome.action.setBadgeText({ text: 'Err' });
        setTimeout(() => chrome.action.setBadgeText({ text: '' }), BADGE_ERROR_TIMEOUT);
    }
});

function getCurrentMonthFirstDay() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}-01`;
}