// background.js – Module Worker

let config = null;

// Функция загрузки конфига
async function loadConfig() {
    if (config) return config;
    
    try {
        if (typeof window !== 'undefined' && window.AppConfig) {
            config = window.AppConfig;
            return config;
        }
    } catch (e) {}
    
    return {
        defaultManagers: ["Петров Владислав Владиславович"],
        defaultPairs: [
            "КЦЕ_НП_Е_Тула_ТКЦ1_ГБ",
            "АП_НП_П_Москва_ГПНК1_ГБ_УД"
        ],
        extensionDelays: {
            afterTabReload: 1000,
            afterTabLoad: 1000,
            messageTimeout: 5000,
            taskTimeout: 60000,
            retryDelay: 1000,
            waitForLoadTimeout: 10000,
            waitForNewTabTimeout: 15000
        },
        retrySettings: {
            executeMaxRetries: 3,
            openMaxRetries: 2
        },
        reportUrl: "https://report.action.group/Reports/report/%D0%A2%D0%B5%D1%81%D1%82%D1%8B/%5B%D0%9C%D0%BE%D1%82%D0%B8%D0%B2%D0%B0%D1%86%D0%B8%D1%8F%5D%20%D0%A0%D0%B0%D1%81%D1%87%D0%B5%D1%82"
    };
}

const BADGE_ERROR_TIMEOUT = 3000;

let isRunning = false;
let stateResetTimer = null;

function clearStateTimer() {
    if (stateResetTimer) {
        clearTimeout(stateResetTimer);
        stateResetTimer = null;
    }
}

function setRunningState(running) {
    if (running) {
        chrome.action.setBadgeText({ text: '⏳' });
        chrome.action.setBadgeBackgroundColor({ color: '#FF6600' });
        chrome.action.setTitle({ title: 'Выполняется...' });
    } else {
        chrome.action.setBadgeText({ text: '' });
        chrome.action.setTitle({ title: 'Запустить отчёт' });
    }
    isRunning = running;
}

async function findReportTab() {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
        if (tab.url && tab.url.includes("report.action.group") && 
            (tab.url.includes("Мотивация") || tab.url.includes("%D0%9C%D0%BE%D1%82%D0%B8%D0%B2%D0%B0%D1%86%D0%B8%D1%8F"))) {
            return tab;
        }
        if (tab.title && tab.title.includes("Мотивация") && tab.title.includes("Расчет")) {
            return tab;
        }
    }
    return null;
}

async function waitForTabLoad(tabId, timeout) {
    const cfg = await loadConfig();
    const waitTimeout = timeout || cfg.extensionDelays.waitForLoadTimeout;
    
    return new Promise((resolve) => {
        let resolved = false;
        const listener = (id, changeInfo) => {
            if (id === tabId && changeInfo.status === 'complete') {
                if (!resolved) {
                    resolved = true;
                    chrome.tabs.onUpdated.removeListener(listener);
                    resolve();
                }
            }
        };
        chrome.tabs.onUpdated.addListener(listener);
        setTimeout(() => {
            if (!resolved) {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
            }
        }, waitTimeout);
    });
}

async function executeOnExistingTab(tab, retryCount = 0) {
    const cfg = await loadConfig();
    const maxRetries = cfg.retrySettings.executeMaxRetries;
    
    try {
        // Переключаемся на вкладку
        await chrome.tabs.update(tab.id, { active: true });
        
        // Обновляем существующую вкладку (только при первом запуске)
        if (retryCount === 0) {
            await chrome.tabs.reload(tab.id);
            await waitForTabLoad(tab.id, cfg.extensionDelays.waitForLoadTimeout);
            await new Promise(r => setTimeout(r, cfg.extensionDelays.afterTabReload));
        } else {
            await new Promise(r => setTimeout(r, cfg.extensionDelays.retryDelay));
        }
        
        // Получаем настройки из хранилища
        const storage = await chrome.storage.sync.get(['managers', 'pairs']);
        const managers = storage.managers?.length ? storage.managers : cfg.defaultManagers;
        const pairs = storage.pairs?.length ? storage.pairs : cfg.defaultPairs;
        const startDate = getCurrentMonthFirstDay();
        
        // Отправляем сообщение с таймаутом
        await Promise.race([
            chrome.tabs.sendMessage(tab.id, {
                action: 'fillReport',
                config: { startDate, managers, pairs }
            }),
            new Promise((_, reject) => setTimeout(() => reject(new Error('Таймаут отправки')), cfg.extensionDelays.messageTimeout))
        ]);
        
        clearStateTimer();
        stateResetTimer = setTimeout(() => {
            setRunningState(false);
            stateResetTimer = null;
        }, cfg.extensionDelays.taskTimeout);
        
    } catch (err) {
        console.log(`Ошибка (попытка ${retryCount + 1}/${maxRetries}):`, err.message);
        
        if (retryCount < maxRetries - 1) {
            await new Promise(r => setTimeout(r, cfg.extensionDelays.retryDelay));
            return executeOnExistingTab(tab, retryCount + 1);
        } else {
            throw err;
        }
    }
}

async function executeOnNewTab(tab, retryCount = 0) {
    const cfg = await loadConfig();
    const maxRetries = cfg.retrySettings.executeMaxRetries;
    
    try {
        // Новая вкладка уже свежая - НЕ обновляем её!
        
        // Получаем настройки из хранилища
        const storage = await chrome.storage.sync.get(['managers', 'pairs']);
        const managers = storage.managers?.length ? storage.managers : cfg.defaultManagers;
        const pairs = storage.pairs?.length ? storage.pairs : cfg.defaultPairs;
        const startDate = getCurrentMonthFirstDay();
        
        // Отправляем сообщение с таймаутом
        await Promise.race([
            chrome.tabs.sendMessage(tab.id, {
                action: 'fillReport',
                config: { startDate, managers, pairs }
            }),
            new Promise((_, reject) => setTimeout(() => reject(new Error('Таймаут отправки')), cfg.extensionDelays.messageTimeout))
        ]);
        
        clearStateTimer();
        stateResetTimer = setTimeout(() => {
            setRunningState(false);
            stateResetTimer = null;
        }, cfg.extensionDelays.taskTimeout);
        
    } catch (err) {
        console.log(`Ошибка на новой вкладке (попытка ${retryCount + 1}/${maxRetries}):`, err.message);
        
        if (retryCount < maxRetries - 1) {
            await new Promise(r => setTimeout(r, cfg.extensionDelays.retryDelay));
            return executeOnNewTab(tab, retryCount + 1);
        } else {
            throw err;
        }
    }
}

async function openAndExecute(retryCount = 0) {
    const cfg = await loadConfig();
    const maxRetries = cfg.retrySettings.openMaxRetries;
    
    try {
        // Открываем новую вкладку
        const tab = await chrome.tabs.create({ url: cfg.reportUrl, active: true });
        await waitForTabLoad(tab.id, cfg.extensionDelays.waitForNewTabTimeout);
        await new Promise(r => setTimeout(r, cfg.extensionDelays.afterTabLoad));
        
        // Запускаем выполнение на новой вкладке (без обновления)
        await executeOnNewTab(tab, 0);
        
    } catch (err) {
        console.log(`Ошибка открытия (попытка ${retryCount + 1}/${maxRetries}):`, err.message);
        
        if (retryCount < maxRetries - 1) {
            await new Promise(r => setTimeout(r, cfg.extensionDelays.retryDelay));
            return openAndExecute(retryCount + 1);
        } else {
            throw err;
        }
    }
}

chrome.runtime.onMessage.addListener((msg, sender) => {
    if (msg.action === 'taskFinished') {
        clearStateTimer();
        setRunningState(false);
    }
});

chrome.action.onClicked.addListener(async (tab) => {
    if (isRunning) return;
    
    setRunningState(true);
    
    try {
        let reportTab = await findReportTab();
        
        if (reportTab) {
            console.log('Вкладка найдена, обновляем и запускаем...');
            await executeOnExistingTab(reportTab, 0);
        } else {
            console.log('Вкладка не найдена, открываем новую...');
            await openAndExecute(0);
        }
    } catch (err) {
        console.error('Финальная ошибка:', err);
        setRunningState(false);
        chrome.action.setBadgeText({ text: 'Err' });
        setTimeout(() => chrome.action.setBadgeText({ text: '' }), BADGE_ERROR_TIMEOUT);
    }
});

function getCurrentMonthFirstDay() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}-01`;
}