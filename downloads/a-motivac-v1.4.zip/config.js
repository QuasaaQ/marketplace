// ==================================================
// КОНФИГУРАЦИЯ РАСШИРЕНИЯ
// ==================================================

window.AppConfig = {
    // Список подразделений по умолчанию (заполняется при первом открытии настроек)
    defaultPairs: [
        "КЦЕ_НП_Е_Тула_БИТ_Е",
        "КЦЕ_НП_Е_Тула_ТКЦ1_ГБ",
        "КЦЕ_НП_Е_Москва_ТКЦ1_ГБ",
        "КЦЕ_НП_Е_Краснодар_ТКЦ1_ГБ",
        "КЦЕ_НП_Е_Тула_ТКЦ2_БУХ",
        "КЦЕ_НП_Е_Тула_ТКЦ3_ФД",
        "КЦЕ_НП_Е_Тула_ТКЦ4_ГБ",
        "КЦЕ_НП_Е_Тула_ТКЦ5_ПР_КиHR",
        "КЦЕ_НП_Е_Тула_ТКЦ7_ГБ",
        "КЦЕ_НП_Е_Тула_ТКЦ8_БУХ"
    ],

    // Список руководителей направления по умолчанию
    defaultManagers: [
        "Петров Владислав Владиславович"
    ],

    // Селекторы полей
    selectors: {
        dateField: '#ReportViewerControl_ctl04_ctl07_txtValue',
        managerField: '#ReportViewerControl_ctl04_ctl03_txtValue',
        subdivisionField: '#ReportViewerControl_ctl04_ctl05_txtValue',
        userField: '#ReportViewerControl_ctl04_ctl15_ddValue',  // <-- ДОБАВЛЕНО
        submitButton: '#ReportViewerControl_ctl04_ctl00',
        closeMenuSelect: '#ReportViewerControl_ctl04_ctl17_ddValue'
    },

    // Задержки для работы с формой (в миллисекундах)
    delays: {
        afterDateEnter: 100,            // после ввода даты и нажатия Enter
        afterManagerFieldClick: 100,    // после клика по полю руководителя
        clickManagerLabel: 100,         // задержка после выбора руководителя
        closeMenuClick: 100,            // между кликами при закрытии меню
        afterSubdivOpen: 100,           // после открытия списка подразделений
        betweenSubdivClicks: 20,        // между выбором чекбоксов подразделений
        beforeSubmit: 100,              // перед кликом на кнопку "Просмотр"
        afterSubmit: 100,               // после клика на кнопку
        
        // ===== НОВЫЕ ЗАДЕРЖКИ ДЛЯ ПОЛЯ ПОЛЬЗОВАТЕЛЯ =====
        afterUserFieldClick: 100,       // после клика по полю пользователя (ожидание открытия списка)
        userItemSearchTimeout: 100,     // между попытками поиска пункта "Все"
        afterUserSelect: 100,           // после выбора пользователя
        closeUserMenu: 100,             // после закрытия меню пользователя
        userValueApplyCheck: 100,       // ожидание перед проверкой, что value=1 применился
        userRetryDelay: 1000            // пауза между ретраями выбора фильтра пользователя
        // ===============================================
    },

    // Задержки для работы расширения (в миллисекундах)
    extensionDelays: {
        afterTabReload: 1000,           // после перезагрузки вкладки
        afterTabLoad: 1000,             // после загрузки вкладки
        messageTimeout: 1000,           // таймаут отправки сообщения
        taskTimeout: 20000,             // общий таймаут выполнения задачи
        retryDelay: 1000,               // задержка между повторными попытками
        waitForLoadTimeout: 1000,       // таймаут ожидания загрузки вкладки
        waitForNewTabTimeout: 1000      // таймаут ожидания новой вкладки
    },

    // Настройки повторов
    retrySettings: {
        executeMaxRetries: 3,           // сколько раз повторять при ошибке выполнения
        openMaxRetries: 2               // сколько раз повторять при ошибке открытия
    },

    // URL отчёта
    reportUrl: "https://report.action.group/Reports/report/%D0%A2%D0%B5%D1%81%D1%82%D1%8B/%5B%D0%9C%D0%BE%D1%82%D0%B8%D0%B2%D0%B0%D1%86%D0%B8%D1%8F%5D%20%D0%A0%D0%B0%D1%81%D1%87%D0%B5%D1%82"
};