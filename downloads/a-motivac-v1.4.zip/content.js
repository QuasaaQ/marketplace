// content.js – финальная версия с закрытием через селект "Да/Нет"
window.addEventListener('load', async () => {
    console.log('Content script загружен, ищем iframe...');
    await waitForIframe();
    await runActions();
});

function waitForIframe() {
    return new Promise((resolve) => {
        const iframe = document.querySelector('iframe.viewer, iframe[title*="Средство просмотра отчетов"]');
        if (iframe?.contentDocument?.readyState === 'complete') {
            resolve(iframe);
            return;
        }
        const observer = new MutationObserver(() => {
            const iframe = document.querySelector('iframe.viewer, iframe[title*="Средство просмотра отчетов"]');
            if (iframe?.contentDocument?.readyState === 'complete') {
                observer.disconnect();
                resolve(iframe);
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'fillReport') {
        const { startDate, managers, pairs } = request.config;
        runActions(startDate, managers, pairs).catch(console.error);
    }
});

function getCurrentMonthFirstDay() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}-01`;
}

function setDateAndEnter(field, dateValue) {
    if (!field) return;
    const parts = dateValue.split('-');
    if (parts.length === 3) {
        const formatted = `${parts[2]}.${parts[1]}.${parts[0]}`;
        field.value = formatted;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        field.dispatchEvent(new KeyboardEvent('keypress', {
            key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
            bubbles: true, cancelable: true
        }));
        console.log(`Дата: ${formatted}`);
    }
}

function normalizeText(text) {
    if (!text) return '';
    return text.replace(/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g, ' ')
               .replace(/\s+/g, ' ')
               .trim();
}

// ========== ЗАКРЫТИЕ МЕНЮ ЧЕРЕЗ СЕЛЕКТ "ДА/НЕТ" ==========
async function closeMenu(doc, wait) {
    const cfg = window.AppConfig;
    // Ищем селект "Да/Нет"
    const yesNoSelect = doc.querySelector(cfg.selectors.closeMenuSelect);
    if (yesNoSelect) {
        yesNoSelect.click();
        console.log('   Кликнули по селекту "Да/Нет"');
        await wait(cfg.delays.closeMenuClick);
    }
    
    // Дополнительный клик по body
    doc.body.click();
    await wait(cfg.delays.closeMenuClick);
}

async function runActions(startDate, managers, pairs) {
    const finalManagers = managers || window.AppConfig.defaultManagers;
    const finalPairs = pairs || [
        "КЦЕ_НП_Е_Тула_ТКЦ1_ГБ",
        "АП_НП_П_Москва_ГПНК1_ГБ_УД"
    ];
    
    console.log('=== runActions ===');
    
    const mainIframe = await waitForIframe();
    const doc = mainIframe.contentDocument;
    if (!doc) return;
    
    const wait = ms => new Promise(r => setTimeout(r, ms));
    const cfg = window.AppConfig;
    
    // Дата
    const effectiveStartDate = startDate || getCurrentMonthFirstDay();
    const dateField = doc.querySelector(cfg.selectors.dateField);
    if (dateField) setDateAndEnter(dateField, effectiveStartDate);
    await wait(cfg.delays.afterDateEnter);
    
    // ========== РУКОВОДИТЕЛИ ==========
    const managerField = doc.querySelector(cfg.selectors.managerField);
    if (managerField) {
        console.log('1. Выбор руководителя...');
        managerField.click();
        await wait(cfg.delays.afterManagerFieldClick);
        
        const labels = doc.querySelectorAll('label');
        for (const label of labels) {
            if (normalizeText(label.innerText) === 'Петров Владислав Владиславович') {
                label.click();
                console.log('   ✓ Руководитель выбран');
                break;
            }
        }
        await wait(cfg.delays.clickManagerLabel);
        
        // Закрываем меню руководителей
        await closeMenu(doc, wait);
        console.log('   ✓ Меню руководителей закрыто');
    }
    
    // ========== ПОДРАЗДЕЛЕНИЯ ==========
    let subdivField = doc.querySelector(cfg.selectors.subdivisionField);
    if (!subdivField) {
        subdivField = doc.querySelector('[id*="ctl05_txtValue"]');
    }
    
    if (subdivField && finalPairs.length > 0) {
        console.log('2. Выбор подразделений...');
        
        let attempts = 0;
        while (subdivField.disabled && attempts < 20) {
            await wait(500);
            subdivField = doc.querySelector(`#${subdivField.id}`);
            attempts++;
        }
        
        if (!subdivField.disabled) {
            subdivField.click();
            await wait(cfg.delays.afterSubdivOpen);
            
            const allSpans = doc.querySelectorAll('span');
            for (const pairName of finalPairs) {
                for (const span of allSpans) {
                    if (span.innerText?.trim() === pairName) {
                        const td = span.closest('td');
                        const checkbox = td?.querySelector('input[type="checkbox"]');
                        if (checkbox && !checkbox.checked) {
                            checkbox.click();
                            console.log(`   ✓ ${pairName}`);
                            break;
                        }
                    }
                }
                await wait(cfg.delays.betweenSubdivClicks);
            }
            
            // Закрываем меню подразделений
            await closeMenu(doc, wait);
            console.log('   ✓ Меню подразделений закрыто');
        }
    }
    
    // Кнопка просмотра
    const submitBtn = doc.querySelector(cfg.selectors.submitButton);
    if (submitBtn) {
        await wait(cfg.delays.beforeSubmit);
        submitBtn.click();
        console.log('3. ✓ Отчет сформирован');
    }
    
    console.log('✅ ГОТОВО!');
	chrome.runtime.sendMessage({ action: 'taskFinished' }).catch(() => {});
}