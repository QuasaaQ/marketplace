// background.js – Module Worker

let config = null;

async function loadConfig() {
    if (config) return config;
    
    try {
        if (typeof window !== 'undefined' && window.AppConfig) {
            config = window.AppConfig;
            return config;
        }
    } catch (e) {}
    
    return {
        defaultPairs: [],
        extensionDelays: {
            afterTabReload: 1000,
            afterTabLoad: 1000,
            messageTimeout: 5000,
            retryDelay: 1000,
            waitForLoadTimeout: 10000,
            waitForNewTabTimeout: 15000
        },
        retrySettings: {
            executeMaxRetries: 3,
            openMaxRetries: 2
        },
        reportUrl: "https://report.action.group/Reports/report/%D0%90%D0%BD%D0%B0%D0%BB%D0%B8%D1%82%D0%B8%D0%BA%D0%B0%20%D0%94%D0%B8%D0%B4%D0%B6%D0%B8%D1%82%D0%B0%D0%BB/%D0%9A%D0%BE%D0%BB%D0%BB-%D1%86%D0%B5%D0%BD%D1%82%D1%80%D1%8B/%D0%9E%D0%BF%D0%BB%D0%B0%D1%87%D0%B5%D0%BD%D0%BD%D1%8B%D0%B5%20%D0%B7%D0%B0%D0%BA%D0%B0%D0%B7%D1%8B%20%D0%B7%D0%B0%20%D0%BF%D0%B5%D1%80%D0%B8%D0%BE%D0%B4"
    };
}

const BADGE_ERROR_TIMEOUT = 3000;

let isRunning = false;

function setRunningState(running) {
    if (running) {
        chrome.action.setBadgeText({ text: '⏳' });
        chrome.action.setBadgeBackgroundColor({ color: '#FF6600' });
        chrome.action.setTitle({ title: 'Выполняется...' });
    } else {
        chrome.action.setBadgeText({ text: '' });
        chrome.action.setTitle({ title: 'Запустить отчёт' });
    }
    isRunning = running;
}

async function findReportTab() {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
        if (tab.url && tab.url.includes("report.action.group") && 
            (tab.url.includes("Оплаченные%20заказы") || 
             tab.url.includes("Оплаченные заказы") ||
             tab.title.includes("Оплаченные заказы"))) {
            return tab;
        }
    }
    return null;
}

async function waitForTabLoad(tabId, timeout) {
    const cfg = await loadConfig();
    const waitTimeout = timeout || cfg.extensionDelays.waitForLoadTimeout;
    
    return new Promise((resolve) => {
        let resolved = false;
        const listener = (id, changeInfo) => {
            if (id === tabId && changeInfo.status === 'complete') {
                if (!resolved) {
                    resolved = true;
                    chrome.tabs.onUpdated.removeListener(listener);
                    resolve();
                }
            }
        };
        chrome.tabs.onUpdated.addListener(listener);
        setTimeout(() => {
            if (!resolved) {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
            }
        }, waitTimeout);
    });
}

async function executeOnExistingTab(tab, retryCount = 0) {
    const cfg = await loadConfig();
    const maxRetries = cfg.retrySettings.executeMaxRetries;
    
    try {
        await chrome.tabs.update(tab.id, { active: true });
        
        if (retryCount === 0) {
            await chrome.tabs.reload(tab.id);
            await waitForTabLoad(tab.id, cfg.extensionDelays.waitForLoadTimeout);
            await new Promise(r => setTimeout(r, cfg.extensionDelays.afterTabReload));
        } else {
            await new Promise(r => setTimeout(r, cfg.extensionDelays.retryDelay));
        }
        
        const storage = await chrome.storage.sync.get(['autoDates', 'startDate', 'endDate', 'pairs']);
        const pairs = storage.pairs?.length ? storage.pairs : cfg.defaultPairs;
        
        let startDate, endDate;
        const autoDates = storage.autoDates !== undefined ? storage.autoDates : true;
        
        if (autoDates) {
            startDate = getPreviousWorkday();
            endDate = calculateEndDate(startDate);
        } else {
            startDate = storage.startDate;
            endDate = storage.endDate;
        }
        
        if (!pairs || pairs.length === 0) {
            throw new Error("Список подразделений пуст");
        }
        
        await Promise.race([
            chrome.tabs.sendMessage(tab.id, {
                action: 'fillReport',
                config: { startDate, endDate, pairs }
            }),
            new Promise((_, reject) => setTimeout(() => reject(new Error('Таймаут отправки')), cfg.extensionDelays.messageTimeout))
        ]);
        
        // Не ставим таймер - ждём taskFinished от content.js
        
    } catch (err) {
        console.log(`Ошибка (попытка ${retryCount + 1}/${maxRetries}):`, err.message);
        
        if (retryCount < maxRetries - 1) {
            await new Promise(r => setTimeout(r, cfg.extensionDelays.retryDelay));
            return executeOnExistingTab(tab, retryCount + 1);
        } else {
            throw err;
        }
    }
}

async function executeOnNewTab(tab, retryCount = 0) {
    const cfg = await loadConfig();
    const maxRetries = cfg.retrySettings.executeMaxRetries;
    
    try {
        const storage = await chrome.storage.sync.get(['autoDates', 'startDate', 'endDate', 'pairs']);
        const pairs = storage.pairs?.length ? storage.pairs : cfg.defaultPairs;
        
        let startDate, endDate;
        const autoDates = storage.autoDates !== undefined ? storage.autoDates : true;
        
        if (autoDates) {
            startDate = getPreviousWorkday();
            endDate = calculateEndDate(startDate);
        } else {
            startDate = storage.startDate;
            endDate = storage.endDate;
        }
        
        if (!pairs || pairs.length === 0) {
            throw new Error("Список подразделений пуст");
        }
        
        await Promise.race([
            chrome.tabs.sendMessage(tab.id, {
                action: 'fillReport',
                config: { startDate, endDate, pairs }
            }),
            new Promise((_, reject) => setTimeout(() => reject(new Error('Таймаут отправки')), cfg.extensionDelays.messageTimeout))
        ]);
        
        // Не ставим таймер - ждём taskFinished от content.js
        
    } catch (err) {
        console.log(`Ошибка на новой вкладке (попытка ${retryCount + 1}/${maxRetries}):`, err.message);
        
        if (retryCount < maxRetries - 1) {
            await new Promise(r => setTimeout(r, cfg.extensionDelays.retryDelay));
            return executeOnNewTab(tab, retryCount + 1);
        } else {
            throw err;
        }
    }
}

async function openAndExecute(retryCount = 0) {
    const cfg = await loadConfig();
    const maxRetries = cfg.retrySettings.openMaxRetries;
    
    try {
        const tab = await chrome.tabs.create({ url: cfg.reportUrl, active: true });
        await waitForTabLoad(tab.id, cfg.extensionDelays.waitForNewTabTimeout);
        await new Promise(r => setTimeout(r, cfg.extensionDelays.afterTabLoad));
        await executeOnNewTab(tab, 0);
        
    } catch (err) {
        console.log(`Ошибка открытия (попытка ${retryCount + 1}/${maxRetries}):`, err.message);
        
        if (retryCount < maxRetries - 1) {
            await new Promise(r => setTimeout(r, cfg.extensionDelays.retryDelay));
            return openAndExecute(retryCount + 1);
        } else {
            throw err;
        }
    }
}

chrome.runtime.onMessage.addListener((msg, sender) => {
    if (msg.action === 'taskFinished') {
        console.log('✅ Получен сигнал о завершении работы');
        setRunningState(false);
    }
});

chrome.action.onClicked.addListener(async (tab) => {
    if (isRunning) {
        console.log('Уже выполняется');
        return;
    }
    
    setRunningState(true);
    
    try {
        const storage = await chrome.storage.sync.get(['pairs']);
        if (!storage.pairs || storage.pairs.length === 0) {
            console.log('Список подразделений пуст, открываем настройки');
            chrome.runtime.openOptionsPage();
            setRunningState(false);
            return;
        }
        
        let reportTab = await findReportTab();
        
        if (reportTab) {
            console.log('Вкладка найдена, обновляем и запускаем...');
            await executeOnExistingTab(reportTab, 0);
        } else {
            console.log('Вкладка не найдена, открываем новую...');
            await openAndExecute(0);
        }
    } catch (err) {
        console.error('Финальная ошибка:', err);
        setRunningState(false);
        chrome.action.setBadgeText({ text: 'Err' });
        setTimeout(() => chrome.action.setBadgeText({ text: '' }), BADGE_ERROR_TIMEOUT);
    }
});

function getPreviousWorkday() {
    const today = new Date();
    let day = today.getDay();
    let offset = 1;
    if (day === 1) offset = 3;
    if (day === 0) offset = 2;
    if (day === 6) offset = 1;
    const prev = new Date(today);
    prev.setDate(today.getDate() - offset);
    while (prev.getDay() === 0 || prev.getDay() === 6) {
        prev.setDate(prev.getDate() - 1);
    }
    return prev.toISOString().split('T')[0];
}

function calculateEndDate(startDateStr) {
    const start = new Date(startDateStr);
    if (start.getDay() === 5) {
        const end = new Date(start);
        end.setDate(start.getDate() + 2);
        return end.toISOString().split('T')[0];
    }
    return startDateStr;
}