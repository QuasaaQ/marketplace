// ============================================================================
// 1. Ожидание основного iframe отчёта
// ============================================================================
window.addEventListener('load', async () => {
    console.log('Content script загружен, ищем iframe...');
    await waitForIframe();
});

function waitForIframe() {
    return new Promise((resolve) => {
        const iframe = document.querySelector('iframe.viewer, iframe[title*="Средство просмотра отчетов"]');
        if (iframe && iframe.contentDocument && iframe.contentDocument.readyState === 'complete') {
            console.log('Iframe уже загружен');
            resolve(iframe);
            return;
        }
        const observer = new MutationObserver(() => {
            const iframe = document.querySelector('iframe.viewer, iframe[title*="Средство просмотра отчетов"]');
            if (iframe && iframe.contentDocument && iframe.contentDocument.readyState === 'complete') {
                observer.disconnect();
                resolve(iframe);
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
        const existing = document.querySelector('iframe.viewer, iframe[title*="Средство просмотра отчетов"]');
        if (existing && existing.contentDocument) {
            if (existing.contentDocument.readyState === 'complete') resolve(existing);
            else existing.addEventListener('load', () => resolve(existing));
        }
    });
}

// ============================================================================
// 2. Обработчик сообщений от попапа/background
// ============================================================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'fillReport') {
        const { startDate, endDate, pairs } = request.config;
        runActions(startDate, endDate, pairs).catch(console.error);
    }
});

// ============================================================================
// 3. Установка даты (ДД.ММ.ГГГГ + Enter)
// ============================================================================
function setDateAndEnter(field, dateValue) {
    if (!field) return false;
    const parts = dateValue.split('-');
    if (parts.length === 3) {
        const formatted = `${parts[2]}.${parts[1]}.${parts[0]}`;
        field.value = formatted;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        const enterEvent = new KeyboardEvent('keypress', {
            key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
            bubbles: true, cancelable: true
        });
        field.dispatchEvent(enterEvent);
        console.log(`Дата: ${formatted} + Enter`);
        return true;
    }
    return false;
}

// ============================================================================
// 4. Ожидание элемента по точному тексту
// ============================================================================
async function waitForElementByText(doc, text, timeout = 5000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
        const elements = Array.from(doc.querySelectorAll('label, span, div, a'));
        const found = elements.find(el => el.innerText && el.innerText.trim() === text);
        if (found) return found;
        await new Promise(r => setTimeout(r, 200));
    }
    return null;
}

// ============================================================================
// 5. Основная функция
// ============================================================================
async function runActions(startDate, endDate, pairs) {
    const mainIframe = await waitForIframe();
    const doc = mainIframe.contentDocument;
    if (!doc) {
        console.error('Нет доступа к iframe отчёта');
        chrome.runtime.sendMessage({ action: 'taskFinished' }).catch(() => {});
        return;
    }

    // Задержки из конфига (если нет – значения по умолчанию)
    const d = (window.AppConfig && window.AppConfig.delays) ? window.AppConfig.delays : {};
    const delays = {
        afterDateStart: d.afterDateStart || 500,
        afterDateEnd: d.afterDateEnd || 800,
        afterSubdivOpen: d.afterSubdivOpen || 1000,
        betweenSubdivClicks: d.betweenSubdivClicks || 200,
        afterSubdivClose: d.afterSubdivClose || 1000,
        afterOpsOpen: d.afterOpsOpen || 1000,
        afterOpsSelect: d.afterOpsSelect || 500,
        afterOpsClose: d.afterOpsClose || 500,
        afterFinalSubmit: d.afterFinalSubmit || 1000
    };

    const wait = ms => new Promise(r => setTimeout(r, ms));

    try {
        // ---------- 5.1. Дата С ----------
        const startField = doc.querySelector('#ReportViewerControl_ctl04_ctl03_txtValue');
        if (startField) setDateAndEnter(startField, startDate);
        else console.warn('Поле даты С не найдено');
        await wait(delays.afterDateStart);

        // ---------- 5.2. Дата ПО ----------
        const endField = doc.querySelector('#ReportViewerControl_ctl04_ctl05_txtValue');
        if (endField) setDateAndEnter(endField, endDate);
        else console.warn('Поле даты ПО не найдено');
        await wait(delays.afterDateEnd);

        // ---------- 5.3. Подразделения ----------
        const subdivCombo = doc.querySelector('#ReportViewerControl_ctl04_ctl07_txtValue');
        if (subdivCombo) {
            subdivCombo.click();
            console.log('Открыт список подразделений');
            await wait(delays.afterSubdivOpen);

            for (const name of pairs) {
                const target = Array.from(doc.querySelectorAll('label')).find(lbl => lbl.innerText.trim() === name);
                if (target) {
                    target.click();
                    console.log(`Выбрано: ${name}`);
                } else {
                    console.warn(`Не найдено: ${name}`);
                }
                await wait(delays.betweenSubdivClicks);
            }

            // Закрыть список подразделений
            if (startField) {
                startField.click();
                console.log('Клик по полю даты С – список подразделений закрыт');
            } else {
                const enterEvent = new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true });
                subdivCombo.dispatchEvent(enterEvent);
                console.log('Enter на поле подразделений');
            }
            await wait(delays.afterSubdivClose);
        } else {
            console.warn('Поле подразделений не найдено');
        }

        // ---------- 5.4. Операторы ----------
        const opsButton = doc.querySelector('#ReportViewerControl_ctl04_ctl09_ctl01');
        if (!opsButton) {
            console.warn('Кнопка операторов не найдена');
        } else {
            opsButton.click();
            console.log('Клик по кнопке операторов (открываем список)');
            await wait(delays.afterOpsOpen);

            let selectAll = await waitForElementByText(doc, '(Выделить все)', 5000);
            if (!selectAll) {
                const opsIframe = doc.querySelector('#ReportViewerControl_ctl04_ctl09_ctl02');
                if (opsIframe && opsIframe.contentDocument) {
                    selectAll = await waitForElementByText(opsIframe.contentDocument, '(Выделить все)', 2000);
                }
            }
            if (selectAll) {
                let clickable = selectAll;
                if (clickable.children.length > 0) clickable = clickable.children[0];
                ['mousedown', 'mouseup', 'click'].forEach(eventType => {
                    const event = new MouseEvent(eventType, { bubbles: true, cancelable: true, view: doc.defaultView });
                    clickable.dispatchEvent(event);
                });
                const forAttr = selectAll.getAttribute('for');
                if (forAttr) {
                    const linkedInput = doc.getElementById(forAttr);
                    if (linkedInput) {
                        ['mousedown', 'mouseup', 'click'].forEach(eventType => {
                            const event = new MouseEvent(eventType, { bubbles: true, cancelable: true, view: doc.defaultView });
                            linkedInput.dispatchEvent(event);
                        });
                        console.log('✅ Дополнительный клик по связанному элементу');
                    }
                }
                console.log('✅ Нажат (Выделить все)');
            } else {
                console.warn('❌ (Выделить все) не найден');
            }
            await wait(delays.afterOpsSelect);

            // Закрыть список операторов
            opsButton.click();
            console.log('Список операторов закрыт');
            await wait(delays.afterOpsClose);
        }

        // ---------- 5.5. Кнопка "Просмотр отчета" ----------
        const submitBtn = doc.querySelector('#ReportViewerControl_ctl04_ctl00');
        if (submitBtn) {
            submitBtn.click();
            console.log('Нажата кнопка "Просмотр отчета"');
        } else {
            console.warn('Кнопка "Просмотр отчета" не найдена');
        }
        
        await wait(delays.afterFinalSubmit);
        
        console.log('✅ Готово. Отчёт обновлён и отправлен.');
        
        // ========== ВАЖНО: Отправляем сигнал о завершении ==========
        chrome.runtime.sendMessage({ action: 'taskFinished' }).catch(() => {});
        console.log('📤 Отправлен сигнал taskFinished в background');
        
    } catch (err) {
        console.error('Ошибка:', err);
        // Даже при ошибке отправляем сигнал, чтобы снять блокировку
        chrome.runtime.sendMessage({ action: 'taskFinished' }).catch(() => {});
    }
}