// ============================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ ДАТ (ЛОКАЛЬНЫЕ, БЕЗ UTC)
// ============================================================
function formatLocalDate(date) {
    let year = date.getFullYear();
    let month = String(date.getMonth() + 1).padStart(2, '0');
    let day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Получить предыдущий рабочий день (пн-пт) от заданной даты
function getPreviousWorkdayFromDate(date) {
    let d = new Date(date);
    d.setHours(12, 0, 0, 0);
    let day = d.getDay();
    let offset = 1;
    if (day === 0) offset = 2;      // вс -> пт
    else if (day === 1) offset = 3; // пн -> пт
    else if (day === 6) offset = 1; // сб -> пт
    d.setDate(d.getDate() - offset);
    // Дополнительная защита: если всё ещё выходной (суббота/воскресенье)
    while (d.getDay() === 0 || d.getDay() === 6) {
        d.setDate(d.getDate() - 1);
    }
    return d;
}

// Получить предыдущий рабочий день от текущей даты (локально)
function getPreviousWorkday() {
    const today = new Date();
    today.setHours(12, 0, 0, 0);
    const workday = getPreviousWorkdayFromDate(today);
    return formatLocalDate(workday);
}

// Рассчитать дату ПО: если С пятница → С+2 дня (воскресенье), иначе С
function calculateEndDate(startDateStr) {
    const [year, month, day] = startDateStr.split('-').map(Number);
    const start = new Date(year, month - 1, day, 12, 0, 0);
    if (start.getDay() === 5) {
        start.setDate(start.getDate() + 2);
    }
    return formatLocalDate(start);
}

// ============================================================
// ЗАПОЛНЕНИЕ ПОПАПА ПРИ ЗАГРУЗКЕ
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    let defaultStart = getPreviousWorkday();
    
    // Проверка: если вдруг дата С суббота или воскресенье (ошибка) – исправляем
    let startDateObj = new Date(defaultStart + 'T12:00:00');
    let startDay = startDateObj.getDay();
    if (startDay === 0 || startDay === 6) {
        // Берём пятницу (если суббота – вычесть 1, если воскресенье – вычесть 2)
        let correction = (startDay === 0) ? 2 : 1;
        startDateObj.setDate(startDateObj.getDate() - correction);
        defaultStart = formatLocalDate(startDateObj);
        console.log('Скорректирована дата С (был выходной):', defaultStart);
    }
    
    let defaultEnd = calculateEndDate(defaultStart);
    
    document.getElementById('startDate').value = defaultStart;
    document.getElementById('endDate').value = defaultEnd;
    
    console.log(`Дата С: ${defaultStart} (день недели: ${new Date(defaultStart + 'T12:00:00').getDay()})`);
    console.log(`Дата ПО: ${defaultEnd} (день недели: ${new Date(defaultEnd + 'T12:00:00').getDay()})`);
    
    // Заполняем список подразделений из конфига
    if (window.AppConfig && window.AppConfig.defaultPairs) {
        document.getElementById('pairsList').value = window.AppConfig.defaultPairs.join('\n');
    }
});

// ============================================================
// ОБРАБОТЧИК КНОПКИ "Применить"
// ============================================================
document.getElementById('runBtn').addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    let startDate = document.getElementById('startDate').value;
    let endDate = document.getElementById('endDate').value;
    const pairsText = document.getElementById('pairsList').value;
    const pairs = pairsText.split(/\r?\n/).filter(s => s.trim().length > 0);
    
    if (!startDate || !endDate) {
        alert('Укажите обе даты');
        return;
    }
    if (pairs.length === 0) {
        alert('Укажите хотя бы одно подразделение');
        return;
    }
    
    // Проверка: дата С не должна быть субботой или воскресеньем
    const startDay = new Date(startDate + 'T12:00:00').getDay();
    if (startDay === 0 || startDay === 6) {
        alert('❌ Дата С не может быть субботой или воскресеньем. Пожалуйста, выберите рабочий день.');
        return;
    }
    
    // Проверка правила для пятницы
    if (startDay === 5) {
        const computedEnd = calculateEndDate(startDate);
        if (computedEnd !== endDate) {
            console.warn(`Дата ПО не соответствует правилу пятницы. Установлено ${endDate}, должно быть ${computedEnd}. Автоматически исправлено.`);
            endDate = computedEnd;
            document.getElementById('endDate').value = computedEnd;
        }
    }
    
    chrome.tabs.sendMessage(tab.id, {
        action: 'fillReport',
        config: { startDate, endDate, pairs }
    });
});