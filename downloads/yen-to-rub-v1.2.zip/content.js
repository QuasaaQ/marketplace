(() => {
  'use strict';

  const RATE_KEY = 'yenToRubRate';
  const MARKER_ATTR = 'data-yen-to-rub';
  const DEFAULT_RATE = 12.0;

  let rate = DEFAULT_RATE;

  const fmtRub = (value) => {
    try {
      return new Intl.NumberFormat('ru-RU', {
        style: 'currency',
        currency: 'RUB',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(value);
    } catch {
      return '₽' + value.toFixed(2).replace('.', ',');
    }
  };

  const parseYen = (text) => {
    if (!text) return null;
    let m = text.match(/¥\s*([\d\s.,]+)/);
    if (!m) m = text.match(/([\d\s.,]+)\s*¥/);
    if (!m) return null;
    const num = parseFloat(m[1].replace(/[\s,]/g, ''));
    return Number.isFinite(num) && num > 0 ? num : null;
  };

  const convert = () => {
    const nodes = document.querySelectorAll('span[data-usage-layout-font="value"]');
    for (const el of nodes) {
      if (el.hasAttribute(MARKER_ATTR)) continue;

      const yen = parseYen(el.textContent);
      if (yen === null) continue;

      // Находим контейнер с единицей измерения (CNY), чтобы вставить цену справа
      const unit = el.parentElement
        ? el.parentElement.querySelector('[data-usage-layout-font="unit"]')
        : null;
      const anchor = unit || el;

      const price = document.createElement('span');
      price.className = 'yen-to-rub-price';
      price.setAttribute(MARKER_ATTR, '1');
      price.textContent = fmtRub(yen * rate);
      anchor.insertAdjacentElement('afterend', price);

      el.setAttribute(MARKER_ATTR, '1');
    }
  };

  const reset = () => {
    document.querySelectorAll('.yen-to-rub-price').forEach((e) => e.remove());
    document.querySelectorAll(`[${MARKER_ATTR}]`).forEach((e) => e.removeAttribute(MARKER_ATTR));
    convert();
  };

  const style = document.createElement('style');
  style.textContent = `
    .yen-to-rub-price {
      margin-left: 6px;
      color: #9b1c1c;
      font-weight: 500;
      white-space: nowrap;
    }
  `;
  document.head.appendChild(style);

  const observer = new MutationObserver(() => convert());
  observer.observe(document.body, { childList: true, subtree: true });

  const init = async () => {
    const data = await chrome.storage.sync.get(RATE_KEY);
    const v = parseFloat(data[RATE_KEY]);
    if (Number.isFinite(v) && v > 0) rate = v;
    convert();
  };

  init();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes[RATE_KEY]) {
      const v = parseFloat(changes[RATE_KEY].newValue);
      if (Number.isFinite(v) && v > 0) rate = v;
      reset();
    }
  });
})();
