'use strict';

const RATE_KEY = 'yenToRubRate';
const DEFAULT_RATE = 12.0;

const rateInput = document.getElementById('rate');
const statusEl = document.getElementById('status');
const saveBtn = document.getElementById('save');
const openOptionsBtn = document.getElementById('open-options');

const load = async () => {
  const data = await chrome.storage.sync.get(RATE_KEY);
  const v = parseFloat(data[RATE_KEY]);
  rateInput.value = Number.isFinite(v) && v > 0 ? v : DEFAULT_RATE;
};

const showStatus = (text, ok) => {
  statusEl.textContent = text;
  statusEl.className = 'status ' + (ok ? 'ok' : 'error');
};

saveBtn.addEventListener('click', async () => {
  const raw = rateInput.value.trim().replace(',', '.');
  const v = parseFloat(raw);

  if (!Number.isFinite(v) || v <= 0) {
    showStatus('Введите корректное положительное число', false);
    return;
  }

  await chrome.storage.sync.set({ [RATE_KEY]: v });
  showStatus('Сохранено ✓', true);

  setTimeout(() => {
    statusEl.textContent = '';
    statusEl.className = 'status';
  }, 2000);
});

rateInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') saveBtn.click();
});

openOptionsBtn.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

load();
