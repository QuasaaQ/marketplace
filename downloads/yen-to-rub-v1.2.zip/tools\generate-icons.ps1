# Генерирует PNG-иконки расширения (чёрная ¥ на белом фоне) для размеров 16/32/48/128.
# Контур символа ¥ берётся из app/icons/icon.svg (viewBox 0 0 16 16) и рисуется
# через GraphicsPath.AddPolygon — точная копия, без шрифтов и кодировки.
# Рендер выполняется с 4x суперсэмплингом для гладких краёв.
# Запуск из папки app/:
#   powershell -ExecutionPolicy Bypass -File tools/generate-icons.ps1

Add-Type -AssemblyName System.Drawing

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$iconsDir = Join-Path (Split-Path -Parent $scriptDir) 'icons'
New-Item -ItemType Directory -Force -Path $iconsDir | Out-Null

$sizes = @(16, 32, 48, 128)
$supersample = 4

# Точки контура символа ¥ из icon.svg (координаты viewBox 0 0 16 16)
$points = @(
    @(0.850708, 0),
    @(5.05071, 7),
    @(3, 7),
    @(3, 9),
    @(6.50001, 9),
    @(6.50001, 11),
    @(3, 11),
    @(3, 13),
    @(6.50001, 13),
    @(6.50001, 16),
    @(9.50001, 16),
    @(9.50001, 13),
    @(13, 13),
    @(13, 11),
    @(9.50001, 11),
    @(9.50001, 9),
    @(13, 9),
    @(13, 7),
    @(10.9493, 7),
    @(15.1493, 0),
    @(11.6507, 0),
    @(7.99999, 6.08452),
    @(4.34928, 0),
    @(0.850708, 0)
)

foreach ($size in $sizes) {
    $big = $size * $supersample

    # Рисуем в большом разрешении
    $bigBmp = New-Object System.Drawing.Bitmap($big, $big)
    $g = [System.Drawing.Graphics]::FromImage($bigBmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.Clear([System.Drawing.Color]::White)

    $k = $big / 16.0
    $pts = New-Object 'System.Drawing.PointF[]' ($points.Count)
    for ($i = 0; $i -lt $points.Count; $i++) {
        $pts[$i] = New-Object System.Drawing.PointF(
            ([float]($points[$i][0] * $k)),
            ([float]($points[$i][1] * $k))
        )
    }

    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddPolygon($pts)
    $g.FillPath([System.Drawing.Brushes]::Black, $path)

    # Уменьшаем до целевого размера
    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g2 = [System.Drawing.Graphics]::FromImage($bmp)
    $g2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBilinear
    $g2.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g2.DrawImage($bigBmp, 0, 0, $size, $size)

    $pngPath = Join-Path $iconsDir "icon$size.png"
    $bmp.Save($pngPath, [System.Drawing.Imaging.ImageFormat]::Png)

    $path.Dispose()
    $g2.Dispose()
    $bmp.Dispose()
    $g.Dispose()
    $bigBmp.Dispose()
    Write-Host "Saved: $pngPath"
}

Write-Host 'Done.'
