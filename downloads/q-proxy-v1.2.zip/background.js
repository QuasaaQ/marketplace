/**
 * Q.Proxy - service worker.
 *
 * Задачи:
 *  - держать PAC-скрипт: сайты из списка - через прокси, остальные - напрямую;
 *  - автоматически тестировать прокси из списка в фоне (не нагружая ПК);
 *  - выбирать лучший рабочий прокси;
 *  - реагировать на изменения настроек.
 */

importScripts('shared/logger.js');
importScripts('shared/storage.js');

// Защитный fallback, если logger.js не загрузился.
const log =
  self.QProxyLog ||
  {
    debug() {},
    info() {},
    warn() {},
    error() {},
  };

log.info('background: service worker запущен');

if (!self.QProxyStorage) {
  log.error('background: QProxyStorage не найден - storage.js не загрузился');
}

const {
  getProxies,
  setProxies,
  getProxiedSites,
  setProxiedSites,
  getProxySources,
  setProxySources,
  getSettings,
  setSettings,
  getActiveProxy,
  setActiveProxy,
  getProxyStats,
  setProxyStats,
  normalizeDomain,
  domainMatches,
  isProxied,
  formatProxyString,
  parseProxyList,
  dedupeProxies,
  passesCountryFilter,
  getFilterCountry,
  collectCountries,
  generateProxyId,
  TEST_TARGETS,
  GEOIP_SERVICES,
  IP_ECHO_SERVICES,
} = self.QProxyStorage;

const ALARM_TEST_PROXIES = 'qproxy-test-proxies';
const ALARM_FETCH_SOURCES = 'qproxy-fetch-sources';

// Прогресс проверки прокси (для UI). alive - только полностью рабочие прокси,
// limited - живые, но с неоткрывшимся тестовым сайтом, dead - недоступные.
let checkProgress = { total: 0, done: 0, running: false, alive: 0, limited: 0, dead: 0 };

// Доступ к приватным окнам: 'unknown' | 'allowed' | 'denied'. Страница
// настроек показывает подсказку, когда расширение не разрешено в инкогнито.
let incognitoState = 'unknown';

// ID прокси, которые проверяются прямо сейчас (для статуса «проверка…»).
const checkingIds = new Set();

// ID прокси, которые стоят в очереди (для статуса «в очереди»).
const queuedIds = new Set();

// Флаг остановки проверки.
let testAborted = false;

// Идёт ли проверка сейчас. Второй запуск поверх первого не допускается: иначе
// фоновый запуск (таймер или импорт источников) сбрасывает флаг остановки и
// нажатие «Остановить» теряется, а прогресс показывает чужие цифры.
let testInProgress = false;

// Контроллер отмены текущей проверки: по «Остановить» обрываем уже начатые
// запросы, не дожидаясь таймаута.
let testAbortController = null;

// ---------------------------------------------------------------------------
// PAC-скрипт
// ---------------------------------------------------------------------------

/**
 * Экранирует строку для безопасной вставки в JS-код PAC.
 * @param {string} value
 * @returns {string}
 */
function jsString(value) {
  return JSON.stringify(String(value));
}

/**
 * Преобразует прокси в формат, понятный PAC-скрипту.
 *
 * PAC не понимает URL-схемы вида `socks5://host:port`. Он ожидает одну из
 * строк: `PROXY host:port`, `SOCKS host:port`, `SOCKS5 host:port`,
 * `HTTPS host:port`.
 *
 * Протокол берётся из общего переключателя настроек (`proxyProtocol`),
 * а не из самого прокси - в списке хранятся только host:port.
 *
 * @param {object} proxy
 * @param {string} protocol
 * @returns {string}
 */
function toPacProxyString(proxy, protocol) {
  if (!proxy) return '';
  const hostPort = `${proxy.host}:${proxy.port}`;
  switch (protocol) {
    case 'socks5':
      return `SOCKS5 ${hostPort}`;
    case 'socks4':
      return `SOCKS ${hostPort}`;
    case 'https':
      return `HTTPS ${hostPort}`;
    case 'http':
    default:
      return `PROXY ${hostPort}`;
  }
}

/**
 * Общие функции PAC-скриптов: нормализация хоста, отсечение локальных адресов
 * и проверка домена вместе с поддоменами.
 *
 * PAC-скрипты не поддерживают модули, поэтому helper-функции вставляются
 * текстом в каждый скрипт.
 *
 * Отсечение локальных и приватных адресов обязательно: прокси не может
 * достать машину в её собственной сети, поэтому попытка проксировать
 * 192.168.1.1, роутер или локальный сервер делает их недоступными.
 */
const PAC_HELPERS = `
function pacHost(host) {
  var value = String(host || '').toLowerCase();
  if (value.charAt(value.length - 1) === '.') {
    value = value.substring(0, value.length - 1);
  }
  return value;
}

function isLocalHost(host) {
  if (!host) return true;
  if (host === 'localhost' || host === '127.0.0.1' || host === '::1') return true;
  if (host.substring(host.length - 6) === '.local') return true;
  if (/^127\\./.test(host)) return true;
  if (/^10\\./.test(host)) return true;
  if (/^192\\.168\\./.test(host)) return true;
  if (/^172\\.(1[6-9]|2[0-9]|3[01])\\./.test(host)) return true;
  if (/^169\\.254\\./.test(host)) return true;
  if (/^f[cd][0-9a-f]{2}:/i.test(host)) return true;
  if (/^fe80:/i.test(host)) return true;
  return false;
}

function hostMatches(host, domain) {
  host = pacHost(host);
  domain = pacHost(domain);
  if (!host || !domain) return false;
  return host === domain || host.substring(host.length - domain.length - 1) === '.' + domain;
}

function matchesAny(host, list) {
  for (var i = 0; i < list.length; i++) {
    if (hostMatches(host, list[i])) return true;
  }
  return false;
}
`.trim();

/**
 * Строит PAC-скрипт на основе текущих настроек.
 *
 * Логика простая:
 *  - если расширение выключено или нет прокси → DIRECT;
 *  - локальные и приватные адреса → всегда DIRECT;
 *  - если proxyAllTraffic → всё через прокси;
 *  - если домен в списке проксируемых → PROXY;
 *  - иначе → DIRECT.
 *
 * @param {object} config
 * @returns {string}
 */
function buildPacScript(config) {
  const { enabled, proxyAllTraffic, proxyString, proxiedDomains } = config;

  if (!enabled || !proxyString) {
    return 'function FindProxyForURL(url, host) { return "DIRECT"; }';
  }

  const domainsList = JSON.stringify(proxiedDomains || []);

  return `
var PROXY = ${jsString(proxyString)};
var PROXY_ALL = ${proxyAllTraffic ? 'true' : 'false'};
var DOMAINS = ${domainsList};
${PAC_HELPERS}
function FindProxyForURL(url, host) {
  host = pacHost(host);
  if (isLocalHost(host)) return "DIRECT";
  if (PROXY_ALL) return PROXY;
  if (matchesAny(host, DOMAINS)) return PROXY;
  return "DIRECT";
}
`.trim();
}

/**
 * Строит PAC-скрипт для проверки одного прокси.
 *
 * Проверка выполняется через временную подмену PAC браузера (в MV3 другого
 * способа нет), поэтому тестовый PAC намеренно «узкий»: через проверяемый
 * прокси идут ТОЛЬКО хосты проверки. Сайты из списка в это время продолжают
 * работать через активный прокси, остальные сайты - напрямую. Поэтому проверка
 * не ломает посторонние сайты и безопасна даже при выгрузке service worker.
 *
 * @param {object} config
 * @param {string} config.proxyString строка проверяемого прокси
 * @param {Array<string>} config.testHosts хосты, которые проверяются
 * @param {string} [config.keepProxyString] строка активного прокси
 * @param {Array<string>} [config.keepDomains] сайты из списка проксируемых
 * @param {boolean} [config.keepAllTraffic] режим «весь трафик через прокси»
 * @returns {string}
 */
function buildTestPacScript(config) {
  const { proxyString, testHosts, keepProxyString, keepDomains, keepAllTraffic } = config;

  return `
var PROXY = ${jsString(proxyString)};
var TEST_HOSTS = ${JSON.stringify(testHosts || [])};
var KEEP_PROXY = ${jsString(keepProxyString || '')};
var KEEP_DOMAINS = ${JSON.stringify(keepDomains || [])};
var KEEP_ALL = ${keepAllTraffic ? 'true' : 'false'};
${PAC_HELPERS}
function FindProxyForURL(url, host) {
  host = pacHost(host);
  if (isLocalHost(host)) return "DIRECT";
  if (matchesAny(host, TEST_HOSTS)) return PROXY;
  if (KEEP_PROXY && KEEP_ALL) return KEEP_PROXY;
  if (KEEP_PROXY && matchesAny(host, KEEP_DOMAINS)) return KEEP_PROXY;
  return "DIRECT";
}
`.trim();
}

/**
 * Достаёт хост из URL.
 * @param {string} url
 * @returns {string}
 */
function hostFromUrl(url) {
  try {
    return String(new URL(String(url || '')).hostname || '').toLowerCase();
  } catch (error) {
    return '';
  }
}

/**
 * Хосты, которые нужно провести через проверяемый прокси: цель проверки,
 * тестовый сайт и IP-echo сервисы (по ним определяется страна выхода).
 *
 * @param {object} settings
 * @returns {Array<string>}
 */
function collectTestHosts(settings) {
  const urls = [settings.testUrl, settings.siteTestUrl, ...IP_ECHO_SERVICES];
  const hosts = [];
  for (const url of urls) {
    const host = hostFromUrl(url);
    if (!host || host === 'localhost' || hosts.includes(host)) continue;
    hosts.push(host);
  }
  return hosts;
}

/**
 * Проверяет, разрешено ли расширению работать в приватных окнах.
 *
 * @returns {Promise<boolean|null>} null - состояние определить не удалось
 */
function isIncognitoAllowed() {
  return new Promise((resolve) => {
    try {
      if (!chrome.extension || typeof chrome.extension.isAllowedIncognitoAccess !== 'function') {
        resolve(null);
        return;
      }
      chrome.extension.isAllowedIncognitoAccess((allowed) => resolve(!!allowed));
    } catch (error) {
      resolve(null);
    }
  });
}

/**
 * Применяет конфиг прокси: отдельно в обычные окна, отдельно в инкогнито.
 *
 * Инкогнито - это отдельный скоуп настроек. Если расширение не разрешено в
 * приватных окнах, Chrome не даёт туда писать: результат попытки сохраняется в
 * incognitoState, а страница настроек показывает подсказку. Писать в инкогнито
 * нужно явно: тогда проксируемые сайты работают и в приватных окнах так же,
 * как в обычных.
 *
 * @param {object} config конфиг chrome.proxy
 * @returns {Promise<{regular: boolean, incognito: boolean}>}
 */
async function applyProxyConfig(config) {
  const applied = { regular: false, incognito: false };

  try {
    // Сначала очищаем, затем ставим - это гарантирует переприменение PAC
    // даже если Chrome закэшировал предыдущее значение.
    await chrome.proxy.settings.clear({ scope: 'regular' });
    await chrome.proxy.settings.set({ value: config, scope: 'regular' });
    applied.regular = true;
  } catch (error) {
    log.error('background: не удалось применить настройки прокси (обычные окна)', error);
  }

  const allowed = await isIncognitoAllowed();
  if (allowed === false) {
    incognitoState = 'denied';
    return applied;
  }

  try {
    await chrome.proxy.settings.set({ value: config, scope: 'incognito_persistent' });
    applied.incognito = true;
    incognitoState = 'allowed';
  } catch (error) {
    incognitoState = 'denied';
    log.debug('background: настройки прокси для инкогнито не применены', error);
  }

  return applied;
}

/**
 * Применяет PAC-скрипт в браузере.
 * @returns {Promise<void>}
 */
async function applyProxySettings() {
  const settings = await getSettings();
  const activeProxy = await getActiveProxy();
  const proxiedSites = await getProxiedSites();

  const proxiedDomains = Array.from(
    new Set(proxiedSites.map(normalizeDomain).filter(Boolean))
  );

  // ВАЖНО: PAC не понимает `socks5://host:port`, нужен формат `SOCKS5 host:port`.
  // Протокол берём из общего переключателя настроек.
  const proxyString = toPacProxyString(activeProxy, settings.proxyProtocol);
  const pacScript = buildPacScript({
    enabled: settings.enabled,
    proxyAllTraffic: settings.proxyAllTraffic,
    proxyString,
    proxiedDomains,
  });

  const config = {
    mode: 'pac_script',
    pacScript: { data: pacScript },
  };

  log.debug('background: применяем PAC', {
    enabled: settings.enabled,
    proxyAllTraffic: settings.proxyAllTraffic,
    proxy: proxyString || '(нет)',
    domains: proxiedDomains.length,
  });

  const applied = await applyProxyConfig(config);
  log.info('background: PAC применён', {
    proxy: proxyString || '(нет)',
    domains: proxiedDomains.length,
    scopes: applied,
  });

  // Диагностика: читаем фактические настройки прокси.
  try {
    const actual = await chrome.proxy.settings.get({ incognito: false });
    log.debug('background: фактические настройки прокси', {
      levelOfControl: actual.levelOfControl,
      mode: actual.value && actual.value.mode,
      hasPac: !!(actual.value && actual.value.pacScript),
    });

    if (actual.levelOfControl === 'controlled_by_other_extensions') {
      log.warn(
        'background: настройки прокси контролируются другим расширением - Q.Proxy не может применить PAC'
      );
    }
  } catch (error) {
    log.debug('background: не удалось прочитать фактические настройки прокси', error);
  }

  if (incognitoState === 'denied') {
    log.info(
      'background: приватные окна - расширение не разрешено в инкогнито. ' +
        'Включите «Разрешить в режиме инкогнито» на странице chrome://extensions'
    );
  }

  // Состояние проксирования могло измениться - обновляем иконку вкладки.
  refreshActiveTabIcon().catch((error) => log.debug('background: иконка вкладки', error));
}

// ---------------------------------------------------------------------------
// Иконка расширения на вкладке
// ---------------------------------------------------------------------------

// Иконка в панели расширений повторяет круглую кнопку из попапа: серая, когда
// сайт открывается напрямую, зелёная - когда через прокси.
const TAB_ICON_FILES = {
  default: 'proxy-off',
  proxy: 'proxy-on',
  disabled: 'proxy-off',
};

const TAB_ICON_SIZES = [16, 32, 48, 128];

/**
 * Набор путей иконки для chrome.action.setIcon: все размеры, чтобы иконка
 * оставалась резкой на любом экране.
 *
 * @param {string} state default | proxy | disabled
 * @returns {object}
 */
function tabIconSet(state) {
  const name = TAB_ICON_FILES[state] || TAB_ICON_FILES.default;
  const path = {};
  for (const size of TAB_ICON_SIZES) {
    path[size] = chrome.runtime.getURL(`images/icons/${size}x${size}/${name}.png`);
  }
  return path;
}

const TAB_TITLES = {
  default: 'Q.Proxy',
  proxy: 'Q.Proxy - сайт открывается через прокси',
  disabled: 'Q.Proxy выключен',
};

/**
 * Ставит иконку и заголовок одной вкладки.
 * @param {number} tabId
 * @param {string} state default | proxy | disabled
 */
function setTabIcon(tabId, state) {
  if (typeof tabId !== 'number' || tabId < 0) return;
  try {
    chrome.action.setIcon({ tabId, path: tabIconSet(state) });
    chrome.action.setTitle({ tabId, title: TAB_TITLES[state] || TAB_TITLES.default });
  } catch (error) {
    log.debug('background: не удалось поставить иконку вкладки', error);
  }
}

/**
 * Определяет состояние вкладки и обновляет её иконку.
 * @param {number} tabId
 * @param {string} url
 * @returns {Promise<void>}
 */
async function refreshTabIcon(tabId, url) {
  const settings = await getSettings();
  if (!settings.enabled) {
    setTabIcon(tabId, 'disabled');
    return;
  }

  const host = normalizeDomain(url || '');
  if (!host || (!host.includes('.') && host !== 'localhost')) {
    setTabIcon(tabId, 'default');
    return;
  }

  const proxiedSites = await getProxiedSites();
  const viaProxy = !!settings.proxyAllTraffic || isProxied(host, proxiedSites);
  setTabIcon(tabId, viaProxy ? 'proxy' : 'default');
}

/**
 * Обновляет иконку активной вкладки: вызывается после смены настроек,
 * списка проксируемых сайтов и активного прокси.
 * @returns {Promise<void>}
 */
async function refreshActiveTabIcon() {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const tab = tabs && tabs[0];
  if (tab) await refreshTabIcon(tab.id, tab.url);
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!tab || !tab.url) return;
  if (changeInfo.status !== 'loading' && !changeInfo.url) return;
  refreshTabIcon(tabId, tab.url).catch((error) =>
    log.debug('background: иконка вкладки при загрузке', error)
  );
});

chrome.tabs.onActivated.addListener((info) => {
  chrome.tabs
    .get(info.tabId)
    .then((tab) => refreshTabIcon(info.tabId, tab && tab.url))
    .catch((error) => log.debug('background: иконка вкладки при активации', error));
});

// ---------------------------------------------------------------------------
// Загрузка списков прокси из источников
// ---------------------------------------------------------------------------

/**
 * Загружает текст по URL.
 * @param {string} url
 * @returns {Promise<string>}
 */
async function fetchText(url) {
  const response = await fetch(url, { cache: 'no-store', redirect: 'follow' });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  return response.text();
}

/**
 * Случайная выборка без повторов (перемешивание Фишера-Йетса).
 *
 * Нужна для лимита прокси: в списках-источниках порядок строк не меняется,
 * поэтому без перемешивания каждый импорт брал бы одни и те же первые прокси
 * файла.
 *
 * @param {Array<*>} items
 * @param {number} count
 * @returns {Array<*>}
 */
function pickRandom(items, count) {
  const list = items.slice();
  for (let i = list.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const swap = list[i];
    list[i] = list[j];
    list[j] = swap;
  }
  return list.slice(0, Math.max(0, Number(count) || 0));
}

/**
 * Загружает прокси из всех источников и добавляет их в список.
 *
 * @returns {Promise<{added: number, sources: number, errors: Array<string>}>}
 */
async function fetchProxySources() {
  const settings = await getSettings();
  const sources = await getProxySources();
  const errors = [];

  if (!sources.length) {
    log.warn('background: источники прокси не заданы');
    return { added: 0, sources: 0, errors: [] };
  }

  log.info('background: загрузка источников прокси', { count: sources.length });

  const collected = [];
  for (const url of sources) {
    try {
      const text = await fetchText(url);
      const parsed = parseProxyList(text);
      log.debug('background: источник загружен', { url, found: parsed.length });
      collected.push(...parsed);
    } catch (error) {
      log.warn('background: не удалось загрузить источник', url, error);
      errors.push(`${url}: ${error && error.message ? error.message : error}`);
    }
  }

  const existing = await getProxies();
  const existingKeys = new Set(existing.map((p) => `${p.host}:${p.port}`));

  const fresh = [];
  for (const parsed of collected) {
    const key = `${parsed.host}:${parsed.port}`;
    if (existingKeys.has(key)) continue;
    existingKeys.add(key);
    fresh.push({
      id: generateProxyId(),
      name: '',
      ...parsed,
    });
  }

  // Лимит размера списка прокси: 0 - без ограничения. Если прокси уже есть,
  // добавляем столько новых, сколько осталось до лимита.
  //
  // Из источника берём случайную выборку, а не первые строки: порядок строк в
  // публичных списках не меняется, поэтому раньше каждый импорт приносил одни и
  // те же прокси, хотя в файле их тысячи.
  const sourcesLimit = Math.max(0, parseInt(settings.sourcesLimit, 10) || 0);
  if (sourcesLimit) {
    const room = Math.max(0, sourcesLimit - existing.length);
    if (fresh.length > room) {
      const picked = pickRandom(fresh, room);
      log.info('background: сработал лимит прокси - взята случайная выборка', {
        limit: sourcesLimit,
        current: existing.length,
        found: fresh.length,
        kept: picked.length,
      });
      fresh.length = 0;
      for (const proxy of picked) fresh.push(proxy);
    }
  }

  let merged = dedupeProxies([...existing, ...fresh]);

  // Фильтр по стране размещения применяется сразу после импорта. Если базой
  // выбрана страна выхода, фильтр выполняет testAllProxies: до проверки
  // exitCountry неизвестен.
  if (
    settings.countryFilterAuto &&
    settings.countryFilterMode !== 'off' &&
    settings.countryFilterBase !== 'exit'
  ) {
    const before = merged.length;
    merged = merged.filter((proxy) => passesCountryFilter(proxy, settings));
    log.info('background: фильтр стран удалил прокси', before - merged.length);
  }

  await setProxies(merged);
  log.info('background: источники обработаны', {
    added: fresh.length,
    total: merged.length,
    errors: errors.length,
  });

  // Страны новых прокси определяем сразу: иначе колонка «Страна» остаётся
  // пустой до ручного нажатия кнопки.
  if (fresh.length) {
    try {
      await detectCountries({ limit: 200 });
    } catch (error) {
      log.warn('background: определение стран после загрузки источников', error);
    }
  }

  if (settings.sourcesAutoTest && fresh.length) {
    // Проверяем только свежие прокси: у уже имеющихся в списке есть свои
    // результаты проверки, и лишние запросы им не нужны.
    await testAllProxies(fresh.map((proxy) => proxy.id));
  } else {
    await selectBestProxy();
    await applyProxySettings();
  }

  return { added: fresh.length, sources: sources.length, errors };
}

/**
 * Планирует автозагрузку источников по таймеру.
 * @returns {Promise<void>}
 */
async function scheduleFetchSources() {
  const settings = await getSettings();
  await chrome.alarms.clear(ALARM_FETCH_SOURCES);
  if (settings.sourcesEnabled) {
    const periodInMinutes = Math.max(5, settings.sourcesInterval || 60);
    chrome.alarms.create(ALARM_FETCH_SOURCES, { periodInMinutes });
    log.debug('background: автозагрузка источников запланирована', { periodInMinutes });
  }
}

// ---------------------------------------------------------------------------
// Определение стран прокси
// ---------------------------------------------------------------------------

/**
 * Определяет страну по IP через внешние сервисы.
 *
 * Ответы бывают двух видов: JSON (ipwho.is, api.country.is) и просто код
 * страны текстом (ipapi.co, ipinfo.io). Поддерживаются оба варианта, а также
 * код страны разной длины в ответе - берём только двухбуквенный ISO-код.
 *
 * @param {string} ip
 * @returns {Promise<string|null>}
 */
async function detectCountryByIp(ip) {
  const target = String(ip || '').trim().replace(/^\[|\]$/g, '');
  if (!target) return null;

  for (const template of GEOIP_SERVICES) {
    const url = template.replace('{ip}', encodeURIComponent(target));
    try {
      const response = await fetch(url, { cache: 'no-store' });
      if (!response.ok) continue;
      const text = (await response.text()).trim();
      if (!text) continue;

      // JSON-ответ (ipwho.is, api.country.is, freeipapi.com).
      if (text.startsWith('{')) {
        try {
          const data = JSON.parse(text);
          const raw =
            data.country_code ||
            data.countryCode ||
            (data.country && data.country.code) ||
            data.country;
          const code = String(raw || '').trim().toUpperCase();
          if (code.length === 2) return code;
        } catch (error) {
          /* пробуем следующий сервис */
        }
        continue;
      }

      // Ответ в формате CSV: ip2c.org отдаёт "1;US;USA;United States".
      if (text.includes(';')) {
        const parts = text.split(';');
        const code = String(parts[1] || '').trim().toUpperCase();
        if (String(parts[0]).trim() === '1' && code.length === 2) return code;
        continue;
      }

      // Остальные отвечают просто кодом страны текстом.
      const code = text.replace(/[^A-Za-z]/g, '').toUpperCase();
      if (code.length === 2) return code;
    } catch (error) {
      /* пробуем следующий сервис */
    }
  }

  log.debug('background: страна не определена', { ip: target });
  return null;
}

/**
 * Определяет страны для прокси, у которых они неизвестны.
 *
 * @param {{limit?: number}} [options] limit - сколько прокси обработать за один
 *   проход (0 или не задано - все). Ограничение нужно для автозапуска после
 *   импорта больших списков: остальное дозаполняется при открытии настроек
 *   или по кнопке «Определить страны».
 * @returns {Promise<{detected: number, total: number}>}
 */
async function detectCountries(options = {}) {
  const limit = Number(options.limit) > 0 ? Math.floor(Number(options.limit)) : 0;

  const proxies = await getProxies();
  if (!proxies.length) {
    log.warn('background: список прокси пуст - определение стран пропущено');
    return { detected: 0, total: 0 };
  }

  const pending = proxies.filter((proxy) => !proxy.country);
  if (!pending.length) {
    log.info('background: страна уже определена у всех прокси', { total: proxies.length });
    return { detected: 0, total: proxies.length };
  }

  const queue = (limit ? pending.slice(0, limit) : pending).slice();
  log.info('background: определение стран', { withoutCountry: pending.length, inQueue: queue.length });

  const found = new Map();
  const concurrency = 4;

  /**
   * Обрабатывает один прокси из очереди.
   * @returns {Promise<void>}
   */
  async function worker() {
    while (queue.length) {
      const proxy = queue.shift();
      if (!proxy) break;

      const country = await detectCountryByIp(proxy.host);
      if (country) {
        found.set(proxy.id, country);
        log.debug('background: страна определена', {
          proxy: `${proxy.host}:${proxy.port}`,
          country,
        });
      }
    }
  }

  const workers = [];
  for (let i = 0; i < concurrency; i += 1) {
    workers.push(worker());
  }
  await Promise.all(workers);

  // Список мог измениться, пока шли запросы, поэтому результат применяется по
  // id к свежему списку, а не записью старого массива целиком.
  const fresh = await getProxies();
  let applied = 0;
  for (const proxy of fresh) {
    if (proxy.country) continue;
    const country = found.get(proxy.id);
    if (country) {
      proxy.country = country;
      applied += 1;
    }
  }

  if (applied) await setProxies(fresh);
  log.info('background: определение стран завершено', {
    detected: applied,
    total: fresh.length,
    inQueue: queue.length,
  });

  return { detected: applied, total: fresh.length };
}

// ---------------------------------------------------------------------------
// Проверка прокси
// ---------------------------------------------------------------------------

/**
 * Проверяет один прокси.
 *
 * В Chrome MV3 нет API для per-request прокси, поэтому проверка идёт через
 * временное переключение chrome.proxy. Ключевой момент: переключение делается
 * ОДИН раз на весь прокси, а все запросы (пинг, тестовый сайт, IP-echo)
 * выполняются внутри этой одной сессии. Ранее прокси переключался на каждый
 * запрос, и из-за постоянной смены прокси половина проверок обрывалась.
 *
 * @param {object} proxy
 * @param {object} settings
 * @returns {Promise<object>}
 */
async function testProxy(proxy, settings) {
  // Медленные публичные прокси не укладываются в прежние 8 секунд.
  const timeout = Math.max(Number(settings.testTimeout) || 8000, 10000);

  const result = {
    alive: false,
    // Проверка была остановлена: результат не записывается, прокси остаётся
    // «не проверено».
    aborted: false,
    needsAuth: false,
    latency: null,
    ping: null,
    siteLatency: null,
    exitIp: null,
    exitCountry: '',
    error: null,
  };

  try {
    const session = await withProxySession(proxy, settings, async (request) => {
      // Остановку проверяем перед каждым запросом: так «Остановить» срабатывает
      // почти сразу, а не после таймаута.
      if (testAborted) return { aborted: true };

      const probe = await request(settings.testUrl, timeout);
      const outcome = { probe, site: null, exit: { exitIp: null, exitCountry: '' }, aborted: false };
      if (!probe.ok) return outcome;
      if (testAborted) return { aborted: true };

      // Оба запроса идут внутри той же сессии прокси.
      outcome.site = await request(settings.siteTestUrl || 'https://www.google.com/', timeout);
      if (testAborted) return { aborted: true };

      outcome.exit = await probeExitInfo(request, timeout, proxy);
      return outcome;
    });

    if (session && session.aborted) {
      result.aborted = true;
      return result;
    }

    const { probe, site, exit } = session;

    result.ping = probe.ok ? probe.ms : null;
    result.latency = probe.ok ? probe.ms : null;
    // 407 - прокси требует авторизацию.
    result.needsAuth = probe.status === 407;

    if (!probe.ok) {
      result.error = probe.error || (probe.status ? 'bad_status' : 'network');
      return result;
    }

    result.alive = true;
    result.siteLatency = site && site.ok ? site.ms : null;
    result.exitIp = exit.exitIp;
    result.exitCountry = exit.exitCountry;

    return result;
  } catch (error) {
    result.error = error && error.name === 'AbortError' ? 'timeout' : 'network';
    return result;
  }
}

/**
 * Определяет IP и страну выхода внутри уже открытой сессии прокси.
 *
 * Запросы идут через переданную функцию request, поэтому прокси не
 * переключается повторно; тело ответа читается там же, внутри сессии.
 *
 * @param {(url: string, timeout: number) => Promise<object>} request
 * @param {number} timeout
 * @param {object} proxy
 * @returns {Promise<{exitIp: string|null, exitCountry: string}>}
 */
async function probeExitInfo(request, timeout, proxy) {
  let exitIp = null;
  const errors = [];

  for (const url of IP_ECHO_SERVICES) {
    const response = await request(url, timeout);
    if (!response.ok) {
      errors.push(`${url}: ${response.error || 'HTTP ' + response.status}`);
      continue;
    }

    const text = String(response.text || '').trim();
    if (!text) {
      errors.push(`${url}: пустой ответ`);
      continue;
    }

    let ip = null;
    if (text.startsWith('{')) {
      try {
        const data = JSON.parse(text);
        ip = data.ip || data.query || null;
      } catch (error) {
        /* пробуем следующий сервис */
      }
    } else {
      const match = text.match(/\b\d{1,3}(?:\.\d{1,3}){3}\b/);
      if (match) ip = match[0];
    }

    if (ip) {
      exitIp = ip;
      break;
    }
  }

  if (!exitIp) {
    log.warn('background: IP выхода через прокси не определён', {
      proxy: formatProxyString(proxy),
      errors,
    });
    return { exitIp: null, exitCountry: '' };
  }

  const country = await detectCountryByIp(exitIp);
  if (!country) {
    log.warn('background: страна выхода не определена', { exitIp });
  }
  return { exitIp, exitCountry: country || '' };
}

/**
 * Открывает одну сессию прокси и выполняет внутри неё все запросы проверки.
 *
 * В MV3 нет API «прокси на один запрос», поэтому проверка идёт через временную
 * подмену PAC-скрипта браузера. Подмена минимальная: через проверяемый прокси
 * идут ТОЛЬКО хосты проверки (цель проверки, тестовый сайт, IP-echo сервисы).
 * Остальной трафик в это время работает как обычно: обычные сайты - напрямую,
 * сайты из списка - через активный прокси. Раньше здесь выставлялся
 * fixed_servers на весь браузер, из-за чего во время проверки (и после
 * аварийной выгрузки service worker) через случайный прокси шли ВСЕ сайты и
 * падали с ERR_SOCKS_CONNECTION_FAILED.
 *
 * handler получает функцию request(url, timeout), которая ходит через этот
 * прокси и сразу читает тело ответа (тело обязательно читать до восстановления
 * PAC, иначе соединение через прокси уже закрыто и response.text() падает).
 * После handler рабочий PAC возвращается. Сессии сериализуются очередью, чтобы
 * не мешать друг другу.
 *
 * @param {object} proxy
 * @param {object} settings
 * @param {(request: Function) => Promise<*>} handler
 * @returns {Promise<*>}
 */
async function withProxySession(proxy, settings, handler) {
  return withProxyLock(async () => {
    const protocol = settings.proxyProtocol;
    const activeProxy = await getActiveProxy();
    const proxiedSites = await getProxiedSites();
    const testHosts = collectTestHosts(settings);
    const keepDomains = Array.from(
      new Set(proxiedSites.map(normalizeDomain).filter(Boolean))
    );
    const keepProxyString = activeProxy ? toPacProxyString(activeProxy, protocol) : '';

    const pacData = buildTestPacScript({
      proxyString: toPacProxyString(proxy, protocol),
      testHosts,
      keepProxyString,
      keepDomains,
      keepAllTraffic: !!settings.proxyAllTraffic,
    });

    log.debug('background: сессия проверки прокси', {
      proxy: formatProxyString(proxy),
      testHosts: testHosts.length,
      keepDomains: keepDomains.length,
      keepProxy: keepProxyString || '(нет)',
    });

    await chrome.proxy.settings.set({
      value: { mode: 'pac_script', pacScript: { data: pacData } },
      scope: 'regular',
    });

    /**
     * Запрос через открытую сессию прокси.
     * @param {string} url
     * @param {number} timeout
     * @returns {Promise<{ok: boolean, status: number, text: string, ms: number, error: string}>}
     */
    const request = async (url, timeout) => {
      // Запрос отменяется и по таймауту, и кнопкой «Остановить»: подписываемся
      // на общий контроллер проверки.
      const stopSignal = testAbortController ? testAbortController.signal : null;
      const controller = new AbortController();
      const onStop = () => controller.abort();
      if (stopSignal) {
        if (stopSignal.aborted) {
          controller.abort();
        } else {
          stopSignal.addEventListener('abort', onStop, { once: true });
        }
      }
      const timer = setTimeout(() => controller.abort(), timeout);
      const started = Date.now();
      try {
        const response = await fetch(url, {
          method: 'GET',
          cache: 'no-store',
          signal: controller.signal,
          redirect: 'follow',
        });
        const text = await response.text();
        return {
          ok: response.ok,
          status: response.status,
          text,
          ms: Date.now() - started,
          error: '',
        };
      } catch (error) {
        return {
          ok: false,
          status: 0,
          text: '',
          ms: Date.now() - started,
          error: String((error && error.name) || error),
        };
      } finally {
        clearTimeout(timer);
        if (stopSignal) stopSignal.removeEventListener('abort', onStop);
      }
    };

    try {
      return await handler(request);
    } finally {
      // Возвращаем рабочий PAC-скрипт после всех запросов сессии.
      await applyProxySettings();
    }
  });
}

// Простая очередь, чтобы не переключать прокси параллельно.
let proxyLock = Promise.resolve();

/**
 * Сериализует доступ к chrome.proxy.settings.
 * @param {Function} task
 * @returns {Promise<*>}
 */
function withProxyLock(task) {
  const run = proxyLock.then(task, task);
  proxyLock = run.catch(() => {});
  return run;
}

/**
 * Порядок прокси после проверки: сначала рабочие по возрастанию пинга, затем
 * требующие авторизации, затем непроверенные и недоступные.
 *
 * @param {Array<object>} proxies
 * @param {Object<string, object>} stats
 * @returns {Array<object>}
 */
function sortProxiesByPing(proxies, stats) {
  const rank = (proxy) => {
    const stat = stats[proxy.id] || {};
    if (stat.alive) return 0;
    if (stat.checkedAt && stat.needsAuth) return 1;
    if (stat.checkedAt) return 3;
    return 2;
  };
  const time = (proxy) => {
    const stat = stats[proxy.id] || {};
    const value = stat.ping != null ? stat.ping : stat.latency;
    return value != null ? value : Infinity;
  };

  return proxies.slice().sort((a, b) => {
    const ra = rank(a);
    const rb = rank(b);
    if (ra !== rb) return ra - rb;
    const ta = time(a);
    const tb = time(b);
    if (ta !== tb) return ta - tb;
    return formatProxyString(a).localeCompare(formatProxyString(b));
  });
}

/**
 * Запускает проверку прокси из списка с ограничением параллелизма.
 *
 * @param {Array<string>} [ids] id прокси, которые нужно проверить. Если список
 *   не передан или пуст, проверяется весь список: так работает фоновая
 *   проверка по таймеру и кнопка без выбранных чекбоксов.
 * @returns {Promise<object>} итог проверки из runProxyTest
 */
async function testAllProxies(ids) {
  if (testInProgress) {
    log.warn('background: проверка уже идёт - повторный запуск пропущен');
    return { started: false, running: true };
  }

  testInProgress = true;
  // Контроллер создаётся на каждый запуск: по нему «Остановить» обрывает
  // начатые запросы.
  testAbortController = new AbortController();

  try {
    return await runProxyTest(ids);
  } finally {
    testInProgress = false;
    testAborted = false;
    testAbortController = null;
    checkingIds.clear();
    queuedIds.clear();
    checkProgress.running = false;
  }
}

/**
 * Сама проверка прокси: гоняет очередь через временную подмену PAC и пишет
 * статистику. Вызывается только через testAllProxies.
 *
 * @param {Array<string>} [ids]
 * @returns {Promise<object>}
 */
async function runProxyTest(ids) {
  const settings = await getSettings();
  const all = await getProxies();
  const onlyIds = Array.isArray(ids) && ids.length ? new Set(ids.map(String)) : null;
  const proxies = onlyIds ? all.filter((proxy) => onlyIds.has(String(proxy.id))) : all;

  if (!proxies.length) {
    log.warn('background: список прокси пуст - проверка пропущена');
    return { started: true, checked: 0, total: 0 };
  }

  // Тестовый URL берём из выбранной цели, если она задана.
  const targetUrl = TEST_TARGETS[settings.testTarget] || settings.testUrl;
  const effectiveSettings = { ...settings, testUrl: targetUrl };

  log.info('background: старт проверки прокси', {
    count: proxies.length,
    onlySelected: !!onlyIds,
    concurrency: settings.testConcurrency,
    timeout: settings.testTimeout,
    target: settings.testTarget,
    url: targetUrl,
  });

  checkProgress = {
    total: proxies.length,
    done: 0,
    running: true,
    alive: 0,
    limited: 0,
    dead: 0,
  };
  testAborted = false;
  checkingIds.clear();
  queuedIds.clear();
  for (const proxy of proxies) {
    queuedIds.add(proxy.id);
  }

  const stats = await getProxyStats();
  const queue = proxies.slice();
  const concurrency = Math.max(1, Math.min(settings.testConcurrency || 4, 16));

  /**
   * Обрабатывает один прокси из очереди.
   * @returns {Promise<void>}
   */
  async function worker() {
    while (queue.length) {
      if (testAborted) break;

      const proxy = queue.shift();
      if (!proxy) break;

      // Помечаем прокси как проверяемый - UI покажет «проверка…».
      queuedIds.delete(proxy.id);
      checkingIds.add(proxy.id);

      const result = await testProxy(proxy, effectiveSettings);

      // Проверка остановлена: недопроверенный прокси не получает ни статуса,
      // ни места в статистике - он останется «не проверено».
      if (result.aborted) {
        checkingIds.delete(proxy.id);
        log.debug('background: проверка прервана на прокси', formatProxyString(proxy));
        break;
      }

      stats[proxy.id] = {
        alive: result.alive,
        needsAuth: result.needsAuth,
        latency: result.latency,
        ping: result.ping,
        siteLatency: result.siteLatency,
        exitIp: result.exitIp,
        exitCountry: result.exitCountry,
        error: result.error,
        checkedAt: Date.now(),
      };
      checkingIds.delete(proxy.id);
      checkProgress.done += 1;
      // Счётчики для строки прогресса. Рабочим считается только полностью
      // рабочий прокси - живой и с открывшимся тестовым сайтом; «ограниченный»
      // идёт отдельным счётчиком, иначе он попадал в число рабочих.
      if (result.alive && result.siteLatency != null) {
        checkProgress.alive += 1;
      } else if (result.alive) {
        checkProgress.limited += 1;
      } else {
        checkProgress.dead += 1;
      }
      log.debug('background: прокси проверен', {
        proxy: formatProxyString(proxy),
        alive: result.alive,
        needsAuth: result.needsAuth,
        ping: result.ping,
        latency: result.latency,
        siteLatency: result.siteLatency,
        exitCountry: result.exitCountry,
        error: result.error,
        progress: `${checkProgress.done}/${checkProgress.total}`,
      });
      await setProxyStats(stats);
    }
  }

  const workers = [];
  for (let i = 0; i < concurrency; i += 1) {
    workers.push(worker());
  }
  await Promise.all(workers);

  // Удаляем нерабочие, если включено. Список читаем заново: пока шла проверка,
  // его могли изменить. Прокси, которых в проверке не было (проверяли
  // выбранные чекбоксами), не удаляются.
  if (settings.autoDeleteDead && !testAborted) {
    const fresh = await getProxies();
    const kept = fresh.filter((proxy) => {
      if (onlyIds && !onlyIds.has(String(proxy.id))) return true;
      const stat = stats[proxy.id];
      return !stat || stat.alive;
    });
    if (kept.length !== fresh.length) {
      log.info('background: удалено нерабочих прокси', fresh.length - kept.length);
      await setProxies(kept);
    }
  }

  // Сразу упорядочиваем список по пингу: самый быстрый рабочий прокси
  // оказывается первым, и в настройках он виден сверху без ручной сортировки.
  const ordered = sortProxiesByPing(await getProxies(), stats);
  await setProxies(ordered);
  log.info('background: список отсортирован по пингу', { count: ordered.length });

  // Фильтр по стране выхода применяется только сейчас: до проверки страна
  // выхода неизвестна.
  if (
    !testAborted &&
    settings.countryFilterAuto &&
    settings.countryFilterMode !== 'off' &&
    settings.countryFilterBase === 'exit'
  ) {
    const before = ordered.length;
    const kept = ordered.filter((proxy) =>
      passesCountryFilter(proxy, settings, stats[proxy.id])
    );
    if (kept.length !== before) {
      await setProxies(kept);
      log.info('background: фильтр по стране выхода удалил прокси', before - kept.length);
    }
  }

  const aborted = testAborted;
  const aliveCount = Object.values(stats).filter((s) => s && s.alive).length;
  log.info('background: проверка завершена', {
    alive: aliveCount,
    total: proxies.length,
    checked: checkProgress.done,
    aborted,
  });

  // Итоги применяем в любом случае: активный прокси и PAC должны вернуться в
  // рабочее состояние даже после остановки.
  await selectBestProxy();
  await applyProxySettings();

  return { started: true, aborted, checked: checkProgress.done, total: proxies.length };
}

/**
 * Выбирает лучший рабочий прокси и делает его активным.
 * @returns {Promise<void>}
 */
async function selectBestProxy() {
  const proxies = await getProxies();
  const stats = await getProxyStats();
  const current = await getActiveProxy();

  // По умолчанию активным становится только полностью рабочий прокси: тот,
  // через который открылся тестовый сайт. «Ограниченный» прокси (живой, но
  // сайт через него не открылся) может быть быстрее по пингу - и всё равно
  // по умолчанию не выбирается.
  const works = proxies
    .filter((proxy) => {
      const stat = stats[proxy.id];
      return stat && stat.alive && stat.siteLatency != null;
    })
    .sort((a, b) => {
      const la = (stats[a.id] && stats[a.id].latency) || Infinity;
      const lb = (stats[b.id] && stats[b.id].latency) || Infinity;
      return la - lb;
    });

  if (works.length) {
    const best = works[0];
    if (!current || current.id !== best.id) {
      log.info('background: выбран лучший рабочий прокси', formatProxyString(best));
      await setActiveProxy(best);
    }
    return;
  }

  // Если проверенных нет - берём первый из списка.
  if (!current && proxies.length) {
    log.info('background: активный прокси не проверен, берём первый');
    await setActiveProxy(proxies[0]);
  }
}

// ---------------------------------------------------------------------------
// Служебные обработчики
// ---------------------------------------------------------------------------

/**
 * Планирует периодическую проверку прокси.
 * @returns {Promise<void>}
 */
async function scheduleAutoTest() {
  const settings = await getSettings();
  await chrome.alarms.clear(ALARM_TEST_PROXIES);
  if (settings.autoTestEnabled) {
    const periodInMinutes = Math.max(1, settings.autoTestInterval || 15);
    chrome.alarms.create(ALARM_TEST_PROXIES, { periodInMinutes });
    log.debug('background: авто-тест запланирован', { periodInMinutes });
  }
}

/**
 * Инициализация при установке/обновлении.
 * @param {object} details
 * @returns {Promise<void>}
 */
async function onInstalled(details) {
  const settings = await getSettings();
  await setSettings(settings);
  await scheduleAutoTest();
  await scheduleFetchSources();
  await selectBestProxy();
  await applyProxySettings();

  if (details && details.reason === 'install') {
    chrome.tabs.create({ url: 'options.html' });
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  onInstalled(details).catch((error) => log.error('background: onInstalled', error));
});

chrome.runtime.onStartup.addListener(() => {
  (async () => {
    await scheduleAutoTest();
    await scheduleFetchSources();
    await selectBestProxy();
    await applyProxySettings();
  })().catch((error) => log.error('background: onStartup', error));
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_TEST_PROXIES) {
    testAllProxies().catch((error) => log.error('background: autoTest', error));
  }
  if (alarm.name === ALARM_FETCH_SOURCES) {
    fetchProxySources().catch((error) => log.error('background: autoFetchSources', error));
  }
});

// Реакция на изменения настроек.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  const relevant = ['proxies', 'proxiedSites', 'settings', 'activeProxy'];
  if (relevant.some((key) => key in changes)) {
    applyProxySettings().catch((error) => log.error('background: storage change', error));
  }
  if ('settings' in changes) {
    scheduleAutoTest().catch((error) => log.error('background: schedule', error));
    scheduleFetchSources().catch((error) => log.error('background: scheduleSources', error));
  }
});

// ---------------------------------------------------------------------------
// Сообщения от UI
// ---------------------------------------------------------------------------

/**
 * Обрабатывает сообщения от popup/options.
 * @param {object} message
 * @param {object} sender
 * @param {Function} sendResponse
 * @returns {boolean}
 */
function handleMessage(message, sender, sendResponse) {
  const { type } = message || {};
  log.debug('background: получено сообщение', type, message);

  (async () => {
    switch (type) {
      case 'getState': {
        const [settings, proxies, proxiedSites, activeProxy, stats] = await Promise.all([
          getSettings(),
          getProxies(),
          getProxiedSites(),
          getActiveProxy(),
          getProxyStats(),
        ]);
        sendResponse({ settings, proxies, proxiedSites, activeProxy, stats, incognito: incognitoState });
        break;
      }
      case 'getIncognitoState': {
        const allowed = await isIncognitoAllowed();
        if (allowed !== null) incognitoState = allowed ? 'allowed' : 'denied';
        sendResponse({ ok: true, incognito: incognitoState });
        break;
      }
      case 'applyProxySettings': {
        await applyProxySettings();
        sendResponse({ ok: true });
        break;
      }
      case 'testAllProxies': {
        await testAllProxies(message.ids);
        sendResponse({ ok: true });
        break;
      }
      case 'selectBestProxy': {
        await selectBestProxy();
        await applyProxySettings();
        sendResponse({ ok: true });
        break;
      }
      case 'isProxied': {
        const hostname = normalizeDomain(message.hostname);
        const proxiedSites = await getProxiedSites();
        const proxied = self.QProxyStorage.isProxied(hostname, proxiedSites);
        sendResponse({ proxied });
        break;
      }
      case 'setSiteProxied': {
        const hostname = normalizeDomain(message.hostname);
        const proxied = !!message.proxied;
        const proxiedSites = await getProxiedSites();
        let next;
        if (proxied) {
          next = Array.from(new Set([...proxiedSites, hostname]));
        } else {
          next = proxiedSites.filter((site) => normalizeDomain(site) !== hostname);
        }
        await setProxiedSites(next);
        await applyProxySettings();
        log.info('background: сайт', hostname, proxied ? 'добавлен в проксируемые' : 'убран из проксируемых');
        sendResponse({ ok: true, proxied, count: next.length });
        break;
      }
      case 'addProxiedSites': {
        const domains = (message.domains || []).map(normalizeDomain).filter(Boolean);
        const proxiedSites = await getProxiedSites();
        const merged = Array.from(new Set([...proxiedSites, ...domains]));
        await setProxiedSites(merged);
        await applyProxySettings();
        log.info('background: добавлено доменов', domains.length);
        sendResponse({ ok: true, count: merged.length });
        break;
      }
      case 'removeProxiedSite': {
        const domain = normalizeDomain(message.domain);
        const proxiedSites = await getProxiedSites();
        await setProxiedSites(proxiedSites.filter((item) => normalizeDomain(item) !== domain));
        await applyProxySettings();
        sendResponse({ ok: true });
        break;
      }
      case 'setProxiedSites': {
        const domains = Array.from(
          new Set((message.domains || []).map(normalizeDomain).filter(Boolean))
        );
        await setProxiedSites(domains);
        await applyProxySettings();
        log.info('background: список сайтов сохранён', domains.length);
        sendResponse({ ok: true, count: domains.length });
        break;
      }
      case 'setProxies': {
        // Страховка от дубликатов: двух одинаковых host:port в списке быть не
        // может, даже если они пришли из интерфейса.
        await setProxies(dedupeProxies(message.proxies || []));
        await selectBestProxy();
        await applyProxySettings();
        sendResponse({ ok: true });
        break;
      }
      case 'addProxiesFromText': {
        const parsed = parseProxyList(message.text || '');
        const existing = await getProxies();
        const existingKeys = new Set(existing.map((p) => `${p.host}:${p.port}`));
        const fresh = [];
        for (const item of parsed) {
          const key = `${item.host}:${item.port}`;
          if (existingKeys.has(key)) continue;
          existingKeys.add(key);
          fresh.push({ id: generateProxyId(), name: '', ...item });
        }
        const merged = dedupeProxies([...existing, ...fresh]);
        await setProxies(merged);
        await selectBestProxy();
        await applyProxySettings();

        // Определяем страны добавленных прокси, чтобы в таблице настроек не
        // было прочерков. Первые 200 - сразу, остальные дозаполняются в фоне.
        if (fresh.length) {
          try {
            await detectCountries({ limit: 200 });
          } catch (error) {
            log.warn('background: определение стран после импорта', error);
          }
        }

        log.info('background: добавлено прокси из текста', {
          parsed: parsed.length,
          added: fresh.length,
          total: merged.length,
        });
        sendResponse({ ok: true, parsed: parsed.length, added: fresh.length, total: merged.length });
        break;
      }
      case 'removeUntestedProxies': {
        const proxies = await getProxies();
        const stats = await getProxyStats();
        const kept = proxies.filter((proxy) => stats[proxy.id] && stats[proxy.id].checkedAt);
        await setProxies(kept);
        await selectBestProxy();
        await applyProxySettings();
        log.info('background: удалено непроверенных', proxies.length - kept.length);
        sendResponse({ ok: true, removed: proxies.length - kept.length, total: kept.length });
        break;
      }
      case 'removeDeadProxies': {
        const proxies = await getProxies();
        const stats = await getProxyStats();
        const kept = proxies.filter((proxy) => {
          const stat = stats[proxy.id];
          return !stat || !stat.checkedAt || stat.alive;
        });
        await setProxies(kept);
        await selectBestProxy();
        await applyProxySettings();
        log.info('background: удалено нерабочих', proxies.length - kept.length);
        sendResponse({ ok: true, removed: proxies.length - kept.length, total: kept.length });
        break;
      }
      case 'fetchProxySources': {
        const result = await fetchProxySources();
        sendResponse({ ok: true, ...result });
        break;
      }
      case 'detectCountries': {
        const result = await detectCountries();
        sendResponse({ ok: true, ...result });
        break;
      }
      case 'applyCountryFilter': {
        const settings = await getSettings();
        const stats = await getProxyStats();
        const proxies = await getProxies();
        const kept = proxies.filter((proxy) => passesCountryFilter(proxy, settings, stats[proxy.id]));
        await setProxies(kept);
        await selectBestProxy();
        await applyProxySettings();
        log.info('background: фильтр стран применён', {
          removed: proxies.length - kept.length,
          kept: kept.length,
        });
        sendResponse({ ok: true, removed: proxies.length - kept.length, kept: kept.length });
        break;
      }
      case 'keepOnlyCountry': {
        const country = String(message.country || '').toUpperCase();
        const settings = await getSettings();
        const stats = await getProxyStats();
        const proxies = await getProxies();
        const kept = proxies.filter(
          (proxy) => getFilterCountry(proxy, settings, stats[proxy.id]) === country
        );
        await setProxies(kept);
        await selectBestProxy();
        await applyProxySettings();
        log.info('background: оставлена только страна', country, { kept: kept.length });
        sendResponse({ ok: true, removed: proxies.length - kept.length, kept: kept.length });
        break;
      }
      case 'getProgress': {
        sendResponse({
          ok: true,
          progress: {
            ...checkProgress,
            checking: Array.from(checkingIds),
            queued: Array.from(queuedIds),
          },
        });
        break;
      }
      case 'stopTestProxies': {
        testAborted = true;
        // Обрываем уже начатые запросы: без этого остановка ждала бы таймаута
        // текущего прокси - до нескольких десятков секунд.
        if (testAbortController) testAbortController.abort();
        log.info('background: проверка остановлена пользователем', {
          running: testInProgress,
        });
        sendResponse({ ok: true, running: testInProgress });
        break;
      }
      case 'getProxySources': {
        const sources = await getProxySources();
        sendResponse({ ok: true, sources });
        break;
      }
      case 'setProxySources': {
        const sources = (message.sources || [])
          .map((s) => String(s).trim())
          .filter(Boolean);
        await setProxySources(sources);
        await scheduleFetchSources();
        sendResponse({ ok: true, count: sources.length });
        break;
      }
      case 'setActiveProxy': {
        await setActiveProxy(message.proxy || null);
        await applyProxySettings();
        sendResponse({ ok: true });
        break;
      }
      case 'setSettings': {
        const current = await getSettings();
        const next = { ...current, ...(message.settings || {}) };
        await setSettings(next);
        await scheduleAutoTest();
        await applyProxySettings();
        sendResponse({ ok: true, settings: next });
        break;
      }
      case 'diagnose': {
        const [settings, proxies, proxiedSites, activeProxy] = await Promise.all([
          getSettings(),
          getProxies(),
          getProxiedSites(),
          getActiveProxy(),
        ]);
        const actual = await chrome.proxy.settings.get({ incognito: false });

        // Отдельно смотрим скоуп инкогнито: если прокси в приватных окнах
        // контролирует другое расширение, сайты там будут падать с
        // ERR_PROXY_CONNECTION_FAILED.
        let incognitoReport = null;
        try {
          const incognitoActual = await chrome.proxy.settings.get({ incognito: true });
          incognitoReport = {
            levelOfControl: incognitoActual.levelOfControl,
            mode: incognitoActual.value && incognitoActual.value.mode,
          };
        } catch (error) {
          incognitoReport = {
            error: String(error && error.message ? error.message : error),
          };
        }

        const report = {
          settings,
          proxiesCount: proxies.length,
          proxiedSites,
          activeProxy,
          proxyString: activeProxy ? formatProxyString(activeProxy) : null,
          levelOfControl: actual.levelOfControl,
          mode: actual.value && actual.value.mode,
          incognitoState,
          incognito: incognitoReport,
          pacPreview:
            actual.value && actual.value.pacScript
              ? actual.value.pacScript.data.slice(0, 400)
              : null,
        };
        log.info('background: диагностика', report);
        sendResponse({ ok: true, report });
        break;
      }
      default:
        log.warn('background: неизвестный тип сообщения', type);
        sendResponse({ ok: false, error: 'unknown_message' });
    }
  })().catch((error) => {
    log.error('background: handleMessage', error);
    sendResponse({ ok: false, error: String(error && error.message ? error.message : error) });
  });

  return true;
}

chrome.runtime.onMessage.addListener(handleMessage);

// Первичная инициализация при старте service worker.
(async () => {
  await scheduleAutoTest();
  await scheduleFetchSources();
  await selectBestProxy();
  await applyProxySettings();
})().catch((error) => log.error('background: init', error));
