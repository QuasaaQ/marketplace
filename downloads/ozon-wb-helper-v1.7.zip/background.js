// background.js - Service Worker для расширения

// Слушаем сообщения от content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "redirect") {
        // Обновляем URL вкладки
        if (sender.tab && sender.tab.id) {
            chrome.tabs.update(sender.tab.id, { url: request.url });
        }
        sendResponse({ success: true });
    }
    return true;
});

// Обработка навигации для отслеживания изменения URL
chrome.webNavigation.onHistoryStateUpdated.addListener((details) => {
    if (details.frameId === 0) { // Только главный фрейм
        // Отправляем сообщение в content script об изменении URL
        chrome.tabs.sendMessage(details.tabId, {
            action: "urlChanged",
            url: details.url
        }).catch(() => {
            // Игнорируем ошибки, если content script еще не загружен
        });
    }
});

// Слушаем изменения в хранилище для синхронизации настроек
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.SettingsOnOff) {
        // Отправляем обновленные настройки всем вкладкам
        chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, {
                    action: "settingsChanged",
                    SettingsOnOff: changes.SettingsOnOff.newValue
                }).catch(() => {
                    // Игнорируем ошибки
                });
            });
        });
    }
});