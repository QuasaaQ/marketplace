// ===== BEST PRICE =====
// Константы, данные, рендер цены, сортировка каталога

// ===== BEST PRICE STORE =====
function storeParsedTitleToElement(cardEl, parsedTitle) {
    if (!cardEl) return;
    cardEl.classList.add(BEST_PRICE_WRAP_CLASS_NAME);
    if (!parsedTitle) return;
    storeDataToElement(cardEl, parsedTitle);
}

function storeDataToElement(el, data) {
    if (!el) return;
    var ds = el.dataset;
    for (var k in data) {
        if (data.hasOwnProperty(k)) {
            ds[PREFIX + k] = JSON.stringify(data[k]);
        }
    }
}

function readDataFromElement(el) {
    if (!el) return {};
    var pairs = Object.entries(el.dataset).map(function(kv) {
        var k = kv[0], v = kv[1];
        if (k.startsWith(PREFIX)) {
            return [k.replace(RegExp("^" + PREFIX), ""), JSON.parse(v || "")];
        }
        return [null, null];
    }).filter(function(kv) { return kv[0]; });
    if (pairs.length > 0) {
        var obj = {};
        for (var i = 0; i < pairs.length; i++) {
            obj[pairs[i][0]] = pairs[i][1];
        }
        return obj;
    }
    return {};
}

function loadParsedTitleFromElement(cardEl) {
    if (!cardEl) return null;
    var pairs = Object.entries(cardEl.dataset).map(function(kv) {
        var k = kv[0], v = kv[1];
        if (k.startsWith(PREFIX)) {
            return [k.replace(RegExp("^" + PREFIX), ""), JSON.parse(v || "")];
        }
        return [null, null];
    }).filter(function(kv) { return kv[0]; });
    if (pairs.length > 0) {
        var obj = {};
        for (var i = 0; i < pairs.length; i++) {
            obj[pairs[i][0]] = pairs[i][1];
        }
        return obj;
    }
    return null;
}

// ===== PRICE RENDER =====
function renderBestPrice(titleInfo, extraStyle) {
    if (!extraStyle) extraStyle = {};
    var wrapEl = document.createElement("div");
    wrapEl.className = BEST_PRICE_CLASS_NAME;
    if (!titleInfo) {
        return wrapEl;
    }
    for (var i = 0; i < titleInfo.units.length; i++) {
        var u = titleInfo.units[i];
        var el = document.createElement("div");
        el.innerHTML = u.price_display;
        wrapEl.appendChild(el);
    }
    if (titleInfo.quantity_price_display) {
        var qtyEl = document.createElement("div");
        qtyEl.innerHTML = titleInfo.quantity_price_display;
        wrapEl.appendChild(qtyEl);
    }
    if (wrapEl.childNodes.length) {
        wrapEl.style.cssText = [
            "border: 1px solid #e53935;",
            "border-radius: 4px;",
            "padding: 2px 5px 3px;",
            "margin: 0 4px;",
            "display: inline-flex;",
            "flex-direction: column;",
            "justify-content: center;",
            "align-items: center;",
            "width: fit-content;",
            "background: #fff5f5;",
            "font-size: 11px;",
            "font-weight: 600;",
            "color: #c62828;",
            "text-align: center;",
            "line-height: 1.5;",
            "font-family: Arial, sans-serif;",
            "box-shadow: 0 1px 3px rgba(229, 57, 53, 0.15);",
            "vertical-align: middle;",
            "white-space: nowrap;"
        ].join(" ");
        for (var k in extraStyle) {
            if (extraStyle.hasOwnProperty(k) && typeof extraStyle[k] === "string") {
                wrapEl.style[k] = extraStyle[k];
            }
        }
    }
    return wrapEl;
}

// ===== COMMON PARSER =====
function processProductCard(cardEl, options) {
    if (!config.bestPriceEnabled) return;
    if (!cardEl) return;
    
    var price_sel = options.price_sel;
    var title_sel = options.title_sel;
    var to_render = options.to_render;
    var force = options.force;
    // Корень для поиска цены/места вставки. По умолчанию — сама карточка.
    // На Ozon цена товара может быть вне [data-widget="container"], поэтому
    // можно передать price_root = document, чтобы искать по всей странице.
    var price_root = options.price_root || cardEl;
    if (!force && cardEl.classList.contains(BEST_PRICE_WRAP_CLASS_NAME)) return;

    var price = getPrice(price_sel, price_root);
    var titleEl = cardEl.querySelector(title_sel);
    var title = titleEl ? titleEl.textContent.trim() : null;
    
    // Отладка
    if (window.location.host.indexOf('wildberries') !== -1) {
        var classes = cardEl.className;
        var foundPriceEl = price_root.querySelector(price_sel);
        var foundTitleEl = cardEl.querySelector(title_sel);
        dbg("[WB debug CARD]", {
            classes: classes,
            priceSel: price_sel,
            priceFound: foundPriceEl ? foundPriceEl.textContent.trim().substring(0, 30) : "NO",
            titleSel: title_sel,
            titleFound: title ? title.substring(0, 30) : "NO",
            renderSel: typeof to_render === 'string' ? to_render : to_render.sel,
            cardInner: cardEl.innerHTML.substring(0, 200)
        });
    } else if (window.location.host.indexOf('ozon') !== -1) {
        var classes = cardEl.className;
        var foundPriceEl = price_root.querySelector(price_sel);
        dbg("[OZON debug CARD]", {
            classes: classes,
            priceSel: price_sel,
            priceFound: foundPriceEl ? foundPriceEl.textContent.trim().substring(0, 30) : "NO",
            titleSel: title_sel,
            titleFound: title ? title.substring(0, 30) : "NO",
            renderSel: typeof to_render === 'string' ? to_render : to_render.sel
        });
    }
    
    if (!title || !price) {
        storeParsedTitleToElement(cardEl, null);
        return;
    }

    var parsedTitle = parseTitleWithPrice(title, price);
    var renderedPrice = renderBestPrice(parsedTitle, options.extra_style);

    var to_render_sel = "";
    var to_render_pos = "after";
    if (typeof to_render === "string") {
        to_render_sel = to_render;
    } else {
        to_render_sel = to_render.sel;
        to_render_pos = to_render.pos || to_render_pos;
    }

    var to_render_els = price_root.querySelectorAll(to_render_sel);
    for (var i = 0; i < to_render_els.length; i++) {
        var el = to_render_els[i];
        if (!el || !el.parentElement) continue;
        var existingPrices = el.parentElement.querySelectorAll("." + BEST_PRICE_CLASS_NAME);
        for (var j = 0; j < existingPrices.length; j++) {
            existingPrices[j].remove();
        }
    }

    var idx = 0;
    for (var i = 0; i < to_render_els.length; i++) {
        var el = to_render_els[i];
        if (!el) continue;
        var r = renderedPrice;
        if (idx > 0) {
            r = renderedPrice.cloneNode(true);
        }
        if (el && el[to_render_pos] && typeof el[to_render_pos] === 'function') {
            try {
                el[to_render_pos](r);
            } catch (e) {}
        }
        idx += 1;
    }
    storeParsedTitleToElement(cardEl, parsedTitle);
}

// ===== BEST PRICE REORDER =====

// Ключ для хранения выбора сортировки в рамках текущего поиска/каталога.
// Привязка к URL (pathname + текст запроса) позволяет:
//   — сохранять выбор при листании вниз (перезапуски initReorderCatalog на той же странице);
//   — сбрасывать выбор при новом поиске/категории (URL меняется).
// Хранение в sessionStorage даёт сброс при открытии новой вкладки.
function getCatalogSortStorageKey() {
    try {
        var u = new URL(window.location.href);
        var key = u.pathname;
        var text = u.searchParams.get('text');
        if (text) key += '?text=' + text;
        return key;
    } catch (e) {
        return window.location.pathname;
    }
}

function initReorderCatalog(catalogRoot, buttonRoot) {
    if (!config.bestPriceEnabled) {
        dbg("[SYSTEM] initReorderCatalog: bestPrice disabled");
        return;
    }
    if (!catalogRoot || !buttonRoot) {
        dbg("[SYSTEM] initReorderCatalog: no root", !!catalogRoot, !!buttonRoot);
        return;
    }
    
    var buttonWrap = buttonRoot;
    if (!buttonWrap) {
        dbg("[SYSTEM] initReorderCatalog: no buttonWrap");
        return;
    }

    var catalogRecords = [];
    var i = 0;
    var children;
    try {
        children = catalogRoot.querySelectorAll(":scope > *");
        dbg("[SYSTEM] initReorderCatalog: children count =", children ? children.length : 0);
    } catch (e) {
        dbg("[SYSTEM] initReorderCatalog: querySelector error", e);
        return;
    }
    
    if (!children || children.length === 0) {
        dbg("[SYSTEM] initReorderCatalog: no children, tag=" + catalogRoot.tagName + " class=" + catalogRoot.className);
        return;
    }
    
    dbg("[SYSTEM] initReorderCatalog: starting, first child class=" + (children[0] ? children[0].className : "none"));
    
    for (var j = 0; j < children.length; j++) {
        var wrapEl = children[j];
        var el = wrapEl.classList.contains(BEST_PRICE_WRAP_CLASS_NAME) ? wrapEl : wrapEl.querySelector("." + BEST_PRICE_WRAP_CLASS_NAME);
        if (!el) continue;
        var ds = loadParsedTitleFromElement(el);
        if (!ds) ds = {};
        if (!ds.initial_order) ds.initial_order = "0";

        var isOutOfStock = wrapEl.textContent.indexOf("Нет в наличии") !== -1
            || wrapEl.textContent.indexOf("нет в наличии") !== -1
            || wrapEl.textContent.indexOf("Нет на складе") !== -1
            || wrapEl.textContent.indexOf("Out of stock") !== -1
            || wrapEl.textContent.indexOf("Товар отсутствует") !== -1;

        i += 1;
        var initial_order = parseInt(ds.initial_order || "0", 10);
        if (!initial_order) {
            initial_order = i;
            ds.initial_order = i.toString();
            storeDataToElement(el, { initial_order: i });
        }
        var record = {
            el: wrapEl,
            initial_order: initial_order,
            weight_price: isOutOfStock ? MAX_NUMBER : (ds.units && ds.units[0] && ds.units[0].price ? ds.units[0].price : MAX_NUMBER),
            quantity_price: isOutOfStock ? MAX_NUMBER : (ds.quantity_price ? ds.quantity_price : MAX_NUMBER)
        };
        catalogRecords.push(record);
    }

    if (catalogRecords.length === 0) return;

    var buttonStyle = [
        "border: 2px solid #666 !important;",
        "padding: 6px 12px !important;",
        "margin: 2px !important;",
        "cursor: pointer !important;",
        "background: #ffffff !important;",
        "color: #333333 !important;",
        "font-size: 12px !important;",
        "font-weight: 600 !important;",
        "border-radius: 4px !important;",
        "transition: all 0.2s ease !important;",
        "min-width: 70px !important;",
        "box-shadow: 0 1px 2px rgba(0,0,0,0.1) !important;",
        "line-height: 1.4 !important;",
        "font-family: Arial, sans-serif !important;",
        "white-space: nowrap !important;"
    ].join(" ");

    var buttons = {};
    buttons.scroll_page = E("button", {
        "class": BEST_ORDER_BUTTON_CLASS_NAME,
        "style": buttonStyle,
        "title": "Прокрутить страницу вниз для подгрузки товаров"
    }, ["⬇ Скролл"]);
    
    buttons.initial_order = E("button", {
        "class": BEST_ORDER_BUTTON_CLASS_NAME,
        "style": buttonStyle,
        "title": "Вернуть исходный порядок"
    }, ["↺ Сброс"]);
    
    buttons.weight_price = E("button", {
        "class": BEST_ORDER_BUTTON_CLASS_NAME,
        "style": buttonStyle,
        "title": "Сортировка по цене за кг/л"
    }, ["⚖ По весу"]);
    
    buttons.quantity_price = E("button", {
        "class": BEST_ORDER_BUTTON_CLASS_NAME,
        "style": buttonStyle,
        "title": "Сортировка по цене за штуку"
    }, ["🔢 По шт."]);

    function scrollAndReturn() {
        var sec = config.scrollDurationSec || 3;
        var startY = window.scrollY;
        var totalDuration = sec * 1000;
        var startTime = Date.now();
        var btn = buttons.scroll_page;
        var originalText = btn.textContent;
        btn.textContent = "⬇ " + sec + "с...";
        btn.disabled = true;

        // Агрессивный скролл: большой прыжок за тик (~1.5 экрана), не зависит от FPS страницы
        var jumpSize = Math.max(Math.round(window.innerHeight * 1.5), 800);
        var timer = null;

        function finish() {
            if (timer) clearInterval(timer);
            window.scrollTo({ top: startY, behavior: 'auto' });
            btn.textContent = originalText;
            btn.disabled = false;
        }

        timer = setInterval(function() {
            var elapsed = Date.now() - startTime;
            if (elapsed >= totalDuration) {
                finish();
                return;
            }

            var doc = document.documentElement;
            var maxScroll = doc.scrollHeight - window.innerHeight;

            // Упёрлись в низ загруженного контента — ждём подгрузку (следующий тик)
            if (window.scrollY >= maxScroll - 10) {
                return;
            }

            window.scrollBy(0, jumpSize);
        }, 30);
    }

    function buttonClickHandler(orderState) {
        if (orderState === 'scroll_page') {
            scrollAndReturn();
            return;
        }
        // Сохраняем выбор только для текущего поиска/каталога (по ключу URL).
        // При новом поиске/категории/вкладке ключ меняется — выбор сбрасывается.
        try {
            sessionStorage.setItem('GM-catalog-sort:' + getCatalogSortStorageKey(), orderState);
        } catch (e) {}
        sort(catalogRecords, orderState);
        if (orderState === 'initial_order') {
            resetCatalogOrder();
        } else {
            reorderActive = true;
            refreshCatalog();
        }
        setActiveButton(buttons[orderState]);
    }

    // Сброс сортировки: снимаем order у карточек, возвращаем исходный порядок.
    // DOM не переставляем, display контейнера не трогаем.
    function resetCatalogOrder() {
        reorderActive = false;
        var wrap = catalogRoot;
        if (!wrap) return;
        for (var i = 0; i < catalogRecords.length; i++) {
            var el = catalogRecords[i].el;
            el.style.order = '';
        }
        // Новые карточки (не в catalogRecords) тоже снимаем order
        var children = wrap.children;
        for (var j = 0; j < children.length; j++) {
            var child = children[j];
            if (child.style && child.style.order) {
                child.style.order = '';
            }
        }
    }

    for (var k in buttons) {
        if (buttons.hasOwnProperty(k)) {
            var b = buttons[k];
            if (k === 'scroll_page') {
                b.onclick = function() { buttonClickHandler('scroll_page'); };
            } else {
                b.onclick = (function(state) {
                    return function() { buttonClickHandler(state); };
                })(k);
            }
            b.onmouseover = function() {
                if (!this.classList.contains('active')) {
                    this.style.background = '#f0f0f0';
                    this.style.borderColor = '#888';
                    this.style.transform = 'translateY(-1px)';
                }
            };
            b.onmouseout = function() {
                if (!this.classList.contains('active')) {
                    this.style.background = '#ffffff';
                    this.style.borderColor = '#666';
                    this.style.transform = 'none';
                }
            };
        }
    }

    // Флаг: активна ли сортировка (не «Сброс»). Если да — контейнер становится
    // flex и карточкам выставляется CSS order. DOM не переставляется, поэтому
    // React-события на карточках (стрелки листания фото, тултипы) сохраняются.
    var reorderActive = false;

    // Восстанавливаем выбор сортировки, если пользователь уже выбрал его
    // для ЭТОГО поиска/каталога — листание вниз не должно сбрасывать.
    // Новый поиск/категория/вкладка = новый ключ = по умолчанию «Сброс».
    var savedOrder = null;
    try {
        savedOrder = sessionStorage.getItem('GM-catalog-sort:' + getCatalogSortStorageKey());
    } catch (e) {}
    if (savedOrder && savedOrder !== 'initial_order' && buttons[savedOrder]) {
        buttonClickHandler(savedOrder);
    } else {
        setActiveButton(buttons.initial_order);
    }

    // Наблюдаем за подгрузкой новых карточек (скролл): если сортировка активна,
    // применяем order к новым элементам, чтобы они не «выпадали» из порядка.
    // DOM не переставляем — только CSS order, React-события не ломаются.
    if (!window.__gmCatalogOrderObserver) {
        var reorderTimer = null;
        window.__gmCatalogOrderObserver = new MutationObserver(function() {
            if (reorderTimer) return;
            reorderTimer = setTimeout(function() {
                reorderTimer = null;
                if (typeof refreshCatalog === 'function') refreshCatalog();
            }, 100);
        });
        try {
            window.__gmCatalogOrderObserver.observe(catalogRoot, {
                childList: true,
                subtree: true
            });
        } catch (e) {}
    }

    function refreshCatalog() {
        var wrap = catalogRoot;
        if (!wrap) return;
        if (!reorderActive) return;

        // НЕ трогаем display контейнера — у Ozon там своя раскладка
        // (grid/flex плитки). CSS order работает в обоих случаях и не ломает
        // вёрстку карточек. DOM не переставляем — React-события сохраняются.

        // Известным карточкам — order по позиции в отсортированном списке
        for (var i = 0; i < catalogRecords.length; i++) {
            var el = catalogRecords[i].el;
            el.style.order = String(i);
        }

        // Новые карточки (добавленные после скролла, ещё не в catalogRecords) —
        // ставим в конец (после отсортированных)
        var known = {};
        for (var k = 0; k < catalogRecords.length; k++) {
            known[catalogRecords[k].el] = true;
        }
        var children = wrap.children;
        var extraOrder = catalogRecords.length;
        for (var j = 0; j < children.length; j++) {
            var child = children[j];
            if (!known[child]) {
                child.style.order = String(extraOrder);
                extraOrder++;
            }
        }
    }

    function setActiveButton(button) {
        if (!button) return;
        for (var k in buttons) {
            if (buttons.hasOwnProperty(k)) {
                var b = buttons[k];
                b.classList.remove("active");
                b.style.background = '#ffffff';
                b.style.borderColor = '#666';
                b.style.borderWidth = '2px';
                b.style.boxShadow = '0 1px 2px rgba(0,0,0,0.1)';
                b.style.transform = 'none';
            }
        }
        button.classList.add("active");
        button.style.background = '#ffebee';
        button.style.borderColor = '#e53935';
        button.style.borderWidth = '2px';
        button.style.boxShadow = '0 0 10px rgba(229, 57, 53, 0.2)';
    }

    try {
        var existingButtonWrap = buttonWrap.querySelector("." + BEST_ORDER_BUTTON_CLASS_NAME + "-wrap");
        if (existingButtonWrap) {
            existingButtonWrap.remove();
        }
        
        var containerStyle = [
            "display: inline-flex !important;",
            "gap: 4px !important;",
            "padding: 6px 10px !important;",
            "background: #f8f9fa !important;",
            "border-radius: 6px !important;",
            "margin: 5px 0 !important;",
            "flex-wrap: wrap !important;",
            "align-items: center !important;",
            "border: 1px solid #e0e0e0 !important;",
            "box-shadow: 0 1px 2px rgba(0,0,0,0.05) !important;",
            "position: relative !important;",
            "max-width: 100% !important;",
            "width: auto !important;"
        ].join(" ");
        
        var buttonValues = [];
        for (var k in buttons) {
            if (buttons.hasOwnProperty(k)) {
                buttonValues.push(buttons[k]);
            }
        }
        
        var buttonDiv = E("div", { 
            "class": BEST_ORDER_BUTTON_CLASS_NAME + "-wrap",
            "style": containerStyle
        }, buttonValues);
        
        var label = document.createElement("span");
        label.textContent = "📊 Сортировка: ";
        label.style.cssText = [
            "font-weight: 600 !important;",
            "margin-right: 6px !important;",
            "font-size: 12px !important;",
            "color: #555 !important;",
            "font-family: Arial, sans-serif !important;",
            "white-space: nowrap !important;"
        ].join(" ");
        buttonDiv.prepend(label);
        
        if (buttonWrap && buttonWrap.appendChild) {
            buttonWrap.innerHTML = '';
            buttonWrap.style.cssText = [
                "display: block !important;",
                "width: auto !important;",
                "max-width: 100% !important;",
                "margin: 0 !important;",
                "padding: 0 !important;",
                "background: transparent !important;",
                "border: none !important;",
                "box-shadow: none !important;"
            ].join(" ");
            buttonWrap.appendChild(buttonDiv);
        }
    } catch (e) {
        dbg('[SYSTEM] initReorderCatalog: error appending buttons', e);
    }
}
