// ===== STORE: OZON =====
// Вся логика для Ozon: сортировка отзывов, Best Price на карточке товара и в каталоге

// OZON: Добавление параметра сортировки в URL
function ozonAddSortParam(url) {
    if (!url) return url;
    
    if (url.indexOf('sort=score_asc') !== -1 || url.indexOf('sort=score_desc') !== -1) {
        return url;
    }
    
    try {
        var fullUrl = url;
        if (url.charAt(0) === '/') {
            fullUrl = window.location.origin + url;
        }
        
        var urlObj = new URL(fullUrl);
        urlObj.searchParams.set('sort', 'score_asc');
        
        if (url.charAt(0) === '/') {
            return urlObj.pathname + urlObj.search + urlObj.hash;
        }
        return urlObj.toString();
    } catch (e) {
        if (url.indexOf('?') !== -1) {
            return url + '&sort=score_asc';
        } else {
            return url + '?sort=score_asc';
        }
    }
}

// OZON: Модификатор URL для перехвата ссылок
function ozonUrlModifier(url) {
    if (typeof url !== 'string') return url;
    
    // Если опция "Переход к отзывам" выключена — не трогаем ссылки на отзывы,
    // оставляем Ozon сам скроллить к отзывам
    if (!config.ozonRedirectToReviews && (url.indexOf('/reviews') !== -1 || url.indexOf('/feedbacks') !== -1)) {
        return url;
    }
    
    if (url.indexOf('/product/') !== -1 && url.indexOf('sort=score_asc') === -1 && url.indexOf('sort=score_desc') === -1) {
        return ozonAddSortParam(url);
    }
    return url;
}

function ozonInitProductPage() {
    // Метка страницы товара: flex-выравнивание блока цены применяется
    // только здесь (не на поиске/каталоге, где это растягивает карточку)
    try {
        document.documentElement.classList.add('gm-ozon-product');
    } catch (e) {}

    setupLinkInterception({
        linkSelectors: 'a[href^="/product/"]',
        urlModifier: ozonUrlModifier,
        dataAttr: 'ozonIntercepted'
    });

    // Скрываем fintech-рекламу в самом начале (работает и без контейнера)
    ozonApplyFintechHidden();

    // Скрываем счётчик сообщений (если включено)
    if (config.ozonHideMessageCounter) {
        ozonApplyMessageCounterHidden();
    }

    // Перемещаем блок «Магазин» над «Доставкой и возвратом» (если включено).
    // Запуск максимально ранний (document_start, observer стартует в content.js) —
    // блоки ловятся в момент добавления в DOM, до первого paint, без «прыжка»
    // на глазах у пользователя. Здесь дополнительно пробуем ещё раз на случай,
    // если ранний observer что-то пропустил.
    if (config.ozonMoveStoreAboveDelivery) {
        ozonMoveStoreAboveDelivery();
        ozonStartMoveStoreObserver();
    }

    var productRoot = document.querySelector('[data-widget="container"]');
    if (!productRoot) return;

    if (config.sortReviewsEnabled) {
        var webToAppBanner = document.querySelector('div[data-widget="webToAppBanner"]');
        if (webToAppBanner) webToAppBanner.style.display = 'none';
        
        var skuGrids = document.querySelectorAll('div[data-widget="skuGrid"]');
        for (var i = 0; i < skuGrids.length; i++) { skuGrids[i].remove(); }
        
        var banners = document.querySelectorAll('div[data-widget="bannerCarousel"]');
        for (var i = 0; i < banners.length; i++) { banners[i].remove(); }
        
        var ReviewsFoto = document.querySelector("#layoutPage > div.b2 > div:nth-child(7) > div > div.container.b6 > div:nth-child(1)");
        if (ReviewsFoto) ReviewsFoto.style.display = 'none';
    }

    // ===== СКРЫТИЕ РЕКЛАМНЫХ БЛОКОВ =====
    // Блоки скрываются CSS через классы на <html> (см. content.css, content.js).
    // Здесь дополнительно ищем блоки по заголовкам («Рекомендуем также»,
    // «Покупают вместе» и т.п.) и ставим на контейнеры атрибут-маркер,
    // который скрывается CSS — это не зависит от меняющихся data-widget.
    ozonApplySectionHidden();

    if (config.bestPriceEnabled) {
        var titleEl = document.querySelector("[data-widget='webProductHeading']");
        var title = titleEl ? titleEl.textContent : null;

        // Fallback заголовка: если webProductHeading не найден (Ozon меняет
        // data-widget), берём h1 — он есть на любой карточке товара
        if (!title) {
            var h1 = document.querySelector("h1");
            if (h1) title = h1.textContent;
        }
        if (!title) return;

        processProductCard(productRoot, {
            // Реальная цена: крупный span с актуальной ценой в контейнере цены.
            // Варианты вёрстки Ozon (меняются со временем):
            //   — div.pdp_gb4.pdp_gb3 > span.tsHeadline600Large (цена без скидки, «С банками», новая вёрстка)
            //   — div.pdp_g2b > div > span.tsHeadline600Large (цена без скидки, старая вёрстка)
            //   — div.c35_5_1-a0 > span.tsHeadline500Medium (цена со скидкой, старая вёрстка)
            //   — div.c35_5_2-a0 > span.tsHeadline500Medium (цена со скидкой, новая вёрстка)
            // Ищем по всей странице (price_root = document) — цена может быть
            // вне [data-widget="container"]
            price_sel: 'div.pdp_gb4.pdp_gb3 > span.tsHeadline600Large, div.pdp_g2b > div > span.tsHeadline600Large, div.c35_5_1-a0 > span.tsHeadline500Medium, div.c35_5_2-a0 > span.tsHeadline500Medium, [data-widget="webOzonAccountPrice"], [data-widget="webPrice"]',
            title_sel: '[data-widget="webProductHeading"]',
            price_root: document,
            to_render: {
                // Вставляем блок сразу после реальной цены (первого span),
                // чтобы он был в той же строке, перед старой ценой и скидкой
                sel: 'div.pdp_gb4.pdp_gb3 > span.tsHeadline600Large, div.pdp_g2b > div > span.tsHeadline600Large, div.c35_5_1-a0 > span.tsHeadline500Medium, div.c35_5_2-a0 > span.tsHeadline500Medium, [data-widget="webOzonAccountPrice"]',
                pos: "after"
            },
            force: false
        });
    }
}

// Универсальное скрытие fintech-рекламы Ozon по текстовым маркерам.
// Селекторы Ozon меняются часто, а тексты маркеров («Оплатить позже»,
// «Без переплат», «Купить сейчас») стабильны.
function ozonApplyFintechHidden() {
    var groups = [
        ['Оплатить позже', 'Без переплат', 'частями на 6', 'частично на 6'],
        ['Покупайте за 1'],
        ['Купить сейчас']
    ];
    var shouldHide = config.ozonHideFintech !== false;

    // Блоки, которые уже обработали (чтобы не трогать повторно)
    var processed = new WeakSet();

    function isBig(el) {
        if (!el || !el.getBoundingClientRect) return false;
        try {
            var r = el.getBoundingClientRect();
            if (r.width > 700 || r.height > 500) return true;
        } catch (e) {}
        // На раннем рендере размеры 0 — считаем крупным контейнером элемент
        // с большим числом вложенных виджетов (карточка/секция)
        try {
            if (el.querySelectorAll && el.querySelectorAll('[data-widget]').length >= 5) return true;
        } catch (e) {}
        return false;
    }

    function hideBlock(el) {
        if (!el || processed.has(el)) return;
        if (el === document.documentElement || el === document.body) return;
        if (isBig(el)) return; // не скрываем крупные контейнеры
        processed.add(el);
        if (shouldHide) {
            el.style.display = 'none';
        } else {
            el.style.display = '';
        }
    }

    // Поиск самых глубоких элементов с маркером
    function findLeavesByText(marker) {
        var leaves = [];
        var xpath = "//*[text()[contains(., '" + marker + "')]]";
        try {
            var xr = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
            for (var i = 0; i < xr.snapshotLength; i++) {
                var el = xr.snapshotItem(i);
                if (!el) continue;
                if (el === document.documentElement || el === document.body) continue;
                leaves.push(el);
            }
        } catch (e) {}
        return leaves;
    }

    // Общий предок набора элементов
    function commonAncestor(nodes) {
        if (!nodes.length) return null;
        var node = nodes[0];
        while (node && node !== document.documentElement) {
            var all = true;
            for (var i = 1; i < nodes.length; i++) {
                if (!node.contains(nodes[i])) { all = false; break; }
            }
            if (all) return node;
            node = node.parentElement;
        }
        return null;
    }

    // Подъём к контейнеру виджета: стоп на крупных контейнерах и на любом
    // data-widget, который НЕ является известным финтех-виджетом
    // (это корень карточки/секции — его нельзя скрывать!)
    var FINTECH_WIDGETS = ['webPricePerStars', 'webOneClickButton'];

    function raiseToContainer(start) {
        var target = null;
        var cur = start;
        for (var i = 0; i < 5 && cur && cur.parentElement; i++) {
            var parent = cur.parentElement;
            if (parent === document.body || parent === document.documentElement) return null;
            if (isBig(parent)) return null;
            var widget = parent.getAttribute && parent.getAttribute('data-widget');
            var style = (parent.getAttribute && parent.getAttribute('style')) || '';
            if (/background(-color)?\s*:/i.test(style)) {
                return parent;
            }
            if (widget) {
                if (FINTECH_WIDGETS.indexOf(widget) !== -1) return parent;
                return null;
            }
            cur = parent;
        }
        return target;
    }

    // 1) Обрабатываем каждую группу маркеров
    for (var g = 0; g < groups.length; g++) {
        var markers = groups[g];
        var allLeaves = [];
        var found = false;
        for (var m = 0; m < markers.length; m++) {
            var leaves = findLeavesByText(markers[m]);
            if (leaves.length) {
                found = true;
                allLeaves = allLeaves.concat(leaves);
            }
        }
        if (!found) continue;

        var start = allLeaves.length > 1 ? commonAncestor(allLeaves) : allLeaves[0];
        if (!start) continue;

        if (isBig(start)) {
            for (var li = 0; li < allLeaves.length; li++) {
                hideBlock(raiseToContainer(allLeaves[li]));
            }
            continue;
        }

        var container = raiseToContainer(start);
        hideBlock(container);
    }

    // 2) Поиск по известным селекторам (если верстка не менялась)
    var known = [
        '[data-widget="webPricePerStars"]',
        '[data-widget="webOneClickButton"]',
        '[data-widget="webPdpGrid"] [data-widget="webPricePerStars"]',
        'a[href*="multipromoCreditProduct"]'
    ];
    for (var k = 0; k < known.length; k++) {
        var nodes2 = document.querySelectorAll(known[k]);
        for (var n = 0; n < nodes2.length; n++) {
            hideBlock(nodes2[n]);
        }
    }

    // 3) MutationObserver: Ozon подгружает виджеты SPA-способом,
    //    повторяем поиск при добавлении новых узлов (с debounce)
    if (!window.__gmOzonFintechObserver) {
        var obsTimer = null;
        window.__gmOzonFintechObserver = new MutationObserver(function(mutations) {
            if (obsTimer) return;
            obsTimer = setTimeout(function() {
                obsTimer = null;
                ozonApplyFintechHidden();
            }, 200);
        });
        try {
            window.__gmOzonFintechObserver.observe(document.body, {
                childList: true,
                subtree: true
            });
        } catch (e) {}
    }

    return true;
}

// ===== СКРЫТИЕ СЕКЦИЙ OZON ПО ЗАГОЛОВКАМ =====
// Скрывает «Рекомендуем также», «Покупают вместе», «Подборки товаров» и т.п.
// Селекторы data-widget на Ozon меняются при каждом релизе, поэтому блоки
// ищем по стабильным текстам заголовков. Контейнеру секции ставим
// атрибут data-gm-hidden-section="<ключ>", а CSS (html.gm-ozon-hide-* [data-gm-hidden-section="..."])
// скрывает его. Настройка применяется мгновенно (без обновления страницы).
function ozonApplySectionHidden() {
    try {
        var groups = [
            { keys: ['ozonHideRecommended'], names: ['Рекомендуем также', 'Рекомендуем для вас', 'Похожие товары'], attr: 'rec' },
            { keys: ['ozonHideTogether'], names: ['Покупают вместе', 'Часто покупают вместе', 'С этим товаром покупают'], attr: 'tog' },
            { keys: ['ozonHideCollections'], names: ['Подборки товаров', 'Подборки', 'Подборка'], attr: 'col' }
        ];

        // Все известные заголовки секций (для распознавания общего контейнера)
        var allNames = [];
        for (var gi = 0; gi < groups.length; gi++) {
            allNames = allNames.concat(groups[gi].names);
        }

        // Убираем маркеры, которые больше не актуальны (выключено) —
        // чтобы при выключении настройки блоки снова появились
        var currentAttrs = ['rec', 'tog', 'col'];
        for (var a = 0; a < currentAttrs.length; a++) {
            var old = document.querySelectorAll('[data-gm-hidden-section="' + currentAttrs[a] + '"]');
            for (var oi = 0; oi < old.length; oi++) {
                old[oi].removeAttribute('data-gm-hidden-section');
            }
        }

        for (var g = 0; g < groups.length; g++) {
            var group = groups[g];
            var shouldHide = true;
            for (var k = 0; k < group.keys.length; k++) {
                if (config[group.keys[k]] === false) { shouldHide = false; break; }
            }
            if (!shouldHide) continue;

            var headers = document.querySelectorAll('div, span, h1, h2, h3, h4, p');
            for (var h = 0; h < headers.length; h++) {
                var headerEl = headers[h];
                if (headerEl.childElementCount !== 0) continue;
                var t = (headerEl.textContent || '').replace(/\s+/g, ' ').trim();
                if (!t) continue;
                var matched = false;
                for (var n = 0; n < group.names.length; n++) {
                    if (t === group.names[n]) { matched = true; break; }
                }
                if (!matched) continue;

                // Поднимаемся до контейнера секции: ближайший предок с несколькими
                // дочерними элементами (заголовок + контент). Секцией может быть
                // и широкий блок (например data-widget="tileScrollDesktop" —
                // карусель «Рекомендуем также»/«Покупают вместе» занимает всю
                // колонку), поэтому НЕ ограничиваем по ширине. Если найденный
                // контейнер содержит ещё один заголовок наших секций — значит это
                // общий контейнер страницы, и берём последний кандидат (саму секцию).
                var section = null;
                var candidate = headerEl;
                var cur = headerEl.parentElement;
                for (var s = 0; s < 8 && cur && cur !== document.body && cur !== document.documentElement; s++) {
                    var childCount = 0;
                    for (var c = 0; c < cur.children.length; c++) {
                        if ((cur.children[c].textContent || '').trim()) childCount++;
                    }
                    if (childCount >= 2) {
                        var otherCount = ozonCountSectionHeadersIn(cur, allNames, headerEl);
                        if (otherCount > 0) {
                            section = candidate !== headerEl ? candidate : null;
                        } else {
                            section = cur;
                        }
                        break;
                    }
                    candidate = cur;
                    cur = cur.parentElement;
                }
                if (!section) continue;
                if (section === document.body || section === document.documentElement) continue;

                section.setAttribute('data-gm-hidden-section', group.attr);
            }
        }

        // Ozon подгружает секции SPA-способом — повторяем поиск при добавлении
        // новых узлов (с debounce), чтобы скрыть блоки, появившиеся позже
        if (!window.__gmOzonSectionObserver) {
            var secTimer = null;
            window.__gmOzonSectionObserver = new MutationObserver(function() {
                if (secTimer) return;
                secTimer = setTimeout(function() {
                    secTimer = null;
                    ozonApplySectionHidden();
                }, 150);
            });
            try {
                window.__gmOzonSectionObserver.observe(document.body, {
                    childList: true,
                    subtree: true
                });
            } catch (e) {}
        }
    } catch (e) {}
}

// Сколько заголовков секций (из allNames) содержится внутри root, кроме excludeEl.
// Используется, чтобы отличить контейнер самой секции от общего контейнера страницы.
function ozonCountSectionHeadersIn(root, allNames, excludeEl) {
    var count = 0;
    if (!root || !root.querySelectorAll) return 0;
    var els = root.querySelectorAll('div, span, h1, h2, h3, h4, p');
    for (var i = 0; i < els.length; i++) {
        var el = els[i];
        if (el === excludeEl) continue;
        if (el.childElementCount !== 0) continue;
        var t = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (!t) continue;
        for (var n = 0; n < allNames.length; n++) {
            if (t === allNames[n]) { count++; break; }
        }
    }
    return count;
}

// Перемещает блок «Магазин» (шапка + название магазина + рейтинг) над
// блоком «Доставка и возврат». Поиск — по ТЕКСТОВЫМ маркерам и структуре,
// а не по обфусцированным классам Ozon (те меняются при каждом релизе).
// Карточка магазина опознаётся по названию (span.b35_5_3-b7) — этот класс
// стабилен на Ozon и уже использовался в прежних версиях расширения.
function ozonMoveStoreAboveDelivery() {
    try {
        var deliveryHeader = ozonFindSectionHeader(['Доставка и возврат']);
        if (!deliveryHeader) return false;

        var storeHeader = ozonFindStoreHeader();
        if (!storeHeader) return false;

        var deliveryBlock = ozonFindDeliveryBlock(deliveryHeader, storeHeader);
        if (!deliveryBlock) return false;

        return ozonMoveStoreUnit(storeHeader, deliveryBlock);
    } catch (e) {
        return false;
    }
}

// Перемещает «единицу магазина» перед блоком доставки.
// Вёрстка Ozon: шапка «Магазин» (div.pdp_a0m) и карточка продавца
// (div.pdp_a1m: название, рейтинг, бренды) — соседние элементы (siblings)
// в общем контейнере колонки, ниже которого идёт блок доставки.
// Переносится диапазон [шапка .. карточка].
function ozonMoveStoreUnit(storeHeader, deliveryBlock) {
    var items = [];

    // Контейнер шапки: ближайший предок заголовка, после которого
    // (nextElementSibling) идёт карточка магазина — элемент с названием
    // .b35_5_3-b7 или ссылкой на продавца /seller/
    var wrap = null;
    var cur = storeHeader.parentElement;
    for (var i = 0; i < 8 && cur && cur !== document.body && cur !== document.documentElement; i++) {
        var next = cur.nextElementSibling;
        if (next && next.querySelector &&
            (next.querySelector('.b35_5_3-b7') || next.querySelector('a[href*="/seller/"]'))) {
            wrap = cur;
            break;
        }
        cur = cur.parentElement;
    }

    // Собираем диапазон [шапка .. карточка] по соседям
    if (wrap) {
        var card = wrap.nextElementSibling;
        var el = wrap;
        var guard = 0;
        while (el && guard++ < 30) {
            items.push(el);
            if (el === card) break;
            el = el.nextElementSibling;
        }
        if (!items.length || items[items.length - 1] !== card) items = [];
    }

    // Fallback: общий контейнер, содержащий и шапку, и карточку
    if (!items.length) {
        var block = storeHeader;
        var cc = storeHeader.parentElement;
        for (var j = 0; j < 8 && cc && cc !== document.body && cc !== document.documentElement; j++) {
            if (deliveryBlock && cc.contains(deliveryBlock)) break;
            if (cc.querySelector && cc.querySelector('.b35_5_3-b7')) block = cc;
            cc = cc.parentElement;
        }
        if (block !== storeHeader) items = [block];
    }

    if (!items.length) return false;

    var parent = deliveryBlock.parentElement;
    if (!parent) return false;

    // Уже стоит перед блоком доставки — считаем успехом
    if (deliveryBlock.previousElementSibling === items[0]) return true;

    // Убираем вертикальные отступы у шапки и карточки, чтобы не было разрыва
    // между «Магазин / Подписаться» и карточкой с названием/рейтингом.
    for (var k = 0; k < items.length; k++) {
        var it = items[k];
        it.style.marginTop = '0';
        it.style.marginBottom = '0';
        parent.insertBefore(it, deliveryBlock);
    }

    // Если карточка (название магазина) имеет свой вертикальный отступ —
    // сбрасываем его тоже
    var cardEl = items[items.length - 1];
    if (cardEl && cardEl.querySelector && cardEl.querySelector('.b35_5_3-b7')) {
        cardEl.style.marginTop = '0';
    }
    return true;
}

// Ищет «заголовок» секции по точному тексту (элемент без дочерних элементов).
// Первый по порядку DOM — секция товара всегда выше футера/меню.
function ozonFindSectionHeader(names) {
    var all = document.querySelectorAll('div, span, h1, h2, h3, h4, p, button, a');
    for (var i = 0; i < all.length; i++) {
        var el = all[i];
        if (el.childElementCount !== 0) continue;
        var t = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (!t) continue;
        for (var n = 0; n < names.length; n++) {
            if (t === names[n]) return el;
        }
    }
    return null;
}

// Ищет шапку «Магазин» (заголовок секции). Приоритет — заголовок, после
// контейнера которого (nextElementSibling) идёт карточка продавца
// (.b35_5_3-b7 — название магазина, или ссылка /seller/).
// Это исключает «Магазин» в каталоге/футере и счётчик сообщений.
function ozonFindStoreHeader() {
    var headers = document.querySelectorAll('div, span, h1, h2, h3, h4, p, button, a');
    var fallback = null;
    for (var i = 0; i < headers.length; i++) {
        var el = headers[i];
        if (el.childElementCount !== 0) continue;
        var t = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (t !== 'Магазин' && t !== 'Продавец') continue;
        if (!fallback) fallback = el;

        var cur = el.parentElement;
        for (var j = 0; j < 8 && cur && cur !== document.body && cur !== document.documentElement; j++) {
            var next = cur.nextElementSibling;
            if (next && next.querySelector &&
                (next.querySelector('.b35_5_3-b7') || next.querySelector('a[href*="/seller/"]'))) {
                return el;
            }
            cur = cur.parentElement;
        }
    }
    return fallback;
}

// Блок доставки: поднимаемся от заголовка «Доставка и возврат» до контейнера,
// который не содержит шапку магазина (т.е. не является общим колоночным).
function ozonFindDeliveryBlock(deliveryHeader, storeHeader) {
    if (!deliveryHeader) return null;
    var candidate = deliveryHeader;
    var cur = deliveryHeader.parentElement;
    for (var i = 0; i < 8 && cur && cur !== document.body && cur !== document.documentElement; i++) {
        if (storeHeader && cur.contains(storeHeader)) {
            // Общий контейнер колонки — берём последнюю секцию
            return candidate !== deliveryHeader ? candidate : null;
        }
        candidate = cur;
        cur = cur.parentElement;
    }
    return candidate !== deliveryHeader ? candidate : null;
}

// Запускает перемещение блока «Магазин» максимально рано — с document_start.
// Ozon рендерит страницу SPA-способом; ловим добавление блоков
// MutationObserver'ом, чтобы перемещение произошло ДО первого paint
// (без видимого «прыжка» у пользователя).
// После успешного перемещения для текущего URL больше не сканируем
// (сбрасывается при SPA-переходе на другой товар).
function ozonStartMoveStoreObserver() {
    if (!config.ozonMoveStoreAboveDelivery) return;
    if (window.__gmOzonMoveStoreObserverEarly) return;
    // Перемещение нужно только на странице товара
    if (window.location.pathname.indexOf('/product/') !== 0) return;

    var observer = new MutationObserver(function() {
        try {
            if (!config.ozonMoveStoreAboveDelivery) return;
            var key = window.location.pathname + window.location.search;
            if (window.__gmOzonStoreMovedKey === key) return;
            if (ozonMoveStoreAboveDelivery()) {
                window.__gmOzonStoreMovedKey = key;
            }
        } catch (e) {}
    });
    window.__gmOzonMoveStoreObserverEarly = observer;

    function tryObserve() {
        if (!document.body || !(document.body instanceof Node)) {
            setTimeout(tryObserve, 10);
            return;
        }
        try {
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        } catch (e) {}
    }
    tryObserve();
}

// Скрывает рекламные чаты на странице /my/chat Ozon.
// Элемент чата: [data-perf="chatItem"], название — внутри span.om_7inde--eOP1V.
// Список названий для скрытия хранится в настройке OzonAdChatNames (через запятую).
function ozonHideAdChats() {
    try {
        if (!config.ozonHideAdChats) return;
        var namesRaw = config.ozonAdChatNames || '';
        var names = namesRaw.split(',').map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 0; });
        if (!names.length) return;

        var items = document.querySelectorAll('[data-perf="chatItem"]');
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var nameEl = item.querySelector('.om_7inde--eOP1V');
            if (!nameEl) continue;
            var name = (nameEl.textContent || '').trim();
            for (var n = 0; n < names.length; n++) {
                if (name.indexOf(names[n]) !== -1) {
                    item.style.display = 'none';
                    break;
                }
            }
        }
    } catch (e) {}
}

// Скрывает счётчик непрочитанных сообщений Ozon (красный бейдж с числом).
// Ищем по уникальным признакам: классу cj01_2_8-a2, фону bgAccentPrimary,
// маленькому размеру и содержимому из цифр/плюса. Скрываем и срабатываем
// на изменениях DOM (SPA).
function ozonApplyMessageCounterHidden() {
    try {
        function hide(el) {
            if (el) el.style.display = 'none';
        }

        // 1) По известному классу (если вёрстка не менялась)
        var byClass = document.querySelectorAll('.cj01_2_8-a2');
        for (var i = 0; i < byClass.length; i++) hide(byClass[i]);

        // 2) По фону bgAccentPrimary (уникальный акцентный фон счётчика)
        var all = document.querySelectorAll('div[style*="bgAccentPrimary"]');
        for (var j = 0; j < all.length; j++) hide(all[j]);

        // 3) Универсальный поиск: маленький элемент, чей текст — цифры (или "+"),
        //    и у которого рядом фон bgAccentPrimary (родитель или сам элемент)
        var candidates = document.querySelectorAll('div, span');
        for (var k = 0; k < candidates.length; k++) {
            var el = candidates[k];
            var txt = (el.textContent || '').trim();
            if (!txt || txt.length > 4) continue;
            if (!/^[0-9+\s]+$/.test(txt)) continue;
            var style = (el.getAttribute && el.getAttribute('style')) || '';
            var parentStyle = (el.parentElement && el.parentElement.getAttribute && el.parentElement.getAttribute('style')) || '';
            if (style.indexOf('bgAccentPrimary') !== -1 || parentStyle.indexOf('bgAccentPrimary') !== -1) {
                hide(el);
            }
        }
    } catch (e) {}
}

function ozonProcessProductCardOld(cardEl) {
    if (!config.bestPriceEnabled) return;
    if (!cardEl) return;
    
    var wrapEl = getElementByXpath("(a|div/a)/following-sibling::div[1]", cardEl);
    if (!wrapEl || wrapEl.querySelector(".GM-best-price")) {
        storeParsedTitleToElement(cardEl, null);
        return;
    }

    // Цена: новый селектор реальной цены (span.tsHeadline500Medium в div.c35_5_1-a0
    // — старая вёрстка, div.c35_5_2-a0 — новая вёрстка),
    // fallback — старый парсинг из wrapEl, затем универсальный поиск
    // первого span с числом и символом «₽» (покрывает страницу продавца /seller/)
    var price = null;
    var priceAnchorEl = cardEl.querySelector('div.c35_5_1-a0 > span.tsHeadline500Medium, div.c35_5_2-a0 > span.tsHeadline500Medium');
    if (priceAnchorEl) {
        price = getPriceFromElement(priceAnchorEl);
    }
    if (price === null) {
        price = getPriceFromElement(wrapEl.querySelector("div"));
    }
    if (price === null) {
        var priceSpans = cardEl.querySelectorAll('span');
        for (var ps = 0; ps < priceSpans.length; ps++) {
            var psText = (priceSpans[ps].textContent || '').trim();
            if (psText.indexOf('₽') !== -1 && /\d/.test(psText)) {
                var psPrice = getPriceFromElement(priceSpans[ps]);
                if (psPrice !== null) {
                    price = psPrice;
                    priceAnchorEl = priceSpans[ps];
                    break;
                }
            }
        }
    }

    var titleEl = wrapEl.querySelector("a span.tsBodyL, a span.tsBodyM:not([style]), a span.tsBodyM[style='color:;'], a span.tsBody500Medium");
    var title = titleEl ? titleEl.textContent : null;

    if (!title || !price) {
        storeParsedTitleToElement(cardEl, null);
        return;
    }

    var parsedTitle = parseTitleWithPrice(title, price);
    var bestPriceEl = renderBestPrice(parsedTitle);

    // Вставляем блок ПОСЛЕ реальной цены (в ту же строку), если нашли цену.
    // Иначе — fallback: после элемента с ценой внутри wrapEl
    var inserted = false;
    if (priceAnchorEl && priceAnchorEl.after && typeof priceAnchorEl.after === 'function') {
        try {
            priceAnchorEl.after(bestPriceEl);
            inserted = true;
        } catch (e) {}
    }
    if (!inserted) {
        var priceWrap = wrapEl.querySelector("div");
        if (priceWrap && priceWrap.after && typeof priceWrap.after === 'function') {
            try {
                priceWrap.after(bestPriceEl);
                inserted = true;
            } catch (e) {}
        }
    }
    if (!inserted && titleEl && titleEl.before && typeof titleEl.before === 'function') {
        try {
            titleEl.before(bestPriceEl);
            inserted = true;
        } catch (e) {}
    }
    storeParsedTitleToElement(cardEl, parsedTitle);
}

function ozonInitCatalog() {
    setupLinkInterception({
        linkSelectors: 'a[href^="/product/"]',
        urlModifier: ozonUrlModifier,
        dataAttr: 'ozonIntercepted'
    });

    // Скрываем fintech-рекламу и в каталоге
    ozonApplyFintechHidden();

    // Скрываем секции («Подборки» и т.п.) и в каталоге
    ozonApplySectionHidden();

    // Скрываем счётчик сообщений в шапке (если включено)
    if (config.ozonHideMessageCounter) {
        ozonApplyMessageCounterHidden();
    }

    if (!config.bestPriceEnabled) return;

    // Контейнер каталога для сортировки — пробуем несколько вариантов
    // (страница продавца /seller/ может иметь другой контейнер)
    var catalogSels = [
        "#contentScrollPaginator div[data-widget='tileGridDesktop'] > div:nth-child(1)",
        "#contentScrollPaginator div[data-widget='tileGridDesktop'] > div:first-child",
        ".widget-search-result-container > div:first-child",
        "[data-widget='searchResultsV2'] > div > div > div"
    ];
    var catalogEl = null;
    for (var cs = 0; cs < catalogSels.length; cs++) {
        catalogEl = document.querySelector(catalogSels[cs]);
        if (catalogEl) break;
    }
    if (!catalogEl) {
        dbg("[OZON debug] no catalogEl");
        return;
    }

    // Парсим все карточки — этот селектор находит сотни.
    // Дополнительно пытаемся взять прямых детей контейнера каталога
    // (покрывает страницу продавца /seller/ и другие вёрстки)
    var cardList = document.querySelectorAll(".widget-search-result-container > div > div, #contentScrollPaginator div[data-widget='tileGridDesktop'] > div > div, [data-widget='skuLine'] > div:nth-child(2) > div, [data-widget='skuGridSimple'] > div:nth-child(2) > div, [data-widget='skuGridSimple'] > div:nth-child(1) > div, [data-widget='skuLine'] > div:nth-child(1) > div, [data-widget='skuLineLR'] > div:nth-child(2) > div, [data-widget='skuGrid'][style] > div:nth-child(2) > div, [data-widget='skuGrid'] > div:nth-child(2) > div, [data-widget='skuGrid']:not([style]) > div:nth-child(1) > div, [data-widget='skuShelfGoods'] > div:nth-child(2) > div > div > div > div");
    if (cardList.length === 0 && catalogEl) {
        cardList = catalogEl.querySelectorAll(":scope > div");
    }
    dbg("[OZON debug] cardList count: " + cardList.length);

    for (var i = 0; i < cardList.length; i++) {
        try {
            ozonProcessProductCardOld(cardList[i]);
        } catch (e) {
            dbg("[OZON debug] old parse error:", e);
        }
    }

    // Контейнер для кнопок сортировки: #paginator или родитель каталога
    var paginatorEl = document.querySelector("#paginator");
    if (!paginatorEl) {
        paginatorEl = catalogEl.parentElement || catalogEl;
    }
    var buttonWrapEl = ElementGetOrCreate(paginatorEl, {
        className: "GM-button-wrap",
        pos: "before"
    });
    if (!buttonWrapEl) return;

    // Собираем все children из catalog в catalogEl (без innerHTML = "")
    // Используем все найденные контейнеры каталога (catalogSels)
    var allItems = [];
    for (var cs2 = 0; cs2 < catalogSels.length; cs2++) {
        var catalogNodes = document.querySelectorAll(catalogSels[cs2]);
        for (var cn = 0; cn < catalogNodes.length; cn++) {
            var items = catalogNodes[cn].querySelectorAll(":scope > div");
            for (var cj = 0; cj < items.length; cj++) {
                allItems.push(items[cj]);
            }
        }
    }
    
    // Перемещаем все items в catalogEl (просто append, не клонируем)
    for (var ai = 0; ai < allItems.length; ai++) {
        if (allItems[ai].parentNode !== catalogEl) {
            catalogEl.appendChild(allItems[ai]);
        }
    }

    if (buttonWrapEl) {
        initReorderCatalog(catalogEl, buttonWrapEl);
    }

    var paginator = document.querySelector('[data-widget="megaPaginator"] > div:nth-child(2)');
    var paginatorWrap = document.querySelector(".widget-search-result-container");
    if (paginator && paginator.querySelector("a") && paginatorWrap) {
        copyElementToNewRoot(paginator, paginatorWrap, { pos: "before" });
    }
}
