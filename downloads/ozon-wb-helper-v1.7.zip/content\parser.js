// ===== PARSER =====
// Парсинг названий товаров: вес, объём, количество, цена за единицу

var WORD_BOUNDARY_END = /(?=\s+|[.,);/]|[хx]|[^\u0400-\u04ff]|$)/;
var WEIGHT_REGEXP = mRegExp([
    /(?<value>\d+[,.]\d+|\d+)/,
    /\s?/,
    "(?<unit>",
    "(?<weight_unit>(?<weight_SI>кг|килограмм(?:ов|а|))|г|грамм(?:ов|а|)|гр)",
    "|(?<volume_unit>(?<volume_SI>л|литр(?:ов|а|))|мл)",
    "|(?<length_unit>(?<length_SI>м|метр(?:ов|а|)))",
    ")\\.?",
    WORD_BOUNDARY_END
]);

function plural(name, plurals) {
    if (!plurals) plurals = ["ок", "ки", "ка"];
    return name + "(?:" + plurals.join("|") + ")";
}

var QUANTITY_UNITS = [
    "шт", "рулон", "пакет", "уп",
    plural("упаков"), plural("салфет"),
    "таб", "капсул", plural("флакон", ["", "a", "ов"]),
    plural("пар", ["", "a", "ы"])
];

var QUANTITY_REGEXP = RegExp("(?<quantity>\\d+)\\s?(?<quantity_unit>" + QUANTITY_UNITS.join("|") + ")\\.?");
var QUANTITY_2_REGEXP = RegExp("(?<quantity_2>\\d+)\\s?(?<quantity_2_unit>" + QUANTITY_UNITS.join("|") + ")\\.?");
var COMBINE_DELIMETER_REGEXP = /\s*?(?:[xх*×/]|по)\s*?/;

var COMBINE_QUANTITY_LIST = [
    mRegExp([/(?<quantity_2>\d+)/, COMBINE_DELIMETER_REGEXP, QUANTITY_REGEXP]),
    mRegExp([QUANTITY_REGEXP, COMBINE_DELIMETER_REGEXP, /(?<quantity_2>\d+)/]),
    mRegExp([QUANTITY_2_REGEXP, COMBINE_DELIMETER_REGEXP, QUANTITY_REGEXP])
];

var COMBINE_QANTITY_WEIGHT_REGEXP_LIST = [
    mRegExp([WEIGHT_REGEXP, COMBINE_DELIMETER_REGEXP, QUANTITY_REGEXP]),
    mRegExp([QUANTITY_REGEXP, COMBINE_DELIMETER_REGEXP, WEIGHT_REGEXP]),
    mRegExp([/(?<quantity>\d+)/, COMBINE_DELIMETER_REGEXP, WEIGHT_REGEXP]),
    mRegExp([WEIGHT_REGEXP, COMBINE_DELIMETER_REGEXP, /(?<quantity>\d+)/])
];

function parseGroups(groups, allowSum) {
    if (allowSum === undefined) allowSum = true;
    var result = {
        quantity: 1,
        units: []
    };
    if (groups && groups.value) {
        var valueStr = groups.value;
        var unit = groups.unit;
        if (valueStr && unit) {
            var value = parseFloat(valueStr.replace(",", "."));
            var unit2 = null;
            if (groups.weight_unit) {
                if (!groups.weight_SI) {
                    value /= 1000;
                }
                unit2 = "кг";
            }
            if (groups.volume_unit) {
                if (!groups.volume_SI) {
                    value /= 1000;
                }
                unit2 = "л";
            }
            if (groups.length_unit) {
                if (!groups.length_SI) {
                    value /= 1000;
                }
                unit2 = "м";
            }
            if (!unit2) {
                    return result;
                }
            result.units.push({
                unit: unit2,
                value: value,
                total: value
            });
        }
    }
    if (groups && groups.quantity) {
        var qtyStr = groups.quantity;
        if (qtyStr) {
            result.quantity = parseInt(qtyStr, 10);
        }
    }
    if (allowSum && result.quantity > 1) {
        for (var i = 0; i < result.units.length; i++) {
            result.units[i].total = result.quantity * result.units[i].value;
        }
    }
    return result;
}

function parseTitle(title) {
    if (!title) return { quantity: 1, units: [] };
    
    for (var i = 0; i < COMBINE_QANTITY_WEIGHT_REGEXP_LIST.length; i++) {
        var rMatch = COMBINE_QANTITY_WEIGHT_REGEXP_LIST[i].exec(title);
        if (rMatch) {
            return parseGroups(rMatch.groups);
        }
    }
    var groups = {};
    var weightMatch = WEIGHT_REGEXP.exec(title);
    if (weightMatch && weightMatch.groups) {
        groups = weightMatch.groups;
    }
    var quantity = 0;
    for (var j = 0; j < COMBINE_QUANTITY_LIST.length; j++) {
        var qMatch = COMBINE_QUANTITY_LIST[j].exec(title);
        if (qMatch && qMatch.groups && qMatch.groups.quantity && qMatch.groups.quantity_2) {
            quantity = parseInt(qMatch.groups.quantity, 10) * parseInt(qMatch.groups.quantity_2, 10);
            break;
        }
    }
    if (quantity) {
        groups.quantity = quantity.toString();
    } else {
        var quantityMatch = QUANTITY_REGEXP.exec(title);
        if (quantityMatch && quantityMatch.groups) {
            var merged = {};
            for (var k in groups) {
                if (groups[k] !== undefined) merged[k] = groups[k];
            }
            for (var k in quantityMatch.groups) {
                if (quantityMatch.groups[k] !== undefined) merged[k] = quantityMatch.groups[k];
            }
            groups = merged;
        }
    }
    var allowSum = true;
    if (groups && groups.value) {
        allowSum = false;
    }
    return parseGroups(groups, allowSum);
}

function parseTitleWithPrice(title, price) {
    if (!title || !price) return null;
    
    var parsed = parseTitle(title);
    var units = parsed.units;
    var res = {
        quantity: parsed.quantity,
        units: [],
        quantity_price: null,
        quantity_price_display: null
    };
    if ((!res.quantity || res.quantity === 1) && !units.length) {
        return null;
    }
    for (var i = 0; i < units.length; i++) {
        var u = units[i];
        var p = round(price / u.total);
        res.units.push({
            unit: u.unit,
            value: u.value,
            total: u.total,
            price: p,
            price_display: p + " ₽/" + (u.unit || "?")
        });
    }
    if (res.quantity > 1) {
        res.quantity_price = round(price / res.quantity);
        res.quantity_price_display = res.quantity_price + " ₽/шт";
    }
    return res;
}

// ===== PRICE PARSE =====
function parsePrice(text) {
    if (!text) return null;
    text = text.split("₽")[0];
    if (text) text = text.trim();
    if (!text) return null;
    text = text.replace("&thinsp;", "").replace(" ", "").replace(" ", "").replace(/\s/g, "");
    var match = text.match(/\d+(\s*[,.]\s*\d+)?/);
    if (match && match[0]) {
        return parseFloat(match[0].trim());
    }
    return null;
}

function getPriceFromElement(el) {
    if (!el) return null;
    var priceText = el.textContent;
    if (priceText) priceText = priceText.trim();
    if (priceText) {
        return parsePrice(priceText);
    }
    return null;
}

function getPrice(sel, root2) {
    if (!root2) root2 = document.body;
    if (!root2) return null;
    var priceEl = root2.querySelector(sel);
    return getPriceFromElement(priceEl);
}
