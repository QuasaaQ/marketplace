// ===== STORE: WILDBERRIES =====
// Вся логика для Wildberries: сортировка отзывов, Best Price, перехват ссылок

var wbExtraStyle = {
    fontSize: "1rem",
    color: "black"
};

// WB: Модификатор URL для перехвата ссылок
function wbUrlModifier(url) {
    if (typeof url !== 'string') return url;
    
    // Для /catalog/ ссылок
    if (url.indexOf('/catalog/') !== -1 && url.indexOf('sort=') === -1) {
        if (url.indexOf('?') !== -1) {
            return url + '&sort=valueup';
        } else {
            return url + '?sort=valueup';
        }
    }
    
    // Для /detail.aspx
    if (url.indexOf('/detail.aspx') !== -1 && url.indexOf('sort=') === -1) {
        if (url.indexOf('?') !== -1) {
            return url + '&sort=valueup';
        } else {
            return url + '?sort=valueup';
        }
    }
    
    // Для /feedbacks
    if (url.indexOf('/feedbacks') !== -1 && url.indexOf('sort=valueup') === -1) {
        if (url.indexOf('?') !== -1) {
            return url + '&sort=valueup';
        } else {
            return url + '?sort=valueup';
        }
    }
    
    return url;
}

function wbInitProductPage() {
    // Настройка перехвата навигации
    setupLinkInterception({
        linkSelectors: ['a[href*="/catalog/"]', 'a[href*="/feedbacks"]'],
        urlModifier: wbUrlModifier,
        dataAttr: 'wbIntercepted'
    });
    
    if (!config.bestPriceEnabled) return;
    
    var productRoot = document.querySelector(".product-page");
    if (!productRoot) return;

    processProductCard(productRoot, {
        price_sel: ".price-block__final-price",
        title_sel: ".product-page__header h1",
        to_render: ".price-block",
        extra_style: wbExtraStyle,
        force: true
    });

    var cardList = document.querySelectorAll(".product-card");
    for (var i = 0; i < cardList.length; i++) {
        processProductCard(cardList[i], {
            price_sel: ".price__lower-price",
            title_sel: ".product-card__name",
            to_render: ".product-card__price",
            extra_style: wbExtraStyle
        });
    }
}

function wbInitPopup() {
    if (!config.bestPriceEnabled) return;
    
    var productPopupRoot = document.querySelector(".popup .product");
    if (!productPopupRoot) return;

    processProductCard(productPopupRoot, {
        price_sel: ".price-block__final-price",
        title_sel: ".product__header",
        to_render: ".price-block",
        extra_style: wbExtraStyle
    });
}

function wbInitCatalog() {
    // Настройка перехвата навигации
    setupLinkInterception({
        linkSelectors: ['a[href*="/catalog/"]', 'a[href*="/feedbacks"]'],
        urlModifier: wbUrlModifier,
        dataAttr: 'wbIntercepted'
    });
    
    if (!config.bestPriceEnabled) {
        dbg("[WB debug] bestPrice disabled");
        return;
    }
    
    // Отладка: ищем все возможные контейнеры с товарами
    var possibleContainers = [
        ".product-card-list",
        ".catalog-page__main",
        "[class*='product-card']",
        "[class*='catalog']",
        "[class*='search']"
    ];
    for (var i = 0; i < possibleContainers.length; i++) {
        var els = document.querySelectorAll(possibleContainers[i]);
        dbg("[WB debug] '" + possibleContainers[i] + "' found " + els.length + " elements");
    }
    
    var cardList = document.querySelectorAll(".product-card");
    dbg("[WB debug] .product-card found: " + cardList.length);
    
    // Пробуем альтернативные селекторы для карточек товаров
    var alternativeCards = document.querySelectorAll("[class*='card']");
    dbg("[WB debug] [class*='card'] found: " + alternativeCards.length);
    
    for (var i = 0; i < cardList.length; i++) {
        try {
            processProductCard(cardList[i], {
                price_sel: ".price__lower-price",
                title_sel: ".product-card__name",
                to_render: ".product-card__price",
                extra_style: wbExtraStyle
            });
        } catch (e) {
            dbg("[WB debug] processProductCard error:", e, e ? e.stack : "");
        }
    }

    var catalogWrapEl = document.querySelector(".product-card-list");
    dbg("[WB debug] .product-card-list found: " + (catalogWrapEl ? "yes" : "no"));
    
    var mainEl = document.querySelector(".catalog-page__main");
    dbg("[WB debug] mainEl found: " + (mainEl ? "yes tag=" + mainEl.tagName : "no"));
    
    var buttonWrapEl = ElementGetOrCreate(mainEl, {
        pos: "before"
    });
    dbg("[WB debug] buttonWrapEl: " + (buttonWrapEl ? "created" : "NULL"));
    
    if (catalogWrapEl && buttonWrapEl) {
        dbg("[WB debug] calling initReorderCatalog");
        initReorderCatalog(catalogWrapEl, buttonWrapEl);
    } else {
        dbg("[WB debug] skipping initReorderCatalog, catalogWrapEl=" + !!catalogWrapEl + " buttonWrapEl=" + !!buttonWrapEl);
    }

    var paginationRootWrap = ElementGetOrCreate(catalogWrapEl, {
        pos: "before",
        className: "GM-pagination-clone"
    });
    if (paginationRootWrap) {
        copyElementToNewRoot(document.querySelectorAll(".pager-bottom:not(.GM-cloned)"), paginationRootWrap);
    }
}

// ===== СОРТИРОВКА ОТЗЫВОВ WILDBERRIES =====
function sortWildberriesReviews() {
    if (!config.sortReviewsEnabled) return;
    
    var currentURL = window.location.href;
    if (currentURL.indexOf('&sort=valueup') !== -1 || currentURL.indexOf('?sort=valueup') !== -1) {
        return;
    }
    
    var interval = setInterval(function() {
        var preloader = document.querySelector('#app > div[data-link="visible{:router.showPreview}"]');
        if (preloader && preloader.style.display === 'none') {
            var sortButton = document.querySelector('a[data-link*="sorterModel.sortingEntries[\'valuationup\']"]');
            if (sortButton) {
                clearInterval(interval);
                
                if (sortButton.classList.contains('sorting__selected')) {
                    var span = sortButton.querySelector('span');
                    if (span && span.classList.contains('sorting__decor--up')) {
                        return;
                    } else {
                        sortButton.click();
                    }
                } else {
                    sortButton.click();
                    setTimeout(function() {
                        sortButton.click();
                    }, 100);
                }
            }
        }
    }, 50);
}

function wbShowSpecsUnderPhoto() {
    if (!config.sortReviewsEnabled) return;
    
    var popup__content = document.querySelector('div.popup-product-details > div.popup__content');
    var product_params__table = document.querySelector('div.popup__content > div.product-details > div.product-params > table.product-params__table');
    var factClick_button_product_page__btn_detail = false;
    var button_product_page__btn_detail;

    if (product_params__table) {
        popup_product_details_Replace();
    } else {
        var observer = new MutationObserver(function(mutationsList, observer) {
            for (var i = 0; i < mutationsList.length; i++) {
                var mutation = mutationsList[i];
                if (mutation.type === 'childList') {
                    for (var j = 0; j < mutation.addedNodes.length; j++) {
                        var node = mutation.addedNodes[j];
                        if (node.nodeType === 1) {
                            if (!button_product_page__btn_detail && node.matches('button.product-page__btn-detail')) {
                                button_product_page__btn_detail = node;
                                button_product_page__btn_detail_click();
                            } else if (factClick_button_product_page__btn_detail && node.matches('div.popup-product-details')) {
                                if (node.querySelector('div.popup__content > div.product-details > div.product-params > table.product-params__table')) {
                                    observer.disconnect();
                                    popup__content = node.querySelector('div.popup__content');
                                    popup_product_details_Replace();
                                    break;
                                } else {
                                    node.remove();
                                    factClick_button_product_page__btn_detail = false;
                                    setTimeout(function() {
                                        button_product_page__btn_detail_click();
                                    }, 1000);
                                }
                            }
                        }
                    }
                }
            }
        });
        observer.observe(document.body, { childList: true });
        button_product_page__btn_detail_click();
    }

    function button_product_page__btn_detail_click() {
        if (!button_product_page__btn_detail) {
            button_product_page__btn_detail = document.querySelector('#app button.product-page__btn-detail');
        }
        if (button_product_page__btn_detail && !factClick_button_product_page__btn_detail) {
            factClick_button_product_page__btn_detail = true;
            button_product_page__btn_detail.click();
        }
    }

    function popup_product_details_Replace() {
        if (factClick_button_product_page__btn_detail && popup__content && popup__content.parentNode) {
            popup__content.parentNode.remove();
        }
        var product_page__grid = document.querySelector('div.product-page__grid');
        if (product_page__grid) {
            var popupContentElements = product_page__grid.parentNode.querySelectorAll('div.popup__content');
            for (var i = 0; i < popupContentElements.length; i++) {
                popupContentElements[i].remove();
            }
        }
        if (popup__content && product_page__grid) {
            var footer = popup__content.querySelector('div.popup__footer');
            if (footer) footer.remove();
            if (product_page__grid.insertAdjacentElement && typeof product_page__grid.insertAdjacentElement === 'function') {
                try {
                    product_page__grid.insertAdjacentElement('afterend', popup__content);
                } catch (e) {}
            }
        }
        document.body.classList.remove('body--overflow');
    }
}

function wbGlobalSortReviews() {
    if (!config.sortReviewsEnabled) return;
    
    if (window.location.pathname.indexOf('&sort=valueup') === -1) {
        var ratingButton = document.querySelector('button.switcher__item.has-alternate');
        if (ratingButton) {
            ratingButton.click();
        } else {
            var callback = function(mutationsList, observer) {
                for (var i = 0; i < mutationsList.length; i++) {
                    var mutation = mutationsList[i];
                    if (mutation.type === 'childList') {
                        mutation.addedNodes.forEach(function(node) {
                            if (node.nodeType === Node.ELEMENT_NODE) {
                                if (node.matches('button.switcher__item.has-alternate') && !node.matches('button.is-active')) {
                                    node.click();
                                    observer.disconnect();
                                } else {
                                    var switcherItem = node.querySelector('button.switcher__item.has-alternate');
                                    if (switcherItem) {
                                        if (!switcherItem.matches('button.is-active')) {
                                            switcherItem.click();
                                            observer.disconnect();
                                        }
                                    }
                                }
                            }
                        });
                    }
                }
            };
            var observer = new MutationObserver(callback);
            observer.observe(document.body, {
                childList: true,
                subtree: true,
            });
        }
    }
}
