// ===== UTILS =====
// Вспомогательные утилиты: ожидание элементов, создание DOM, XPath, стили

// Константы для глобального использования (shared между модулями)
var BEST_PRICE_CLASS_NAME = "GM-best-price";
var BEST_PRICE_WRAP_CLASS_NAME = "GM-best-price-wrap";
var ORDER_NAME_LOCAL_STORAGE = "GM-best-price-default-order";
var MAX_NUMBER = 99999999999;
var BEST_ORDER_BUTTON_CLASS_NAME = "GM-best-price-button";
var PREFIX = "bp_";

function getElementByXpath(xpath, root) {
    if (!root) root = document;
    var e = document.evaluate(xpath, root, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    return e && e;
}

function waitElement(match, callback, root) {
    if (!root) root = document.body;
    var observer = new MutationObserver(function(mutations) {
        if (!mutations) return;
        var matchFlag = false;
        for (var mi = 0; mi < mutations.length; mi++) {
            var mutation = mutations[mi];
            if (!mutation.addedNodes) continue;
            for (var ni = 0; ni < mutation.addedNodes.length; ni++) {
                var node = mutation.addedNodes[ni];
                matchFlag = match(node);
            }
        }
        if (matchFlag) {
            _stop();
            callback();
            _start();
        }
    });
    var isStarted = false;
    function _start() {
        if (isStarted) return;
        var target = root || document.body;
        if (!target || !(target instanceof Node)) return;
        try {
            observer.observe(target, {
                childList: true,
                subtree: true,
                attributes: false,
                characterData: false
            });
            isStarted = true;
        } catch (e) {}
    }
    function _stop() {
        try {
            observer.disconnect();
        } catch (e) {}
        isStarted = false;
    }
    _start();
    return function() { _stop(); };
}

function waitCompletePage(callback, options) {
    if (!options) options = {};
    var root = options.root || document.body;
    var runOnce = options.runOnce !== undefined ? options.runOnce : true;
    var sync = options.sync !== undefined ? options.sync : true;
    var delay = options.delay || 150;
    var t;
    var lock = false;
    function run() {
        var stop = waitElement(function() { return true; }, function() {
            if (t) clearTimeout(t);
            t = setTimeout(function() {
                if (lock) return;
                lock = true;
                if (runOnce || sync) {
                    stop();
                }
                callback();
                if (sync && !runOnce) {
                    setTimeout(run, delay);
                }
                lock = false;
            }, delay);
        }, root);
        return stop;
    }
    return run();
}

function E(tag, attributes, children) {
    if (!attributes) attributes = {};
    if (!children) children = [];
    var element = document.createElement(tag);
    for (var k in attributes) {
        if (attributes.hasOwnProperty(k)) {
            element.setAttribute(k, attributes[k]);
        }
    }
    var fragment = document.createDocumentFragment();
    children.forEach(function(child) {
        if (typeof child === "string") {
            child = document.createTextNode(child);
        }
        fragment.appendChild(child);
    });
    element.appendChild(fragment);
    return element;
}

function ElementGetOrCreate(root, options) {
    if (!options) options = {};
    var className = options.className || "GM-wrap";
    var pos = options.pos || "appendChild";
    if (!root) return null;
    
    var wrapEl = root.parentElement ? root.parentElement.querySelector("." + className) : null;
    if (!wrapEl) {
        wrapEl = E("div", { "class": className });
        if (root && root[pos] && typeof root[pos] === 'function') {
            try {
                root[pos](wrapEl);
            } catch (e) {
                return null;
            }
        } else if (root && root.parentElement && pos === "before" && root.parentElement.insertBefore) {
            try {
                root.parentElement.insertBefore(wrapEl, root);
            } catch (e) {
                return null;
            }
        } else if (root && root.appendChild) {
            try {
                root.appendChild(wrapEl);
            } catch (e) {
                return null;
            }
        } else {
            return null;
        }
    }
    return wrapEl;
}

function copyElementToNewRoot(el, toRoot, options) {
    if (!options) options = {};
    var className = options.className || "GM-cloned";
    var pos = options.pos || "appendChild";
    if (!el || !toRoot || !toRoot.parentElement) return;
    
    var elList = [];
    if (el instanceof HTMLElement) {
        elList = [el];
    } else {
        elList = el;
    }
    
    try {
        var existingElements = toRoot.parentElement.querySelectorAll("." + className);
        for (var i = 0; i < existingElements.length; i++) {
            existingElements[i].remove();
        }
    } catch (e) {}
    
    for (var j = 0; j < elList.length; j++) {
        try {
            var clonedEl = elList[j].cloneNode(true);
            clonedEl.classList.add(className);
            if (toRoot && toRoot[pos] && typeof toRoot[pos] === 'function') {
                toRoot[pos](clonedEl);
            }
        } catch (e) {}
    }
}

function GM_addStyle(css) {
    try {
        var style = document.getElementById("GM_addStyleBy8626");
        if (!style) {
            style = document.createElement("style");
            style.type = "text/css";
            style.id = "GM_addStyleBy8626";
            document.head.appendChild(style);
        }
        var sheet = style.sheet;
        if (sheet) {
            sheet.insertRule(css, (sheet.rules || sheet.cssRules || []).length);
        }
    } catch (e) {}
}

function isFunction(x) {
    return typeof x === "function";
}

function matchLocation() {
    var s = document.location.href;
    for (var i = 0; i < arguments.length; i++) {
        var p = arguments[i];
        if (isFunction(p) && p(s)) {
            return true;
        }
        if (RegExp(p).test(s)) {
            return true;
        }
    }
    return false;
}

function isRegexp(value) {
    return toString.call(value) === "[object RegExp]";
}

function mRegExp(regExps) {
    return RegExp(regExps.map(function(r) {
        if (isRegexp(r)) {
            return r.source;
        }
        return r;
    }).join(""), "i");
}

function round(n, parts) {
    if (!parts) parts = 2;
    var i = Math.pow(10, parts);
    return Math.round(n * i) / i;
}

var entries = Object.entries;
var values = Object.values;

function byPropertiesOf(sortBy) {
    function compareByProperty(arg) {
        var key;
        var sortOrder = 1;
        if (typeof arg === "string" && arg.startsWith("-")) {
            sortOrder = -1;
            key = arg.substr(1);
        } else {
            key = arg;
        }
        return function(a, b) {
            var result = a[key] < b[key] ? -1 : a[key] > b[key] ? 1 : 0;
            return result * sortOrder;
        };
    }
    return function(obj1, obj2) {
        var i = 0;
        var result = 0;
        var numberOfProperties = sortBy ? sortBy.length : 0;
        while (result === 0 && i < numberOfProperties) {
            result = compareByProperty(sortBy[i])(obj1, obj2);
            i++;
        }
        return result;
    };
}

function sort(arr) {
    var sortBy = Array.prototype.slice.call(arguments, 1);
    arr.sort(byPropertiesOf(sortBy));
}

// ===== ГЛОБАЛЬНАЯ ФУНКЦИЯ ДЛЯ ЛОГОВ =====
// Все логи начинаются с [MarketplaceTrue] — фильтруй в консоли по этому слову
// Учитывает config.debugEnabled — выкл/вкл одним переключателем
function dbg() {
    if (!config || config.debugEnabled === false) return;
    var args = Array.prototype.slice.call(arguments);
    if (args.length > 0 && typeof args[0] === 'string') {
        args[0] = "[MarketplaceTrue] " + args[0];
    } else {
        args.unshift("[MarketplaceTrue]");
    }
    console.log.apply(console, args);
}
