// ===== LINK INTERCEPTOR =====
// Утилиты для перехвата навигации: window.open, клики по ссылкам, MutationObserver

/**
 * Перехватывает window.open для добавления параметров сортировки
 */
function interceptWindowOpen(urlModifier) {
    if (!config.sortReviewsEnabled) return;
    
    var originalOpen = window.open;
    window.open = function(url, target, features) {
        if (typeof url === 'string') {
            var modifiedUrl = urlModifier(url);
            if (modifiedUrl !== url) {
                url = modifiedUrl;
            }
        }
        return originalOpen.call(this, url, target, features);
    };
}

/**
 * Добавляет перехват кликов на ссылки, соответствующие селектору
 */
function interceptLinks(linkSelector, urlModifier, dataAttr) {
    if (!dataAttr) dataAttr = 'intercepted';
    if (!config.sortReviewsEnabled) return;
    
    var links = document.querySelectorAll(linkSelector);
    for (var i = 0; i < links.length; i++) {
        var link = links[i];
        if (link.dataset[dataAttr] === 'true') continue;
        link.dataset[dataAttr] = 'true';
        
        link.addEventListener('click', function(e) {
            // Клики по внутренним кнопкам карточки не перехватываем.
            // Ozon добавил в карточку стрелки листания фото влево/вправо
            // (это <button> внутри <a>). Наш обработчик висит в фазе захвата
            // и срабатывает раньше кнопки, поэтому без этой проверки
            // preventDefault + window.open уводили бы на страницу товара
            // вместо листания фото.
            var clickTarget = e.target;
            if (clickTarget && clickTarget.closest && clickTarget.closest('button')) {
                return;
            }
            if (e.ctrlKey || e.shiftKey || e.metaKey) {
                var currentHref = this.getAttribute('href');
                var newHref = urlModifier(currentHref);
                if (newHref !== currentHref) {
                    this.setAttribute('href', newHref);
                }
                return;
            }
            
            var currentHref = this.getAttribute('href');
            var newHref = urlModifier(currentHref);
            if (newHref !== currentHref) {
                this.setAttribute('href', newHref);
                e.preventDefault();
                window.open(newHref, '_self');
            }
        }, true);
        
        link.addEventListener('mousedown', function(e) {
            if (e.button === 1) {
                var currentHref = this.getAttribute('href');
                var newHref = urlModifier(currentHref);
                if (newHref !== currentHref) {
                    this.setAttribute('href', newHref);
                }
            }
        }, true);
        
        link.addEventListener('contextmenu', function(e) {
            var currentHref = this.getAttribute('href');
            var newHref = urlModifier(currentHref);
            if (newHref !== currentHref) {
                this.setAttribute('href', newHref);
            }
        }, true);
    }
}

/**
 * Запускает MutationObserver для отслеживания новых ссылок
 */
function observeNewLinks(linkSelector, urlModifier, dataAttr) {
    if (!dataAttr) dataAttr = 'intercepted';
    if (!config.sortReviewsEnabled) return;
    
    var observer = new MutationObserver(function() {
        interceptLinks(linkSelector, urlModifier, dataAttr);
    });
    
    function tryObserve() {
        if (!document.body || !(document.body instanceof Node)) {
            setTimeout(tryObserve, 10);
            return;
        }
        try {
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        } catch (e) {}
    }
    tryObserve();
}

/**
 * Настраивает полный перехват навигации для магазина
 */
function setupLinkInterception(options) {
    var linkSelectors = options.linkSelectors;
    var urlModifier = options.urlModifier;
    var dataAttr = options.dataAttr || 'intercepted';
    
    interceptWindowOpen(urlModifier);
    
    var selectors = Array.isArray(linkSelectors) ? linkSelectors : [linkSelectors];
    for (var i = 0; i < selectors.length; i++) {
        interceptLinks(selectors[i], urlModifier, dataAttr);
        observeNewLinks(selectors[i], urlModifier, dataAttr);
    }
}
