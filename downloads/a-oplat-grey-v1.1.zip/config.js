// ==================================================
// КОНФИГУРАЦИЯ РАСШИРЕНИЯ A.OPLAT
// ==================================================

window.AppConfig = {
    // Список подразделений по умолчанию
    defaultPairs: [
        "КЦЕ_НП_Е_Тула_БИТ_Е",
        "КЦЕ_НП_Е_Тула_ТКЦ1_ГБ",
        "АП_НП_П_Москва_ГПНК1_ГБ_УД",
        "АП_НП_П_Краснодар_ГПНК1_ГБ_УД",
        "КЦЕ_НП_Е_Тула_ТКЦ2_БУХ",
        "КЦЕ_НП_Е_Тула_ТКЦ3_ФД",
        "КЦЕ_НП_Е_Тула_ТКЦ4_ГБ",
        "КЦЕ_НП_Е_Тула_ТКЦ5_ПР_КиHR",
        "КЦЕ_НП_Е_Тула_ТКЦ7_ГБ",
        "КЦЕ_НП_Е_Тула_ТКЦ8_БУХ"
    ],

    // Задержки между действиями (в миллисекундах)
    delays: {
        afterDateStart: 50,
        afterDateEnd: 50,
        afterSubdivOpen: 100,
        betweenSubdivClicks: 20,
        afterSubdivClose: 2000,
        afterOpsOpen: 100,
        afterOpsSelect: 50,
        afterOpsClose: 50,
        afterFinalSubmit: 100  // небольшая задержка перед отправкой taskFinished
    },

    // Задержки для работы расширения
    extensionDelays: {
        afterTabReload: 1000,
        afterTabLoad: 1000,
        messageTimeout: 5000,
        retryDelay: 1000,
        waitForLoadTimeout: 10000,
        waitForNewTabTimeout: 15000
    },

    // Настройки повторов
    retrySettings: {
        executeMaxRetries: 3,
        openMaxRetries: 2
    },

    // URL отчёта
    reportUrl: "https://report.action.group/Reports/report/%D0%90%D0%BD%D0%B0%D0%BB%D0%B8%D1%82%D0%B8%D0%BA%D0%B0%20%D0%94%D0%B8%D0%B4%D0%B6%D0%B8%D1%82%D0%B0%D0%BB/%D0%9A%D0%BE%D0%BB%D0%BB-%D1%86%D0%B5%D0%BD%D1%82%D1%80%D1%8B/%D0%9E%D0%BF%D0%BB%D0%B0%D1%87%D0%B5%D0%BD%D0%BD%D1%8B%D0%B5%20%D0%B7%D0%B0%D0%BA%D0%B0%D0%B7%D1%8B%20%D0%B7%D0%B0%20%D0%BF%D0%B5%D1%80%D0%B8%D0%BE%D0%B4"
};