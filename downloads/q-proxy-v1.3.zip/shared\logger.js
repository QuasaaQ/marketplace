/**
 * Q.Proxy - отладочный логгер.
 *
 * Все сообщения выводятся с префиксом `[Q.Proxy]`, чтобы их можно было
 * отфильтровать в консоли (DevTools → Filter: `[Q.Proxy]`).
 *
 * Управление:
 *  - `QProxyLog.setEnabled(false)` - выключить вывод;
 *  - `QProxyLog.setLevel('debug'|'info'|'warn'|'error')` - уровень;
 *  - `QProxyLog.dump()` - вывести накопленный буфер.
 */

(function () {
  'use strict';

  const PREFIX = '[Q.Proxy]';
  const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };

  // Буфер последних сообщений (для dump()).
  const buffer = [];
  const BUFFER_LIMIT = 500;

  const state = {
    enabled: true,
    level: 'debug',
  };

  /**
   * Форматирует время в виде HH:MM:SS.mmm.
   * @returns {string}
   */
  function timestamp() {
    const d = new Date();
    const pad = (n, len) => String(n).padStart(len, '0');
    return (
      pad(d.getHours(), 2) +
      ':' +
      pad(d.getMinutes(), 2) +
      ':' +
      pad(d.getSeconds(), 2) +
      '.' +
      pad(d.getMilliseconds(), 3)
    );
  }

  /**
   * Определяет, доступна ли консоль в текущем контексте.
   * @returns {boolean}
   */
  function hasConsole() {
    return typeof console !== 'undefined' && console !== null;
  }

  /**
   * Пишет сообщение в консоль и буфер.
   * @param {string} level
   * @param {Array<*>} args
   */
  function write(level, args) {
    if (!state.enabled) return;
    if (LEVELS[level] < LEVELS[state.level]) return;

    const time = timestamp();
    const entry = { time, level, args };

    buffer.push(entry);
    if (buffer.length > BUFFER_LIMIT) buffer.shift();

    if (!hasConsole()) return;

    const method =
      level === 'error' ? 'error' : level === 'warn' ? 'warn' : level === 'info' ? 'info' : 'log';

    try {
      console[method](`${PREFIX} ${time} ${level.toUpperCase()}`, ...args);
    } catch (error) {
      /* игнорируем ошибки консоли */
    }
  }

  const QProxyLog = {
    PREFIX,

    /**
     * Отладочное сообщение.
     * @param {...*} args
     */
    debug(...args) {
      write('debug', args);
    },

    /**
     * Информационное сообщение.
     * @param {...*} args
     */
    info(...args) {
      write('info', args);
    },

    /**
     * Предупреждение.
     * @param {...*} args
     */
    warn(...args) {
      write('warn', args);
    },

    /**
     * Ошибка.
     * @param {...*} args
     */
    error(...args) {
      write('error', args);
    },

    /**
     * Включает/выключает вывод.
     * @param {boolean} enabled
     */
    setEnabled(enabled) {
      state.enabled = !!enabled;
      write('info', ['Логирование', state.enabled ? 'включено' : 'выключено']);
    },

    /**
     * Устанавливает минимальный уровень.
     * @param {'debug'|'info'|'warn'|'error'} level
     */
    setLevel(level) {
      if (LEVELS[level] === undefined) return;
      state.level = level;
      write('info', ['Уровень логирования:', level]);
    },

    /**
     * Возвращает текущее состояние.
     * @returns {{enabled: boolean, level: string}}
     */
    getState() {
      return { ...state };
    },

    /**
     * Выводит накопленный буфер.
     */
    dump() {
      if (!hasConsole()) return;
      console.group(`${PREFIX} dump (${buffer.length})`);
      for (const entry of buffer) {
        console.log(`${entry.time} ${entry.level.toUpperCase()}`, ...entry.args);
      }
      console.groupEnd();
    },

    /**
     * Очищает буфер.
     */
    clear() {
      buffer.length = 0;
    },
  };

  if (typeof self !== 'undefined') {
    self.QProxyLog = QProxyLog;
  }
  if (typeof window !== 'undefined') {
    window.QProxyLog = QProxyLog;
  }
})();
