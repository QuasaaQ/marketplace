/**
 * Q.Proxy - логика страницы настроек.
 *
 * Управляет:
 *  - общими настройками;
 *  - списком своих прокси (добавление, проверка, удаление);
 *  - авто-тестированием;
 *  - списком проксируемых сайтов.
 */

// Защитный fallback, если logger.js не загрузился.
const log =
  window.QProxyLog ||
  {
    debug() {},
    info() {},
    warn() {},
    error() {},
  };

log.info('options: скрипт загружен');

if (!window.QProxyStorage) {
  log.error('options: QProxyStorage не найден - storage.js не загрузился');
}

const {
  normalizeDomain,
  parseProxyString,
  formatProxyString,
  generateProxyId,
  collectCountries,
  BUILTIN_SOURCES,
  AI_SITES,
} = window.QProxyStorage;

const els = {
  enabledCheckbox: document.getElementById('enabledCheckbox'),
  proxyAllTrafficCheckbox: document.getElementById('proxyAllTrafficCheckbox'),

  proxyProtocolSelect: document.getElementById('proxyProtocolSelect'),
  proxyNameInput: document.getElementById('proxyNameInput'),
  proxyServerInput: document.getElementById('proxyServerInput'),
  addProxyButton: document.getElementById('addProxyButton'),
  proxyFormError: document.getElementById('proxyFormError'),
  pasteProxiesButton: document.getElementById('pasteProxiesButton'),
  copyAllProxiesButton: document.getElementById('copyAllProxiesButton'),
  pasteStatus: document.getElementById('pasteStatus'),

  proxySourcesList: document.getElementById('proxySourcesList'),
  builtinSourceSelect: document.getElementById('builtinSourceSelect'),
  addBuiltinSourceButton: document.getElementById('addBuiltinSourceButton'),
  addAllBuiltinSourcesButton: document.getElementById('addAllBuiltinSourcesButton'),
  sourcesLimitInput: document.getElementById('sourcesLimitInput'),
  saveSourcesButton: document.getElementById('saveSourcesButton'),
  fetchSourcesButton: document.getElementById('fetchSourcesButton'),
  sourcesStatus: document.getElementById('sourcesStatus'),

  countryDetectStatus: document.getElementById('countryDetectStatus'),
  countryFilterMode: document.getElementById('countryFilterMode'),
  countryFilterBase: document.getElementById('countryFilterBase'),
  countryFilterList: document.getElementById('countryFilterList'),
  countryFilterUnknownCheckbox: document.getElementById('countryFilterUnknownCheckbox'),
  countryFilterAutoCheckbox: document.getElementById('countryFilterAutoCheckbox'),
  applyCountryFilterButton: document.getElementById('applyCountryFilterButton'),
  keepOnlyCountrySelect: document.getElementById('keepOnlyCountrySelect'),
  keepOnlyCountryButton: document.getElementById('keepOnlyCountryButton'),

  testTargetSelect: document.getElementById('testTargetSelect'),
  testAllProxiesButton: document.getElementById('testAllProxiesButton'),
  stopTestProxiesButton: document.getElementById('stopTestProxiesButton'),
  removeDeadProxiesButton: document.getElementById('removeDeadProxiesButton'),
  removeUntestedProxiesButton: document.getElementById('removeUntestedProxiesButton'),
  removeAllProxiesButton: document.getElementById('removeAllProxiesButton'),
  checkProgress: document.getElementById('checkProgress'),
  checkProgressFill: document.getElementById('checkProgressFill'),
  checkProgressText: document.getElementById('checkProgressText'),
  proxyImportMsg: document.getElementById('proxyImportMsg'),
  proxyCount: document.getElementById('proxyCount'),
  proxyList: document.getElementById('proxyList'),
  selectAllProxies: document.getElementById('selectAllProxies'),
  selectionInfo: document.getElementById('selectionInfo'),

  autoTestEnabledCheckbox: document.getElementById('autoTestEnabledCheckbox'),
  autoTestIntervalInput: document.getElementById('autoTestIntervalInput'),
  autoTestTimesInput: document.getElementById('autoTestTimesInput'),
  autoTestDeleteDeadCheckbox: document.getElementById('autoTestDeleteDeadCheckbox'),
  autoTestDeleteLimitedCheckbox: document.getElementById('autoTestDeleteLimitedCheckbox'),
  autoTestRefillCheckbox: document.getElementById('autoTestRefillCheckbox'),
  disableOnDeadProxyCheckbox: document.getElementById('disableOnDeadProxyCheckbox'),
  autoDeleteDeadCheckbox: document.getElementById('autoDeleteDeadCheckbox'),
  testUrlInput: document.getElementById('testUrlInput'),
  testTimeoutInput: document.getElementById('testTimeoutInput'),

  proxiedSitesTextarea: document.getElementById('proxiedSitesTextarea'),
  saveProxiedSitesButton: document.getElementById('saveProxiedSitesButton'),
  addAiSitesButton: document.getElementById('addAiSitesButton'),
  proxiedSitesStatus: document.getElementById('proxiedSitesStatus'),

  incognitoHint: document.getElementById('incognitoHint'),
  incognitoStatus: document.getElementById('incognitoStatus'),
  openExtensionsPageButton: document.getElementById('openExtensionsPageButton'),

  statProxies: document.getElementById('statProxies'),
  statSites: document.getElementById('statSites'),
  navItems: document.querySelectorAll('.nav__item'),
  sections: document.querySelectorAll('.section'),
};

// Версия из manifest.json: показывается внизу страницы настроек, править
// вручную не нужно.
const footerVersion = document.getElementById('footerVersion');
if (footerVersion) {
  footerVersion.textContent = 'Версия ' + chrome.runtime.getManifest().version;
}

let state = {
  settings: null,
  proxies: [],
  proxiedSites: [],
  activeProxy: null,
  stats: {},
  sources: [],
};

// Таймер опроса прогресса проверки.
let progressTimer = null;

// Последние известные статусы строк («проверка…» / «в очереди»). Нужны, чтобы
// после перерисовки таблицы статусы не терялись.
let lastRowStatus = { checking: [], queued: [] };

// Шла ли проверка на предыдущем опросе: по переходу «идёт -> завершилась»
// подтягиваем свежую статистику.
let wasRunning = false;

// Прокси, отмеченные чекбоксами. По этому набору работают кнопки «Проверить»
// и «Удалить»: пустой набор означает «весь список».
const selectedProxies = new Set();

// Идёт ли проверка прямо сейчас: пока идёт, подпись кнопки не переписывается.
let testRunning = false;

// Идёт ли проверка по данным service worker: она могла быть запущена фоном
// (таймер авто-тестирования, автозагрузка источников), а не этой страницей.
let progressRunning = false;

// Нажата ли кнопка «Остановить»: до фактического завершения проверки кнопка
// остаётся в состоянии «Останавливаю…».
let stopRequested = false;

/**
 * Отправляет сообщение в service worker.
 * @param {object} message
 * @returns {Promise<object>}
 */
function sendMessage(message) {
  log.debug('options → background:', message.type, message);
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        log.error('options: ошибка sendMessage:', chrome.runtime.lastError.message);
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      log.debug('options ← background:', message.type, response);
      resolve(response || { ok: false });
    });
  });
}

/**
 * Загружает состояние из service worker.
 * @returns {Promise<void>}
 */
async function loadState() {
  const response = await sendMessage({ type: 'getState' });
  if (response && response.ok !== false) {
    state = {
      settings: response.settings,
      proxies: response.proxies || [],
      proxiedSites: response.proxiedSites || [],
      activeProxy: response.activeProxy || null,
      stats: response.stats || {},
      sources: state.sources,
    };
    log.info('options: состояние загружено', {
      proxies: state.proxies.length,
      sites: state.proxiedSites.length,
    });
  } else {
    log.error('options: не удалось загрузить состояние', response);
  }

  const sourcesResponse = await sendMessage({ type: 'getProxySources' });
  if (sourcesResponse && sourcesResponse.ok !== false) {
    state.sources = sourcesResponse.sources || [];
  }
}

/**
 * Отрисовывает все секции.
 */
function render() {
  renderGeneral();
  renderProxies();
  updateSortIndicator();
  // Перерисовка таблицы не должна стирать статусы идущей проверки.
  updateRowStatuses(lastRowStatus.checking, lastRowStatus.queued);
  renderAutoTest();
  renderProxiedSites();
  renderSources();
  renderCountryFilter();
  renderStats();
}

/**
 * Обновляет счётчики в боковой панели.
 */
function renderStats() {
  els.statProxies.textContent = String(state.proxies.length);
  els.statSites.textContent = String(state.proxiedSites.length);
}

/**
 * Переключает активный раздел.
 * @param {string} targetId
 */
function switchSection(targetId) {
  for (const item of els.navItems) {
    item.classList.toggle('nav__item--active', item.dataset.target === targetId);
  }
  for (const section of els.sections) {
    section.hidden = section.id !== targetId;
  }
}

/**
 * Отрисовывает общие настройки.
 */
function renderGeneral() {
  const settings = state.settings || {};
  els.enabledCheckbox.checked = settings.enabled !== false;
  els.proxyAllTrafficCheckbox.checked = !!settings.proxyAllTraffic;
  els.proxyProtocolSelect.value = settings.proxyProtocol || 'socks5';
}

/**
 * Текущая сортировка таблицы прокси. По умолчанию - по пингу: после проверки
 * самые быстрые прокси должны быть сверху. Клик по заголовку столбца меняет
 * сортировку и её направление.
 */
const sortState = { key: 'ping', dir: 'asc' };

/**
 * Прокси помечен «ограниченным»: тестовый сайт через него не открылся.
 *
 * Состояние не зависит от того, отвечает ли прокси на пинг: при проверке по
 * событию (активный прокси не открыл страницу) пинг не проверяется, поэтому
 * живость может быть неизвестна.
 *
 * @param {object} stat
 * @returns {boolean}
 */
function isLimitedStat(stat) {
  if (!stat || !stat.checkedAt) return false;
  // Явный флаг есть в новых записях. Старые записи распознаём по прежнему
  // признаку: живой прокси без открывшегося тестового сайта.
  if (typeof stat.limited === 'boolean') return stat.limited;
  return !!(stat.alive && stat.siteLatency == null);
}

/**
 * Ранг статуса прокси для сортировки: рабочие - первыми.
 * @param {object} stat
 * @returns {number}
 */
function statusRank(stat) {
  if (!stat || !stat.checkedAt) return 4;
  // Ограниченные идут сразу после полностью рабочих.
  if (isLimitedStat(stat)) return 1;
  if (stat.alive) return 0;
  if (stat.needsAuth) return 2;
  return 3;
}

/**
 * Значение прокси по ключу столбца.
 * @param {object} proxy
 * @param {string} key
 * @returns {string|number}
 */
function sortValue(proxy, key) {
  const stat = state.stats[proxy.id] || {};
  switch (key) {
    case 'name':
      return String(proxy.name || '').toLowerCase();
    case 'address':
      return formatProxyString(proxy);
    case 'country':
      return String(proxy.country || '');
    case 'exit':
      return String(stat.exitCountry || '');
    case 'ping':
      return stat.ping != null ? stat.ping : Infinity;
    case 'site':
      return stat.siteLatency != null ? stat.siteLatency : Infinity;
    case 'status':
      return statusRank(stat);
    default:
      return '';
  }
}

/**
 * Список прокси в порядке текущей сортировки. Прокси без данных (например,
 * без пинга) всегда остаются в конце списка.
 * @returns {Array<object>}
 */
function sortedProxies() {
  const dir = sortState.dir === 'desc' ? -1 : 1;
  const key = sortState.key;
  return state.proxies.slice().sort((a, b) => {
    // Для пинга и статуса сначала группируем по состоянию: работающие сверху,
    // ниже ограниченные, затем требующие авторизации и недоступные. Группы не
    // переворачиваются сменой направления, внутри группы работает обычная
    // сортировка по столбцу.
    if (key === 'ping' || key === 'status') {
      const ra = statusRank(state.stats[a.id]);
      const rb = statusRank(state.stats[b.id]);
      if (ra !== rb) return ra - rb;
    }

    const va = sortValue(a, key);
    const vb = sortValue(b, key);
    if (va === Infinity && vb === Infinity) return 0;
    if (va === Infinity) return 1;
    if (vb === Infinity) return -1;
    if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir;
    const cmp = String(va).localeCompare(String(vb), 'ru');
    if (cmp !== 0) return cmp * dir;
    // Одинаковый статус и одинаковое значение - сравниваем по адресу.
    return formatProxyString(a).localeCompare(formatProxyString(b));
  });
}

/**
 * Показывает стрелку у активного столбца сортировки.
 */
function updateSortIndicator() {
  for (const th of document.querySelectorAll('.proxy-table th[data-sort]')) {
    const active = th.dataset.sort === sortState.key;
    th.classList.toggle('th-sort--asc', active && sortState.dir === 'asc');
    th.classList.toggle('th-sort--desc', active && sortState.dir === 'desc');
  }
}

/**
 * Включает сортировку по клику на заголовок столбца.
 */
function initSortableHeaders() {
  for (const th of document.querySelectorAll('.proxy-table th[data-sort]')) {
    th.addEventListener('click', () => {
      const key = th.dataset.sort;
      if (sortState.key === key) {
        sortState.dir = sortState.dir === 'asc' ? 'desc' : 'asc';
      } else {
        sortState.key = key;
        sortState.dir = 'asc';
      }
      renderProxies();
      updateSortIndicator();
    });
  }
}

/**
 * Возвращает эмодзи-флаг страны по двухбуквенному коду (как в оригинале).
 * @param {string} code
 * @returns {string}
 */
function countryFlag(code) {
  const letters = String(code || '').trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(letters)) return '';
  return String.fromCodePoint(
    ...[...letters].map((ch) => 0x1f1e6 + (ch.charCodeAt(0) - 65))
  );
}

/**
 * Подпись страны для таблицы: флаг плюс код, либо прочерк.
 * @param {string} code
 * @returns {string}
 */
function countryLabel(code) {
  const value = String(code || '').trim().toUpperCase();
  if (!value) return '-';
  const flag = countryFlag(value);
  return flag ? `${flag} ${value}` : value;
}

/**
 * Возвращает текст, класс и подсказку статуса прокси.
 *
 * Статусы: не проверено; ограничен - прокси не открыл тестовый сайт; недоступен;
 * требуется авторизация; работает.
 *
 * @param {object} stat статистика проверки прокси
 * @returns {{text: string, className: string, title: string}}
 */
function proxyStatusInfo(stat) {
  if (!stat || !stat.checkedAt) {
    return { text: 'не проверено', className: '', title: '' };
  }

  // «Ограничен» - прокси не открыл тестовый сайт. Проверяем это раньше живости:
  // при проверке по событию пинг не проверяется, поэтому прокси может быть
  // ограниченным и без подтверждённой живости.
  if (isLimitedStat(stat)) {
    return {
      text: 'ограничен',
      className: 'status--warn',
      title: 'Сайт через этот прокси не открылся',
    };
  }

  if (!stat.alive) {
    if (stat.needsAuth) {
      return {
        text: 'требуется авторизация',
        className: 'status--warn',
        title: stat.error ? String(stat.error) : '',
      };
    }
    return {
      text: 'недоступен',
      className: 'status--bad',
      title: stat.error ? String(stat.error) : '',
    };
  }

  return { text: 'работает', className: 'status--ok', title: '' };
}

/**
 * Отрисовывает список прокси в виде таблицы.
 */
function renderProxies() {
  els.proxyList.innerHTML = '';
  // «Работает» - только полностью рабочие прокси: живые и с открывшимся
  // тестовым сайтом. «Ограниченные» (сайт через них не открылся) в счёт рабочих
  // не идут.
  const workingCount = state.proxies.filter((proxy) => {
    const stat = state.stats[proxy.id];
    return stat && stat.alive && stat.siteLatency != null && !isLimitedStat(stat);
  }).length;
  els.proxyCount.textContent =
    `Всего: ${state.proxies.length} · работает: ${workingCount}`;

  // В наборе выбора не должно оставаться id удалённых прокси.
  pruneSelection();

  if (!state.proxies.length) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 9;
    cell.className = 'empty';
    cell.textContent = 'Список прокси пуст. Добавьте свой прокси ниже.';
    row.appendChild(cell);
    els.proxyList.appendChild(row);
    updateSelectionUi();
    return;
  }

  for (const proxy of sortedProxies()) {
    const stat = state.stats[proxy.id] || {};
    const isActive = state.activeProxy && state.activeProxy.id === proxy.id;
    const isSelected = selectedProxies.has(proxy.id);

    const row = document.createElement('tr');
    row.className =
      'proxy-row' +
      (isActive ? ' proxy-row--active' : '') +
      (isSelected ? ' proxy-row--selected' : '');
    row.dataset.proxyId = proxy.id;

    // Первый столбец - чекбокс: по нему работают кнопки «Проверить» и «Удалить».
    const selectCell = document.createElement('td');
    selectCell.className = 'col-select';
    const selectBox = document.createElement('input');
    selectBox.type = 'checkbox';
    selectBox.className = 'proxy-select';
    selectBox.dataset.proxyId = proxy.id;
    selectBox.checked = isSelected;
    selectBox.title = 'Выбрать этот прокси';
    selectBox.setAttribute('aria-label', 'Выбрать прокси ' + formatProxyString(proxy));
    selectCell.appendChild(selectBox);

    // Название.
    const nameCell = document.createElement('td');
    nameCell.className = 'col-name';
    nameCell.textContent = proxy.name || '-';

    // Адрес.
    const addressCell = document.createElement('td');
    addressCell.className = 'col-address';
    addressCell.textContent = formatProxyString(proxy);

    // Страна прокси (по его IP): флаг плюс код, как в оригинале.
    const countryCell = document.createElement('td');
    countryCell.className = 'col-country';
    countryCell.textContent = countryLabel(proxy.country);

    // Страна выхода (определяется через прокси при проверке). Если вышел
    // другой IP, но страна ещё не определена, показываем «IP» - так видно,
    // что выход получен, а страна нет.
    const exitCell = document.createElement('td');
    exitCell.className = 'col-exit';
    if (stat.exitCountry) {
      exitCell.textContent = countryLabel(stat.exitCountry);
    } else if (stat.exitIp) {
      exitCell.textContent = 'IP';
      exitCell.title = stat.exitIp;
    } else {
      exitCell.textContent = '-';
    }

    // Пинг прокси (TCP-пинг хоста).
    const pingCell = document.createElement('td');
    pingCell.className = 'col-ping';
    pingCell.textContent = stat.ping != null ? `${stat.ping} мс` : '-';

    // Пинг сайта (второй).
    const siteCell = document.createElement('td');
    siteCell.className = 'col-site';
    siteCell.textContent = stat.siteLatency != null ? `${stat.siteLatency} мс` : '-';

    // Статус: текст и цвет берутся из общей функции, чтобы строка выглядела
    // одинаково и при отрисовке, и при обновлении во время проверки.
    const statusCell = document.createElement('td');
    statusCell.className = 'col-status';
    const statusInfo = proxyStatusInfo(stat);
    statusCell.textContent = statusInfo.text;
    if (statusInfo.title) statusCell.title = statusInfo.title;
    if (statusInfo.className) statusCell.classList.add(statusInfo.className);

    // Действия.
    const actionsCell = document.createElement('td');
    actionsCell.className = 'col-actions';

    const useButton = document.createElement('button');
    useButton.className = 'btn btn--sm';
    useButton.textContent = isActive ? 'Активен' : 'Использовать';
    useButton.disabled = isActive;
    useButton.addEventListener('click', () => {
      setActiveProxy(proxy).catch((error) => log.error('options: setActiveProxy', error));
    });

    const deleteButton = document.createElement('button');
    // Удаление одной строки - не акцентное действие: красный только при наведении.
    deleteButton.className = 'btn btn--sm btn--muted';
    deleteButton.textContent = 'Удалить';
    deleteButton.addEventListener('click', () => {
      deleteProxy(proxy.id).catch((error) => log.error('options: deleteProxy', error));
    });

    actionsCell.appendChild(useButton);
    actionsCell.appendChild(deleteButton);

    row.appendChild(selectCell);
    row.appendChild(nameCell);
    row.appendChild(addressCell);
    row.appendChild(countryCell);
    row.appendChild(exitCell);
    row.appendChild(pingCell);
    row.appendChild(siteCell);
    row.appendChild(statusCell);
    row.appendChild(actionsCell);
    els.proxyList.appendChild(row);
  }

  updateSelectionUi();
}

/**
 * Убирает из набора выбора id прокси, которых уже нет в списке: иначе счётчик
 * и подписи кнопок показывали бы удалённые строки.
 */
function pruneSelection() {
  if (!selectedProxies.size) return;
  const ids = new Set(state.proxies.map((proxy) => proxy.id));
  for (const id of Array.from(selectedProxies)) {
    if (!ids.has(id)) selectedProxies.delete(id);
  }
}

/**
 * Отмечает прокси выбранным или снимает отметку.
 *
 * @param {string} id
 * @param {boolean} selected
 */
function setProxySelected(id, selected) {
  if (!id) return;

  if (selected) {
    selectedProxies.add(id);
  } else {
    selectedProxies.delete(id);
  }

  // Обновляем строку без полной перерисовки: статусы проверки при этом
  // не сбрасываются.
  for (const row of els.proxyList.querySelectorAll('tr.proxy-row')) {
    if (row.dataset.proxyId !== id) continue;
    row.classList.toggle('proxy-row--selected', selected);
    const box = row.querySelector('input.proxy-select');
    if (box) box.checked = selected;
    break;
  }

  updateSelectionUi();
}

/**
 * Обновляет подписи кнопок, счётчик выбранных и состояние «выбрать все».
 *
 * Есть хотя бы один отмеченный прокси - кнопки работают по выбранным и
 * называются «Проверить» и «Удалить». Ничего не отмечено - по всему списку.
 */
function updateSelectionUi() {
  const selected = selectedProxies.size;
  const total = state.proxies.length;

  // Во время проверки подпись держит сама проверка («Проверка…») - и запущенная
  // этой страницей, и запущенная фоном.
  if (!testRunning && !progressRunning) {
    els.testAllProxiesButton.textContent = selected ? 'Проверить' : 'Проверить все';
    els.removeAllProxiesButton.textContent = selected ? 'Удалить' : 'Удалить все';
  }

  if (els.selectionInfo) {
    els.selectionInfo.textContent = selected ? `Выбрано прокси: ${selected}` : '';
    els.selectionInfo.hidden = !selected;
  }

  if (els.selectAllProxies) {
    els.selectAllProxies.disabled = total === 0;
    els.selectAllProxies.checked = total > 0 && selected === total;
    els.selectAllProxies.indeterminate = selected > 0 && selected < total;
  }
}

/**
 * Приводит настройку времён авто-теста к строке для поля ввода.
 * @param {Array<string>|string} value
 * @returns {string}
 */
function formatAutoTestTimes(value) {
  if (Array.isArray(value)) return value.join(', ');
  return String(value || '');
}

/**
 * Разбирает строку времён авто-теста в массив «HH:MM».
 *
 * Принимает значения через запятую, точку с запятой или пробел, в формате
 * «HH:MM» (допускается «H:MM» и «HH.MM»). Некорректные значения
 * отбрасываются, дубликаты убираются, результат сортируется по времени суток.
 *
 * @param {string} value
 * @returns {Array<string>}
 */
function parseAutoTestTimesInput(value) {
  const raw = String(value || '').split(/[,\s;]+/);
  const seen = new Set();
  const times = [];
  for (const item of raw) {
    const match = item.trim().match(/^([01]?\d|2[0-3])[:.]([0-5]\d)$/);
    if (!match) continue;
    const key = `${String(parseInt(match[1], 10)).padStart(2, '0')}:${match[2]}`;
    if (seen.has(key)) continue;
    seen.add(key);
    times.push(key);
  }
  times.sort();
  return times;
}

/**
 * Отрисовывает настройки авто-тестирования.
 */
function renderAutoTest() {
  const settings = state.settings || {};
  els.autoTestEnabledCheckbox.checked = settings.autoTestEnabled !== false;
  els.autoTestIntervalInput.value = settings.autoTestInterval || 15;
  els.autoTestTimesInput.value = formatAutoTestTimes(settings.autoTestTimes);
  els.autoDeleteDeadCheckbox.checked = settings.autoDeleteDead !== false;
  els.autoTestDeleteDeadCheckbox.checked = !!settings.autoTestDeleteDead;
  // «Удалять ограниченные»: включено по умолчанию.
  els.autoTestDeleteLimitedCheckbox.checked = settings.autoTestDeleteLimited !== false;
  els.autoTestRefillCheckbox.checked = !!settings.autoTestRefill;
  // «Отключаться от нерабочих»: работает независимо от авто-тестирования.
  els.disableOnDeadProxyCheckbox.checked = !!settings.disableOnDeadProxy;
  els.testUrlInput.value = settings.testUrl || '';
  els.testTimeoutInput.value = settings.testTimeout || 8000;
  els.testTargetSelect.value = settings.testTarget || 'google';
}

/**
 * Отрисовывает список проксируемых сайтов.
 */
function renderProxiedSites() {
  els.proxiedSitesTextarea.value = state.proxiedSites.join('\n');
}

/**
 * Отрисовывает настройки источников прокси.
 */
function renderSources() {
  const settings = state.settings || {};
  els.proxySourcesList.value = (state.sources || []).join('\n');
  els.sourcesLimitInput.value = settings.sourcesLimit || 0;

  // Заполняем список готовых подписок (один раз).
  if (!els.builtinSourceSelect.options.length) {
    for (const source of BUILTIN_SOURCES) {
      const option = document.createElement('option');
      option.value = source.id;
      option.textContent = source.name;
      els.builtinSourceSelect.appendChild(option);
    }
  }
}

/**
 * Добавляет выбранный готовый источник в список.
 * @returns {Promise<void>}
 */
async function addBuiltinSource() {
  const id = els.builtinSourceSelect.value;
  const source = BUILTIN_SOURCES.find((s) => s.id === id);
  if (!source) return;

  const current = els.proxySourcesList.value
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean);

  if (current.includes(source.url)) {
    flashStatus(els.sourcesStatus, 'Этот источник уже добавлен.');
    return;
  }

  current.push(source.url);
  els.proxySourcesList.value = current.join('\n');
  await saveSources();
  flashStatus(els.sourcesStatus, `Добавлен источник: ${source.name}`);
}

/**
 * Добавляет все готовые источники.
 * @returns {Promise<void>}
 */
async function addAllBuiltinSources() {
  const current = els.proxySourcesList.value
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean);

  let added = 0;
  for (const source of BUILTIN_SOURCES) {
    if (!current.includes(source.url)) {
      current.push(source.url);
      added += 1;
    }
  }

  els.proxySourcesList.value = current.join('\n');
  await saveSources();
  flashStatus(els.sourcesStatus, `Добавлено источников: ${added}`);
}

/**
 * Отрисовывает настройки фильтра по странам.
 */
function renderCountryFilter() {
  const settings = state.settings || {};
  els.countryFilterMode.value = settings.countryFilterMode || 'off';
  els.countryFilterBase.value = settings.countryFilterBase === 'exit' ? 'exit' : 'proxy';
  els.countryFilterList.value = (settings.countryFilterList || []).join(', ');
  els.countryFilterUnknownCheckbox.checked = !!settings.countryFilterUnknown;
  els.countryFilterAutoCheckbox.checked = !!settings.countryFilterAuto;

  // Заполняем список стран по выбранной базе: страна прокси или страна выхода.
  const countries = collectCountries(state.proxies, state.stats, settings.countryFilterBase);
  const current = els.keepOnlyCountrySelect.value;
  els.keepOnlyCountrySelect.innerHTML = '';
  for (const code of countries) {
    const option = document.createElement('option');
    option.value = code;
    option.textContent = code;
    els.keepOnlyCountrySelect.appendChild(option);
  }
  if (current && countries.includes(current)) {
    els.keepOnlyCountrySelect.value = current;
  }
}

/**
 * Показывает временное сообщение в статусе.
 * @param {HTMLElement} el
 * @param {string} text
 * @param {number} [timeout]
 */
function flashStatus(el, text, timeout = 4000) {
  if (!el) return;
  el.textContent = text;
  el.hidden = false;
  if (el._flashTimer) {
    clearTimeout(el._flashTimer);
    el._flashTimer = null;
  }
  if (timeout > 0) {
    el._flashTimer = setTimeout(() => {
      el.textContent = '';
      el.hidden = true;
      el._flashTimer = null;
    }, timeout);
  }
}

/**
 * Показывает постоянный статус (не скрывается сам).
 * @param {HTMLElement} el
 * @param {string} text
 */
function showStatus(el, text) {
  flashStatus(el, text, 0);
}

/**
 * Скрывает статус.
 * @param {HTMLElement} el
 */
function hideStatus(el) {
  if (!el) return;
  if (el._flashTimer) {
    clearTimeout(el._flashTimer);
    el._flashTimer = null;
  }
  el.textContent = '';
  el.hidden = true;
}

/**
 * Вставляет список прокси из буфера обмена.
 * @returns {Promise<void>}
 */
async function pasteProxies() {
  let text = '';
  try {
    text = await navigator.clipboard.readText();
  } catch (error) {
    log.error('options: не удалось прочитать буфер обмена', error);
    flashStatus(els.pasteStatus, 'Не удалось прочитать буфер обмена. Используйте Ctrl+V.');
    return;
  }

  if (!text || !text.trim()) {
    flashStatus(els.pasteStatus, 'Буфер обмена пуст.');
    return;
  }

  const response = await sendMessage({ type: 'addProxiesFromText', text });
  await loadState();
  render();

  if (response && response.ok !== false) {
    flashStatus(
      els.pasteStatus,
      `Найдено: ${response.parsed}, добавлено: ${response.added}, всего: ${response.total}`
    );
  } else {
    flashStatus(els.pasteStatus, 'Не удалось добавить прокси.');
  }
}

/**
 * Копирует все прокси в буфер обмена.
 * @returns {Promise<void>}
 */
async function copyAllProxies() {
  const lines = state.proxies.map((proxy) => formatProxyString(proxy));
  if (!lines.length) {
    flashStatus(els.pasteStatus, 'Список прокси пуст.');
    return;
  }
  try {
    await navigator.clipboard.writeText(lines.join('\n'));
    flashStatus(els.pasteStatus, `Скопировано прокси: ${lines.length}`);
  } catch (error) {
    log.error('options: не удалось записать в буфер обмена', error);
    flashStatus(els.pasteStatus, 'Не удалось скопировать.');
  }
}

/**
 * Сохраняет источники прокси.
 * @returns {Promise<void>}
 */
async function saveSources() {
  const sources = els.proxySourcesList.value
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean);

  await sendMessage({ type: 'setProxySources', sources });
  await saveSettings({
    // Лимит общего размера списка прокси: 0 - без ограничения.
    sourcesLimit: Math.max(0, parseInt(els.sourcesLimitInput.value, 10) || 0),
  });
  await loadState();
  render();
  flashStatus(els.sourcesStatus, `Сохранено источников: ${sources.length}`);
}

/**
 * Загружает прокси из источников.
 * @returns {Promise<void>}
 */
async function fetchSources() {
  els.fetchSourcesButton.disabled = true;
  els.fetchSourcesButton.textContent = 'Загрузка…';
  showStatus(els.sourcesStatus, 'Загрузка списков…');
  try {
    const response = await sendMessage({ type: 'fetchProxySources' });
    await loadState();
    render();
    if (response && response.ok !== false) {
      const errors = (response.errors || []).length;
      flashStatus(
        els.sourcesStatus,
        `Добавлено: ${response.added} из ${response.sources} источников${errors ? `, ошибок: ${errors}` : ''}`
      );
    } else {
      flashStatus(els.sourcesStatus, 'Не удалось загрузить источники.');
    }
  } finally {
    els.fetchSourcesButton.disabled = false;
    els.fetchSourcesButton.textContent = 'Загрузить сейчас';
  }
}

/**
 * Доопределяет страны прокси, у которых они ещё неизвестны.
 *
 * Отдельной кнопки нет: страны определяются автоматически при импорте списка,
 * при загрузке источников и при открытии этой страницы. Функция запускает
 * добор остатка и показывает результат в статусе.
 *
 * @returns {Promise<void>}
 */
async function detectCountries() {
  showStatus(els.countryDetectStatus, 'Определение стран…');
  try {
    // Ограничиваем порцию: при большом списке дозаполняем страны по частям,
    // чтобы открытие настроек не запускало сразу тысячи внешних запросов.
    const response = await sendMessage({ type: 'detectCountries', limit: 300 });
    await loadState();
    render();
    if (response && response.ok !== false) {
      flashStatus(
        els.countryDetectStatus,
        `Определено: ${response.detected} из ${response.total}`
      );
    } else {
      flashStatus(els.countryDetectStatus, 'Не удалось определить страны.');
    }
  } catch (error) {
    log.error('options: detectCountries', error);
  }
}

/**
 * Применяет фильтр по странам.
 * @returns {Promise<void>}
 */
async function applyCountryFilter() {
  const mode = els.countryFilterMode.value;
  const list = els.countryFilterList.value
    .split(/[,\s]+/)
    .map((s) => s.trim().toUpperCase())
    .filter(Boolean);

  await saveSettings({
    countryFilterMode: mode,
    countryFilterBase: els.countryFilterBase.value === 'exit' ? 'exit' : 'proxy',
    countryFilterList: list,
    countryFilterUnknown: els.countryFilterUnknownCheckbox.checked,
    countryFilterAuto: els.countryFilterAutoCheckbox.checked,
  });

  if (mode === 'off') {
    flashStatus(els.countryDetectStatus, 'Фильтр выключен.');
    return;
  }

  const response = await sendMessage({ type: 'applyCountryFilter' });
  await loadState();
  render();
  if (response && response.ok !== false) {
    flashStatus(
      els.countryDetectStatus,
      `Удалено: ${response.removed}, осталось: ${response.kept}`
    );
  }
}

/**
 * Оставляет только выбранную страну.
 * @returns {Promise<void>}
 */
async function keepOnlyCountry() {
  const country = els.keepOnlyCountrySelect.value;
  if (!country) {
    flashStatus(els.countryDetectStatus, 'Сначала определите страны.');
    return;
  }
  const response = await sendMessage({ type: 'keepOnlyCountry', country });
  await loadState();
  render();
  if (response && response.ok !== false) {
    flashStatus(
      els.countryDetectStatus,
      `Оставлено: ${response.kept}, удалено: ${response.removed}`
    );
  }
}

/**
 * Запускает проверку прокси и следит за прогрессом.
 *
 * Если отмечены чекбоксы - проверяются только выбранные прокси, иначе весь
 * список.
 *
 * @returns {Promise<void>}
 */
async function testAllProxies() {
  const ids = Array.from(selectedProxies);
  const scope = ids.length ? `выбранных прокси (${ids.length})` : 'прокси';

  els.testAllProxiesButton.disabled = true;
  testRunning = true;
  els.testAllProxiesButton.textContent = 'Проверка…';
  els.stopTestProxiesButton.disabled = false;
  els.stopTestProxiesButton.textContent = 'Остановить';
  els.stopTestProxiesButton.classList.remove('hidden');
  showStatus(els.proxyImportMsg, `Идёт проверка ${scope}…`);
  startProgressPolling();
  try {
    const response = await sendMessage({ type: 'testAllProxies', ids });
    await loadState();
    // После проверки список сразу показываем отсортированным по пингу:
    // самый быстрый рабочий прокси оказывается в первой строке.
    sortState.key = 'ping';
    sortState.dir = 'asc';
    render();

    if (response && response.aborted) {
      flashStatus(els.proxyImportMsg, 'Проверка остановлена.');
    } else if (response && response.started === false && response.running) {
      flashStatus(els.proxyImportMsg, 'Проверка уже идёт - дождитесь её окончания.');
    } else {
      flashStatus(els.proxyImportMsg, 'Проверка завершена.');
    }
  } finally {
    testRunning = false;
    els.testAllProxiesButton.disabled = false;
    updateSelectionUi();
    refreshProgress().catch((error) => log.debug('options: progress', error));
  }
}

/**
 * Останавливает проверку прокси.
 *
 * Кнопка сразу переходит в состояние «Останавливаю…»: сама проверка закроется
 * после того, как service worker прервёт текущий запрос, и тогда прогресс
 * исчезнет сам.
 *
 * @returns {Promise<void>}
 */
async function stopTestProxies() {
  log.info('options: остановка проверки');
  stopRequested = true;
  els.stopTestProxiesButton.disabled = true;
  els.stopTestProxiesButton.textContent = 'Останавливаю…';
  const response = await sendMessage({ type: 'stopTestProxies' });
  log.info('options: остановка отправлена', response);
  flashStatus(els.proxyImportMsg, 'Проверка остановлена.');
}

/**
 * Запускает постоянный опрос прогресса проверки.
 *
 * Проверка запускается не только кнопкой, но и в фоне (автозагрузка списков
 * с проверкой, таймер авто-тестирования). Поэтому опрос идёт всё время, пока
 * открыта страница настроек: иначе шаги «в очереди» и «проверка» не видны,
 * а список прокси при этом ещё и перерисовывается по изменениям хранилища.
 */
function startProgressPolling() {
  if (progressTimer) return;
  refreshProgress().catch((error) => log.debug('options: progress', error));
  progressTimer = setInterval(() => {
    refreshProgress().catch((error) => log.debug('options: progress', error));
  }, 1000);
}

/**
 * Синхронизирует прогресс-бар и статусы строк с состоянием проверки.
 * @returns {Promise<void>}
 */
async function refreshProgress() {
  const response = await sendMessage({ type: 'getProgress' });

  if (!response || response.ok === false) {
    // Service worker не ответил - значит проверка не идёт (он перезапустился).
    // Снимаем «зависший» прогресс, иначе кнопки остаются заблокированными.
    progressRunning = false;
    stopRequested = false;
    els.checkProgress.hidden = true;
    els.checkProgressFill.style.width = '0%';
    els.checkProgressText.textContent = '';
    els.stopTestProxiesButton.classList.add('hidden');
    els.stopTestProxiesButton.disabled = false;
    els.stopTestProxiesButton.textContent = 'Остановить';
    if (!testRunning) {
      els.testAllProxiesButton.disabled = false;
      updateSelectionUi();
    }
    return;
  }

  const { total, done, running, checking, queued, alive = 0, limited = 0, dead = 0 } =
    response.progress || {};

  lastRowStatus = { checking: checking || [], queued: queued || [] };

  if (running) {
    const percent = total ? Math.round((done / total) * 100) : 0;
    els.checkProgress.hidden = false;
    els.checkProgressFill.style.width = percent + '%';
    // Счётчики работающих и недоступных прокси приходят из service worker.
    // «Работает» - без ограниченных: ограниченный прокси не открыл тестовый
    // сайт, поэтому рабочим он не считается.
    els.checkProgressText.textContent =
      `Проверено ${done} из ${total} · работает: ${alive}, ограничено: ${limited}, недоступен: ${dead}`;

    // Проверка может идти и без участия этой страницы (таймер авто-тестирования,
    // автозагрузка источников). Кнопку «Остановить» показываем всё время, пока
    // проверка идёт: иначе остановить её из интерфейса невозможно.
    els.stopTestProxiesButton.classList.remove('hidden');
    els.stopTestProxiesButton.disabled = stopRequested;
    els.stopTestProxiesButton.textContent = stopRequested ? 'Останавливаю…' : 'Остановить';
    els.testAllProxiesButton.disabled = true;
    els.testAllProxiesButton.textContent = 'Проверка…';
  } else {
    els.checkProgress.hidden = true;
    els.checkProgressFill.style.width = '0%';
    els.checkProgressText.textContent = '';

    stopRequested = false;
    els.stopTestProxiesButton.classList.add('hidden');
    els.stopTestProxiesButton.disabled = false;
    els.stopTestProxiesButton.textContent = 'Остановить';

    // Проверка закончилась (в том числе остановленная): возвращаем кнопкам
    // обычные подписи и состояние.
    if (!testRunning) {
      els.testAllProxiesButton.disabled = false;
      updateSelectionUi();
    }
  }

  progressRunning = !!running;

  // Обновляем статусы строк: «проверка…» и «в очереди».
  updateRowStatuses(lastRowStatus.checking, lastRowStatus.queued);

  // Проверка только что завершилась: перечитываем статистику, чтобы у
  // последнего прокси статус сменился с «проверка…» на фактический.
  if (wasRunning && !running) {
    loadState()
      .then(() => render())
      .catch((error) => log.debug('options: обновление после проверки', error));
  }
  wasRunning = !!running;
}

/**
 * Обновляет статусы строк таблицы во время проверки.
 *
 * @param {Array<string>} checkingIds ID прокси, которые проверяются сейчас
 * @param {Array<string>} queuedIds ID прокси, которые стоят в очереди
 */
function updateRowStatuses(checkingIds, queuedIds) {
  const checking = new Set(checkingIds);
  const queued = new Set(queuedIds);
  const rows = els.proxyList.querySelectorAll('tr.proxy-row');
  for (const row of rows) {
    const id = row.dataset.proxyId;
    const statusCell = row.querySelector('.col-status');
    if (!statusCell) continue;

    if (checking.has(id)) {
      statusCell.textContent = 'проверка…';
      statusCell.classList.remove('status--ok', 'status--bad', 'status--warn', 'status--queued');
      statusCell.classList.add('status--checking');
    } else if (queued.has(id)) {
      statusCell.textContent = 'в очереди';
      statusCell.classList.remove('status--ok', 'status--bad', 'status--warn', 'status--checking');
      statusCell.classList.add('status--queued');
    } else {
      // Возвращаем обычный статус: иначе у последнего проверенного прокси
      // остаётся текст «проверка…», хотя проверка уже завершена.
      statusCell.classList.remove('status--checking', 'status--queued', 'status--ok', 'status--bad', 'status--warn');
      const info = proxyStatusInfo(state.stats[id]);
      statusCell.textContent = info.text;
      statusCell.title = info.title;
      if (info.className) statusCell.classList.add(info.className);
    }
  }
}

/**
 * Останавливает опрос прогресса.
 */
function stopProgressPolling() {
  if (progressTimer) {
    clearInterval(progressTimer);
    progressTimer = null;
  }
}

/**
 * Выполняет действие удаления прокси и обновляет UI.
 * @param {string} type
 * @param {string} label
 * @returns {Promise<void>}
 */
async function removeProxies(type, label) {
  const response = await sendMessage({ type });
  await loadState();
  render();
  if (response && response.ok !== false) {
    flashStatus(els.proxyImportMsg, `${label}: удалено ${response.removed || 0}`);
  }
}

/**
 * Сохраняет настройки.
 * @param {object} patch
 * @returns {Promise<void>}
 */
async function saveSettings(patch) {
  const response = await sendMessage({ type: 'setSettings', settings: patch });
  if (response && response.settings) {
    state.settings = response.settings;
  }
}

/**
 * Добавляет прокси из формы.
 * @returns {Promise<void>}
 */
async function addProxy() {
  els.proxyFormError.hidden = true;
  const raw = els.proxyServerInput.value.trim();
  const parsed = parseProxyString(raw);
  if (!parsed) {
    els.proxyFormError.textContent = 'Неверный прокси. Формат: хост:порт (например 83.147.216.208:1080).';
    els.proxyFormError.hidden = false;
    return;
  }

  // Дубликаты в список не попадают: такой же host:port уже добавлен.
  const key = `${parsed.host}:${parsed.port}`.toLowerCase();
  const duplicate = state.proxies.some(
    (item) => `${item.host}:${item.port}`.toLowerCase() === key
  );
  if (duplicate) {
    els.proxyFormError.textContent = 'Такой прокси уже есть в списке.';
    els.proxyFormError.hidden = false;
    return;
  }

  const proxy = {
    id: generateProxyId(),
    name: els.proxyNameInput.value.trim(),
    ...parsed,
  };

  const proxies = [...state.proxies, proxy];
  await sendMessage({ type: 'setProxies', proxies });
  await loadState();
  render();

  els.proxyNameInput.value = '';
  els.proxyServerInput.value = '';
}

/**
 * Удаляет прокси по id.
 * @param {string} id
 * @returns {Promise<void>}
 */
async function deleteProxy(id) {
  const proxies = state.proxies.filter((proxy) => proxy.id !== id);
  await sendMessage({ type: 'setProxies', proxies });
  await loadState();
  render();
}

/**
 * Делает прокси активным.
 * @param {object} proxy
 * @returns {Promise<void>}
 */
async function setActiveProxy(proxy) {
  await sendMessage({ type: 'setActiveProxy', proxy });
  await loadState();
  render();
}

/**
 * Сохраняет список проксируемых сайтов из textarea.
 * @returns {Promise<void>}
 */
async function saveProxiedSites() {
  const lines = els.proxiedSitesTextarea.value
    .split('\n')
    .map(normalizeDomain)
    .filter(Boolean);
  const unique = Array.from(new Set(lines));

  const response = await sendMessage({ type: 'setProxiedSites', domains: unique });
  await loadState();
  render();

  els.proxiedSitesStatus.textContent = `Сохранено доменов: ${
    (response && response.count) || unique.length
  }`;
  setTimeout(() => {
    els.proxiedSitesStatus.textContent = '';
  }, 3000);
}

/**
 * Добавляет в список проксируемых сайтов готовый набор сервисов ИИ.
 *
 * Кнопка нужна, чтобы не набирать домены руками: это ровно тот сценарий, для
 * которого расширение и сделано. Какие сайты оставить в списке, пользователь
 * решает сам - набор можно править или удалить целиком.
 *
 * @returns {Promise<void>}
 */
async function addAiSites() {
  const current = els.proxiedSitesTextarea.value
    .split('\n')
    .map(normalizeDomain)
    .filter(Boolean);
  const merged = Array.from(new Set([...current, ...AI_SITES]));

  const response = await sendMessage({ type: 'setProxiedSites', domains: merged });
  await loadState();
  render();

  const added = merged.length - Array.from(new Set(current)).length;
  els.proxiedSitesStatus.textContent = added
    ? `Добавлено сервисов ИИ: ${added}, всего сайтов: ${(response && response.count) || merged.length}`
    : 'Сервисы ИИ уже есть в списке';
  setTimeout(() => {
    els.proxiedSitesStatus.textContent = '';
  }, 4000);
  log.info('options: добавлены сервисы ИИ', { added, total: merged.length });
}

/**
 * Показывает состояние приватных окон.
 *
 * В приватные окна расширение пишет настройки отдельным скоупом, и только если
 * в браузере разрешено «Разрешено в режиме инкогнито». Если разрешения нет,
 * приватные окна работают напрямую - об этом и сообщаем пользователю вместо
 * непонятных ошибок ERR_PROXY_CONNECTION_FAILED.
 *
 * @returns {Promise<void>}
 */
async function renderIncognito() {
  if (!els.incognitoStatus) return;

  const response = await sendMessage({ type: 'getIncognitoState' });
  const state = (response && response.incognito) || 'unknown';

  if (state === 'allowed') {
    els.incognitoStatus.textContent = 'Разрешено в инкогнито: сайты из списка идут через прокси';
    // Зелёный: разрешение выдано, приватные окна работают через прокси.
    els.incognitoStatus.classList.remove('status--warn', 'status--bad');
    els.incognitoStatus.classList.add('status--ok');
    els.incognitoStatus.hidden = false;
    if (els.incognitoHint) {
      els.incognitoHint.textContent =
        'Приватные окна используют тот же прокси и тот же список сайтов, что и обычные окна.';
    }
    return;
  }

  if (state === 'denied') {
    els.incognitoStatus.textContent =
      'Не разрешено в инкогнито: приватные окна открываются напрямую. Нажмите кнопку ниже, найдите Q.Proxy и включите переключатель';
    // Красный: разрешения нет, приватные окна идут напрямую.
    els.incognitoStatus.classList.remove('status--ok', 'status--warn');
    els.incognitoStatus.classList.add('status--bad');
    els.incognitoStatus.hidden = false;
    return;
  }

  els.incognitoStatus.textContent = '';
  els.incognitoStatus.classList.remove('status--ok', 'status--warn', 'status--bad');
  els.incognitoStatus.hidden = true;
}

/**
 * Открывает страницу управления расширениями: там включается режим инкогнито.
 *
 * @returns {Promise<void>}
 */
async function openExtensionsPage() {
  const url = 'chrome://extensions/?id=' + chrome.runtime.id;
  try {
    await chrome.tabs.create({ url });
  } catch (error) {
    log.warn('options: не удалось открыть страницу расширений', error);
    if (els.incognitoStatus) {
      els.incognitoStatus.textContent =
        'Откройте chrome://extensions вручную, найдите Q.Proxy и включите «Разрешено в режиме инкогнито»';
      els.incognitoStatus.classList.remove('status--ok');
      els.incognitoStatus.classList.add('status--bad');
      els.incognitoStatus.hidden = false;
    }
  }
}

// ---------------------------------------------------------------------------
// Обработчики событий
// ---------------------------------------------------------------------------

els.enabledCheckbox.addEventListener('change', () => {
  saveSettings({ enabled: els.enabledCheckbox.checked }).catch((error) =>
    log.error('options: enabled', error)
  );
});

els.proxyAllTrafficCheckbox.addEventListener('change', () => {
  saveSettings({ proxyAllTraffic: els.proxyAllTrafficCheckbox.checked }).catch((error) =>
    log.error('options: proxyAllTraffic', error)
  );
});

// «Отключаться от нерабочих»: проверка активного прокси по навигации.
// Настройка не зависит от авто-тестирования.
els.disableOnDeadProxyCheckbox.addEventListener('change', () => {
  saveSettings({ disableOnDeadProxy: els.disableOnDeadProxyCheckbox.checked }).catch((error) =>
    log.error('options: disableOnDeadProxy', error)
  );
});

els.addProxyButton.addEventListener('click', () => {
  addProxy().catch((error) => log.error('options: addProxy', error));
});

els.proxyProtocolSelect.addEventListener('change', () => {
  const protocol = els.proxyProtocolSelect.value;
  log.info('options: смена протокола списка', protocol);
  saveSettings({ proxyProtocol: protocol }).catch((error) =>
    log.error('options: proxyProtocol', error)
  );
});

// Вставка списка из буфера.
els.pasteProxiesButton.addEventListener('click', () => {
  pasteProxies().catch((error) => log.error('options: pasteProxies', error));
});

// Готовые источники.
els.addBuiltinSourceButton.addEventListener('click', () => {
  addBuiltinSource().catch((error) => log.error('options: addBuiltinSource', error));
});

els.addAllBuiltinSourcesButton.addEventListener('click', () => {
  addAllBuiltinSources().catch((error) => log.error('options: addAllBuiltinSources', error));
});

// Копирование всех прокси.
els.copyAllProxiesButton.addEventListener('click', () => {
  copyAllProxies().catch((error) => log.error('options: copyAllProxies', error));
});

// Источники.
els.saveSourcesButton.addEventListener('click', () => {
  saveSources().catch((error) => log.error('options: saveSources', error));
});

els.fetchSourcesButton.addEventListener('click', () => {
  fetchSources().catch((error) => log.error('options: fetchSources', error));
});

// Лимит прокси: сколько всего держать в списке (0 - без ограничения).
els.sourcesLimitInput.addEventListener('change', () => {
  const value = Math.max(0, parseInt(els.sourcesLimitInput.value, 10) || 0);
  els.sourcesLimitInput.value = value;
  saveSettings({ sourcesLimit: value }).catch((error) =>
    log.error('options: sourcesLimit', error)
  );
});

// Страны.
els.applyCountryFilterButton.addEventListener('click', () => {
  applyCountryFilter().catch((error) => log.error('options: applyCountryFilter', error));
});

els.keepOnlyCountryButton.addEventListener('click', () => {
  keepOnlyCountry().catch((error) => log.error('options: keepOnlyCountry', error));
});

els.countryFilterUnknownCheckbox.addEventListener('change', () => {
  saveSettings({ countryFilterUnknown: els.countryFilterUnknownCheckbox.checked }).catch((error) =>
    log.error('options: countryFilterUnknown', error)
  );
});

els.countryFilterAutoCheckbox.addEventListener('change', () => {
  saveSettings({ countryFilterAuto: els.countryFilterAutoCheckbox.checked }).catch((error) =>
    log.error('options: countryFilterAuto', error)
  );
});

// База фильтра: страна прокси или страна выхода.
els.countryFilterBase.addEventListener('change', () => {
  const base = els.countryFilterBase.value === 'exit' ? 'exit' : 'proxy';
  saveSettings({ countryFilterBase: base })
    .then(() => loadState())
    .then(() => render())
    .catch((error) => log.error('options: countryFilterBase', error));
});

// Проверка.
els.testTargetSelect.addEventListener('change', () => {
  saveSettings({ testTarget: els.testTargetSelect.value }).catch((error) =>
    log.error('options: testTarget', error)
  );
});

els.testAllProxiesButton.addEventListener('click', () => {
  testAllProxies().catch((error) => log.error('options: testAllProxies', error));
});

els.stopTestProxiesButton.addEventListener('click', () => {
  stopTestProxies().catch((error) => log.error('options: stopTestProxies', error));
});

els.removeDeadProxiesButton.addEventListener('click', () => {
  removeProxies('removeDeadProxies', 'Нерабочие').catch((error) =>
    log.error('options: removeDeadProxies', error)
  );
});

els.removeUntestedProxiesButton.addEventListener('click', () => {
  removeProxies('removeUntestedProxies', 'Непроверенные').catch((error) =>
    log.error('options: removeUntestedProxies', error)
  );
});

// Изменение чекбокса в строке.
els.proxyList.addEventListener('change', (event) => {
  const box = event.target;
  if (!box || !box.classList || !box.classList.contains('proxy-select')) return;
  setProxySelected(box.dataset.proxyId, box.checked);
});

// Клик по строке (вне кнопок и полей ввода) тоже переключает выбор.
els.proxyList.addEventListener('click', (event) => {
  const target = event.target;
  if (!target || typeof target.closest !== 'function') return;

  const row = target.closest('tr.proxy-row');
  if (!row) return;
  if (target.closest('button, input, a, select, textarea')) return;

  const box = row.querySelector('input.proxy-select');
  if (!box) return;
  setProxySelected(row.dataset.proxyId, !box.checked);
});

// «Выбрать все» в шапке таблицы.
els.selectAllProxies.addEventListener('change', () => {
  const checked = els.selectAllProxies.checked;
  selectedProxies.clear();
  if (checked) {
    for (const proxy of state.proxies) selectedProxies.add(proxy.id);
  }

  for (const row of els.proxyList.querySelectorAll('tr.proxy-row')) {
    const box = row.querySelector('input.proxy-select');
    if (box) box.checked = checked;
    row.classList.toggle('proxy-row--selected', checked);
  }

  updateSelectionUi();
});

// Удаление: есть отмеченные - удаляем только их, иначе весь список.
els.removeAllProxiesButton.addEventListener('click', async () => {
  if (!selectedProxies.size) {
    await sendMessage({ type: 'setProxies', proxies: [] });
    await loadState();
    render();
    return;
  }

  const removed = selectedProxies.size;
  const proxies = state.proxies.filter((proxy) => !selectedProxies.has(proxy.id));
  selectedProxies.clear();

  await sendMessage({ type: 'setProxies', proxies });
  await loadState();
  render();
  flashStatus(els.proxyImportMsg, `Удалено выбранных прокси: ${removed}`);
  log.info('options: удалены выбранные прокси', { removed, left: proxies.length });
});

els.autoTestEnabledCheckbox.addEventListener('change', () => {
  saveSettings({ autoTestEnabled: els.autoTestEnabledCheckbox.checked }).catch((error) =>
    log.error('options: autoTestEnabled', error)
  );
});

// Интервал авто-теста в минутах. Работает, только если не задано точное
// время проверок: расписание берёт «Время проверок», иначе - интервал.
els.autoTestIntervalInput.addEventListener('change', () => {
  const value = Math.max(1, parseInt(els.autoTestIntervalInput.value, 10) || 15);
  els.autoTestIntervalInput.value = value;
  saveSettings({ autoTestInterval: value }).catch((error) =>
    log.error('options: autoTestInterval', error)
  );
});

// Точное время авто-теста: «09:00, 15:00, 21:00». Некорректные значения
// отбрасываются, дубликаты убираются, порядок приводится к возрастанию.
els.autoTestTimesInput.addEventListener('change', () => {
  const times = parseAutoTestTimesInput(els.autoTestTimesInput.value);
  els.autoTestTimesInput.value = times.join(', ');
  saveSettings({ autoTestTimes: times }).catch((error) =>
    log.error('options: autoTestTimes', error)
  );
});

els.autoTestDeleteDeadCheckbox.addEventListener('change', () => {
  saveSettings({ autoTestDeleteDead: els.autoTestDeleteDeadCheckbox.checked }).catch((error) =>
    log.error('options: autoTestDeleteDead', error)
  );
});

els.autoTestDeleteLimitedCheckbox.addEventListener('change', () => {
  saveSettings({ autoTestDeleteLimited: els.autoTestDeleteLimitedCheckbox.checked }).catch(
    (error) => log.error('options: autoTestDeleteLimited', error)
  );
});

els.autoTestRefillCheckbox.addEventListener('change', () => {
  saveSettings({ autoTestRefill: els.autoTestRefillCheckbox.checked }).catch((error) =>
    log.error('options: autoTestRefill', error)
  );
});

els.autoDeleteDeadCheckbox.addEventListener('change', () => {
  saveSettings({ autoDeleteDead: els.autoDeleteDeadCheckbox.checked }).catch((error) =>
    log.error('options: autoDeleteDead', error)
  );
});

els.testUrlInput.addEventListener('change', () => {
  saveSettings({ testUrl: els.testUrlInput.value.trim() }).catch((error) =>
    log.error('options: testUrl', error)
  );
});

els.testTimeoutInput.addEventListener('change', () => {
  const value = Math.max(1000, parseInt(els.testTimeoutInput.value, 10) || 8000);
  els.testTimeoutInput.value = value;
  saveSettings({ testTimeout: value }).catch((error) =>
    log.error('options: testTimeout', error)
  );
});

els.saveProxiedSitesButton.addEventListener('click', () => {
  saveProxiedSites().catch((error) => log.error('options: saveProxiedSites', error));
});

els.addAiSitesButton.addEventListener('click', () => {
  addAiSites().catch((error) => log.error('options: addAiSites', error));
});

els.openExtensionsPageButton.addEventListener('click', () => {
  openExtensionsPage().catch((error) => log.error('options: openExtensionsPage', error));
});

// Пользователь мог переключить режим инкогнито на странице расширений и вернуться
// сюда: при возврате фокуса состояние перечитывается.
window.addEventListener('focus', () => {
  renderIncognito().catch((error) => log.debug('options: состояние инкогнито', error));
});

// Навигация по разделам.
for (const item of els.navItems) {
  item.addEventListener('click', () => {
    switchSection(item.dataset.target);
  });
}

// Обновляем UI при изменениях в хранилище.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  loadState()
    .then(render)
    .catch((error) => log.error('options: storage change', error));
});

(async () => {
  await loadState();
  render();
  switchSection('section-proxies');
  initSortableHeaders();
  renderIncognito().catch((error) => log.debug('options: состояние инкогнито', error));
  // Проверка может идти прямо сейчас (в том числе фоновая) - сразу
  // подхватываем её статусы и прогресс.
  startProgressPolling();

  // Если у части прокси страна ещё не определена, дозаполняем её сразу при
  // открытии настроек: без этого колонка «Страна» остаётся с прочерками.
  const withoutCountry = (state.proxies || []).filter((proxy) => !proxy.country).length;
  if (withoutCountry) {
    log.info('options: автозаполнение стран', { count: withoutCountry });
    detectCountries().catch((error) => log.error('options: автозаполнение стран', error));
  }
})().catch((error) => log.error('options: init', error));
