/**
 * Q.Proxy - логика popup.
 *
 * Показывает текущий сайт, круглую кнопку «через прокси / напрямую»
 * и сканирование связанных доменов.
 */

// Защитный fallback, если logger.js не загрузился.
const log =
  window.QProxyLog ||
  {
    debug() {},
    info() {},
    warn() {},
    error() {},
  };

log.info('popup: скрипт загружен');

if (!window.QProxyStorage) {
  log.error('popup: QProxyStorage не найден - storage.js не загрузился');
}

const { normalizeDomain, domainMatches, isProxied, formatProxyString } = window.QProxyStorage;

const els = {
  currentDomain: document.getElementById('currentDomain'),
  proxyStatus: document.getElementById('proxyStatus'),
  siteFavicon: document.getElementById('siteFavicon'),
  openOptionsPage: document.getElementById('openOptionsPage'),
  proxyPowerButton: document.getElementById('proxyPowerButton'),
  proxyToggleHint: document.getElementById('proxyToggleHint'),
  proxyPickList: document.getElementById('proxyPickList'),
  findRelatedDomainsButton: document.getElementById('findRelatedDomainsButton'),
  relatedDomainsStatus: document.getElementById('relatedDomainsStatus'),
  relatedDomainsList: document.getElementById('relatedDomainsList'),
  relatedDomainsSelectAll: document.getElementById('relatedDomainsSelectAll'),
  proxyNotice: document.getElementById('proxyNotice'),
  proxyNoticeText: document.getElementById('proxyNoticeText'),
  proxyNoticeClose: document.getElementById('proxyNoticeClose'),
};

// Сообщение о замене прокси устарело и уже убрано из хранилища: повторно
// отправлять просьбу о его очистке не нужно.
let staleNoticeCleared = false;

// Версия из manifest.json: показывается внизу попапа, править вручную не нужно.
const footerVersion = document.getElementById('footerVersion');
if (footerVersion) {
  footerVersion.textContent = 'Версия ' + chrome.runtime.getManifest().version;
}

const HINTS = {
  true: 'Сайт добавлен в список проксируемых',
  false: 'Сайт открывается напрямую',
};

// Сколько показывать уведомление о замене нерабочего прокси, мс.
const NOTICE_TTL = 30 * 60 * 1000;

let currentHostname = '';
let currentTabId = null;
// Открыт ли попап в приватном окне: там прокси работает только при
// разрешении «Разрешено в режиме инкогнито».
let currentTabIncognito = false;
let foundDomains = [];
// Текущее состояние кнопки: сайт открывается через прокси или напрямую.
let currentProxied = false;

/**
 * Отправляет сообщение в service worker.
 * @param {object} message
 * @returns {Promise<object>}
 */
function sendMessage(message) {
  log.debug('popup → background:', message.type, message);
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        log.error('popup: ошибка sendMessage:', chrome.runtime.lastError.message);
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      log.debug('popup ← background:', message.type, response);
      resolve(response || { ok: false });
    });
  });
}

/**
 * Возвращает активную вкладку.
 * @returns {Promise<chrome.tabs.Tab|null>}
 */
async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs.length ? tabs[0] : null;
}

/**
 * Устанавливает состояние круглой кнопки: включена (зелёная) - сайт идёт
 * через прокси, выключена (серая) - напрямую.
 * @param {boolean} proxied
 */
function setToggleState(proxied) {
  currentProxied = !!proxied;
  els.proxyPowerButton.classList.toggle('power__btn--on', currentProxied);
  els.proxyPowerButton.setAttribute('aria-pressed', currentProxied ? 'true' : 'false');
  els.proxyPowerButton.title = currentProxied
    ? 'Сайт открывается через прокси. Нажмите, чтобы открывать напрямую'
    : 'Сайт открывается напрямую. Нажмите, чтобы открывать через прокси';
  els.proxyToggleHint.textContent = HINTS[String(currentProxied)] || '';
}

/**
 * Флаг страны по двухбуквенному коду.
 * @param {string} code
 * @returns {string}
 */
function countryFlag(code) {
  const letters = String(code || '').trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(letters)) return '';
  return String.fromCodePoint(
    ...[...letters].map((ch) => 0x1f1e6 + (ch.charCodeAt(0) - 65))
  );
}

/**
 * Подпись страны: флаг и код, либо пустая строка.
 * @param {string} code
 * @returns {string}
 */
function countryLabel(code) {
  const value = String(code || '').trim().toUpperCase();
  if (!value) return '';
  const flag = countryFlag(value);
  return flag ? `${flag} ${value}` : value;
}

/**
 * Оценка прокси для списка быстрого переключения: сначала те, через которые
 * открывается тестовый сайт, затем по возрастанию пинга.
 * @param {object} stat
 * @returns {number}
 */
function proxyScore(stat) {
  const data = stat || {};
  const ping = data.ping != null ? data.ping : 999999;
  return (data.siteLatency == null ? 1000000 : 0) + ping;
}

/**
 * Список для быстрого переключения: активный прокси и три лучших рабочих.
 * «Ограниченные» прокси (сайт через них не открылся) в список не попадают:
 * по умолчанию пользователю предлагаются только полностью рабочие.
 * @param {object} state
 * @returns {Array<object>}
 */
function pickableProxies(state) {
  const stats = state.stats || {};
  const active = state.activeProxy;
  const works = (state.proxies || [])
    .filter((proxy) => {
      const stat = stats[proxy.id];
      return stat && stat.alive && stat.siteLatency != null;
    })
    .sort((a, b) => proxyScore(stats[a.id]) - proxyScore(stats[b.id]));

  const list = [];
  if (active) list.push(active);
  for (const proxy of works) {
    if (list.length >= 4) break;
    if (list.some((item) => item.id === proxy.id)) continue;
    list.push(proxy);
  }
  return list;
}

/**
 * Отрисовывает список прокси для быстрого переключения.
 * @param {object} state
 */
function renderProxyPick(state) {
  els.proxyPickList.innerHTML = '';
  const stats = state.stats || {};
  const activeId = state.activeProxy ? state.activeProxy.id : '';
  const list = pickableProxies(state);

  if (!list.length) {
    const empty = document.createElement('div');
    empty.className = 'proxy-pick__empty';
    empty.textContent = 'Нет проверенных рабочих прокси';
    els.proxyPickList.appendChild(empty);
    return;
  }

  for (const proxy of list) {
    const stat = stats[proxy.id] || {};
    const isActive = proxy.id === activeId;

    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'proxy-pick__item' + (isActive ? ' proxy-pick__item--active' : '');
    item.title = isActive ? 'Текущий прокси' : 'Сделать активным';

    const address = document.createElement('span');
    address.className = 'proxy-pick__address';
    address.textContent = formatProxyString(proxy);

    const meta = document.createElement('span');
    meta.className = 'proxy-pick__meta';
    const parts = [];
    if (isActive) parts.push('активен');
    const country = countryLabel(proxy.country);
    if (country) parts.push(country);
    if (stat.ping != null) parts.push(`${stat.ping} мс`);
    meta.textContent = parts.join(' · ');

    item.appendChild(address);
    item.appendChild(meta);
    item.addEventListener('click', () => {
      if (isActive) return;
      chooseProxy(proxy).catch((error) => log.error('popup: chooseProxy', error));
    });

    els.proxyPickList.appendChild(item);
  }
}

/**
 * Делает прокси активным и обновляет попап.
 * @param {object} proxy
 * @returns {Promise<void>}
 */
async function chooseProxy(proxy) {
  log.info('popup: переключение активного прокси', formatProxyString(proxy));
  const response = await sendMessage({ type: 'setActiveProxy', proxy });
  if (response && response.ok === false) {
    log.error('popup: не удалось переключить прокси', response.error);
    return;
  }

  const state = await sendMessage({ type: 'getState' });
  if (state && state.ok !== false) {
    renderProxyPick(state);
    if (currentHostname) {
      updateStatus(state, isProxied(currentHostname, state.proxiedSites || []));
    }
  }
}

/**
 * Инициализирует popup.
 * @returns {Promise<void>}
 */
async function init() {
  log.info('popup: инициализация');
  const tab = await getActiveTab();
  if (!tab || !tab.url) {
    log.warn('popup: нет активной вкладки');
    els.currentDomain.textContent = '-';
    els.proxyStatus.textContent = 'Нет активной вкладки';
    return;
  }

  currentTabId = tab.id;
  currentTabIncognito = !!tab.incognito;
  log.debug('popup: активная вкладка', {
    id: tab.id,
    url: tab.url,
    incognito: currentTabIncognito,
  });

  let hostname = '';
  try {
    hostname = new URL(tab.url).hostname;
  } catch (error) {
    log.warn('popup: не удалось разобрать URL', tab.url);
    hostname = '';
  }

  currentHostname = normalizeDomain(hostname);
  els.currentDomain.textContent = currentHostname || '-';
  log.info('popup: домен', currentHostname || '(нет)');

  if (currentHostname) {
    els.siteFavicon.style.backgroundImage = `url(https://www.google.com/s2/favicons?domain=${encodeURIComponent(
      currentHostname
    )}&sz=64)`;
  }

  // Состояние запрашиваем всегда: список прокси нужен и на служебных страницах.
  const state = await sendMessage({ type: 'getState' });
  if (!state || state.ok === false) {
    log.error('popup: не удалось получить состояние', state);
    return;
  }

  renderProxyPick(state);
  renderProxyNotice(state);

  if (!currentHostname) {
    els.proxyStatus.textContent = 'Служебная страница';
    return;
  }

  const proxied = isProxied(currentHostname, state.proxiedSites || []);
  log.info('popup: сайт проксируется?', proxied);
  log.debug('popup: состояние', {
    proxiedSites: state.proxiedSites,
    activeProxy: state.activeProxy,
    enabled: state.settings && state.settings.enabled,
  });
  setToggleState(proxied);
  updateStatus(state, proxied);
}

/**
 * Показывает уведомление о том, что активный прокси был признан нерабочим и
 * заменён автоматически. Уведомление показывается, пока оно свежее: через
 * NOTICE_TTL минут оно считается устаревшим и скрывается.
 *
 * @param {object} state
 */
function renderProxyNotice(state) {
  if (!els.proxyNotice) return;

  const notice = state && state.notice;
  const fresh = notice && notice.at && Date.now() - notice.at < NOTICE_TTL;
  if (!fresh) {
    if (els.proxyNoticeText) els.proxyNoticeText.textContent = '';
    els.proxyNotice.hidden = true;
    // Устаревшее уведомление убираем и из хранилища: значок «!» на иконке
    // расширения снимается вместе с ним, иначе он висел бы вечно. Просим один
    // раз за открытие попапа.
    if (notice && !staleNoticeCleared) {
      staleNoticeCleared = true;
      sendMessage({ type: 'clearProxyNotice' }).catch((error) =>
        log.debug('popup: устаревшее уведомление убрано', error)
      );
    }
    return;
  }

  const text = notice.to
    ? `Прокси ${notice.from} не открыл сайт и помечен ограниченным. Включён ${notice.to} - обновите страницу.`
    : `Прокси ${notice.from} не открыл сайт и помечен ограниченным. Других прокси в списке нет.`;
  if (els.proxyNoticeText) els.proxyNoticeText.textContent = text;
  els.proxyNotice.hidden = false;
}

/**
 * Закрывает уведомление: скрывает его в попапе и просит service worker убрать
 * значок «!» с иконки расширения.
 */
function closeProxyNotice() {
  if (els.proxyNotice) els.proxyNotice.hidden = true;
  sendMessage({ type: 'clearProxyNotice' }).catch((error) =>
    log.debug('popup: уведомление закрыто', error)
  );
}

/**
 * Обновляет строку статуса под доменом.
 *
 * Показывает состояние именно для текущего сайта:
 *  - если сайт проксируется - какой прокси используется;
 *  - если нет - что трафик идёт напрямую.
 *
 * @param {object} state
 * @param {boolean} proxied
 */
function updateStatus(state, proxied) {
  const settings = state.settings || {};
  const activeProxy = state.activeProxy;

  els.proxyStatus.classList.remove('site__status--proxied', 'site__status--direct');

  // Приватное окно без разрешения инкогнито: прокси здесь не применяется.
  // Пользователь должен видеть причину, а не думать, что сломалось расширение.
  if (currentTabIncognito && state.incognito === 'denied') {
    els.proxyStatus.textContent =
      'Приватное окно: включите «Разрешено в режиме инкогнито» в настройках расширений';
    els.proxyStatus.classList.add('site__status--direct');
    return;
  }

  if (settings.enabled === false) {
    els.proxyStatus.textContent = 'Проксирование выключено в настройках';
    els.proxyStatus.classList.add('site__status--direct');
    return;
  }

  if (!proxied) {
    els.proxyStatus.textContent = 'Трафик идёт напрямую';
    els.proxyStatus.classList.add('site__status--direct');
    return;
  }

  if (activeProxy) {
    // Страна входа (где стоит прокси) и выхода (что видят сайты) - только
    // код страны, без флага, чтобы строка не разрасталась.
    const stat = (state.stats || {})[activeProxy.id] || {};
    const parts = [`Через прокси ${activeProxy.host}:${activeProxy.port}`];
    const entry = String(activeProxy.country || '').trim().toUpperCase();
    const exit = String(stat.exitCountry || '').trim().toUpperCase();
    if (entry) parts.push(`вх ${entry}`);
    if (exit) parts.push(`вых ${exit}`);
    els.proxyStatus.textContent = parts.join(' · ');
    els.proxyStatus.classList.add('site__status--proxied');
  } else {
    els.proxyStatus.textContent = 'Прокси не выбран - добавьте в настройках';
    els.proxyStatus.classList.add('site__status--direct');
  }
}

/**
 * Обрабатывает переключение проксирования для сайта.
 * @param {boolean} proxied
 * @returns {Promise<void>}
 */
async function onToggle(proxied) {
  if (!currentHostname) {
    log.warn('popup: переключение без домена - игнорируем');
    return;
  }
  log.info('popup: переключение сайта', { hostname: currentHostname, proxied });
  setToggleState(proxied);

  const response = await sendMessage({
    type: 'setSiteProxied',
    hostname: currentHostname,
    proxied,
  });

  if (response && response.ok === false) {
    log.error('popup: не удалось сохранить', response.error);
    return;
  }

  // Обновляем статус под доменом, чтобы он отражал новое состояние.
  const state = await sendMessage({ type: 'getState' });
  if (state && state.ok !== false) {
    updateStatus(state, proxied);
  }
}

/**
 * Сканирует страницу и собирает домены ресурсов.
 * @returns {Promise<void>}
 */
async function scanRelatedDomains() {
  if (!currentTabId) return;

  els.relatedDomainsStatus.hidden = false;
  els.relatedDomainsStatus.textContent = 'Сканирование страницы…';
  els.relatedDomainsList.innerHTML = '';
  els.relatedDomainsSelectAll.classList.add('hidden');

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: currentTabId, allFrames: true },
      func: collectPageDomains,
    });

    const domains = new Set();
    for (const frame of results || []) {
      const list = (frame && frame.result) || [];
      for (const domain of list) {
        const normalized = normalizeDomain(domain);
        if (!normalized) continue;
        if (normalized === currentHostname) continue;
        if (domainMatches(normalized, currentHostname)) continue;
        domains.add(normalized);
      }
    }

    foundDomains = Array.from(domains).sort();

    if (!foundDomains.length) {
      els.relatedDomainsStatus.textContent = 'Дополнительных доменов не найдено.';
      return;
    }

    els.relatedDomainsStatus.textContent = `Найдено доменов: ${foundDomains.length}`;
    renderRelatedDomains();
    els.relatedDomainsSelectAll.classList.remove('hidden');
  } catch (error) {
    log.error('popup: ошибка сканирования', error);
    els.relatedDomainsStatus.textContent =
      'Не удалось просканировать страницу: ' + (error && error.message ? error.message : error);
  }
}

/**
 * Функция, выполняемая в контексте страницы для сбора доменов.
 * @returns {Array<string>}
 */
function collectPageDomains() {
  const domains = new Set();

  /**
   * Добавляет домен из URL.
   * @param {string} url
   */
  function addUrl(url) {
    if (!url) return;
    try {
      const parsed = new URL(url, location.href);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        domains.add(parsed.hostname);
      }
    } catch (error) {
      /* игнорируем некорректные URL */
    }
  }

  try {
    const entries = performance.getEntriesByType('resource');
    for (const entry of entries) {
      addUrl(entry.name);
    }
  } catch (error) {
    /* игнорируем */
  }

  const selectors = [
    'a[href]',
    'script[src]',
    'img[src]',
    'iframe[src]',
    'link[href]',
    'source[src]',
    'video[src]',
    'audio[src]',
  ];
  for (const selector of selectors) {
    const nodes = document.querySelectorAll(selector);
    for (const node of nodes) {
      addUrl(node.getAttribute('src') || node.getAttribute('href'));
    }
  }

  return Array.from(domains);
}

/**
 * Отрисовывает список найденных доменов с чекбоксами.
 */
function renderRelatedDomains() {
  els.relatedDomainsList.innerHTML = '';
  for (const domain of foundDomains) {
    const row = document.createElement('label');
    row.className = 'domain-chip';

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.value = domain;
    checkbox.checked = true;

    const text = document.createElement('span');
    text.className = 'domain-chip__text';
    text.textContent = domain;

    row.appendChild(checkbox);
    row.appendChild(text);
    els.relatedDomainsList.appendChild(row);
  }
}

/**
 * Добавляет выбранные домены в список проксируемых сайтов.
 * @returns {Promise<void>}
 */
async function addSelectedDomains() {
  const checkboxes = els.relatedDomainsList.querySelectorAll('input[type="checkbox"]');
  const selected = [];
  for (const checkbox of checkboxes) {
    if (checkbox.checked) selected.push(checkbox.value);
  }
  if (!selected.length) return;

  await sendMessage({ type: 'addProxiedSites', domains: selected });
  els.relatedDomainsStatus.textContent = `Добавлено доменов: ${selected.length}`;
  els.relatedDomainsSelectAll.classList.add('hidden');
}

// ---------------------------------------------------------------------------
// Обработчики событий
// ---------------------------------------------------------------------------

// Один клик по круглой кнопке переключает режим для текущего сайта.
els.proxyPowerButton.addEventListener('click', () => {
  const proxied = !currentProxied;
  log.debug('popup: клик по кнопке проксирования', proxied);
  onToggle(proxied).catch((error) => log.error('popup: onToggle', error));
});

els.findRelatedDomainsButton.addEventListener('click', () => {
  log.debug('popup: клик «Просканировать»');
  scanRelatedDomains().catch((error) => log.error('popup: scan', error));
});

els.relatedDomainsSelectAll.addEventListener('click', () => {
  log.debug('popup: клик «Добавить все»');
  addSelectedDomains().catch((error) => log.error('popup: addDomains', error));
});

els.openOptionsPage.addEventListener('click', () => {
  log.info('popup: открытие настроек');
  chrome.runtime.openOptionsPage();
});

// Крестик в уведомлении о замене прокси.
if (els.proxyNoticeClose) {
  els.proxyNoticeClose.addEventListener('click', () => {
    log.info('popup: уведомление о замене прокси закрыто');
    closeProxyNotice();
  });
}

init().catch((error) => log.error('popup: init', error));
