// Значения по умолчанию (берутся из config.js если он загружен)
const DEFAULT_MANAGERS = (window.AppConfig && window.AppConfig.defaultManagers) 
    ? window.AppConfig.defaultManagers 
    : ["Петров Владислав Владиславович"];

const DEFAULT_PAIRS = (window.AppConfig && window.AppConfig.defaultPairs)
    ? window.AppConfig.defaultPairs
    : [
        "КЦЕ_НП_Е_Тула_БИТ_Е",
        "КЦЕ_НП_Е_Тула_ТКЦ1_ГБ",
        "АП_НП_П_Москва_ГПНК1_ГБ_УД",
        "АП_НП_П_Краснодар_ГПНК1_ГБ_УД",
        "КЦЕ_НП_Е_Тула_ТКЦ2_БУХ",
        "КЦЕ_НП_Е_Тула_ТКЦ3_ФД",
        "КЦЕ_НП_Е_Тула_ТКЦ4_ГБ",
        "КЦЕ_НП_Е_Тула_ТКЦ5_ПР_КиHR",
        "КЦЕ_НП_Е_Тула_ТКЦ7_ГБ",
        "КЦЕ_НП_Е_Тула_ТКЦ8_БУХ"
    ];

// Загрузка настроек
async function loadSettings() {
    const storage = await chrome.storage.sync.get(['managers', 'pairs']);
    
    const managers = storage.managers || DEFAULT_MANAGERS;
    const pairs = storage.pairs || DEFAULT_PAIRS;
    
    document.getElementById('managersList').value = managers.join('\n');
    document.getElementById('pairsList').value = pairs.join('\n');
}

// Сохранение
document.getElementById('saveBtn').addEventListener('click', async () => {
    const managersText = document.getElementById('managersList').value;
    const managers = managersText.split(/\r?\n/).filter(s => s.trim().length > 0);
    
    const pairsText = document.getElementById('pairsList').value;
    const pairs = pairsText.split(/\r?\n/).filter(s => s.trim().length > 0);
    
    if (managers.length === 0) {
        const status = document.getElementById('status');
        status.textContent = '❌ Укажите хотя бы одного руководителя';
        status.className = 'error';
        return;
    }
    if (pairs.length === 0) {
        const status = document.getElementById('status');
        status.textContent = '❌ Укажите хотя бы одно подразделение';
        status.className = 'error';
        return;
    }
    
    await chrome.storage.sync.set({ managers, pairs });
    
    const status = document.getElementById('status');
    status.textContent = '✅ Настройки сохранены';
    status.className = 'success';
    setTimeout(() => {
        status.textContent = '';
        status.className = '';
    }, 2000);
});

document.addEventListener('DOMContentLoaded', loadSettings);