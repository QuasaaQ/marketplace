// content.js – исправленная версия
if (window.self !== window.top) {
    console.log('A.MOTIVAC: скрипт выполняется во фрейме, пропускаем');
} else {
    console.log('A.MOTIVAC: content script загружен, ожидаю команду');

    let isProcessing = false;

    chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
        if (request.action === 'fillReport') {
            if (isProcessing) {
                console.log('A.MOTIVAC: уже выполняется, игнорирую');
                return;
            }
            isProcessing = true;
            try {
                const { startDate, managers, pairs } = request.config;
                await runActions(startDate, managers, pairs);
            } catch (err) {
                console.error('A.MOTIVAC: ошибка выполнения:', err);
            } finally {
                isProcessing = false;
                chrome.runtime.sendMessage({ action: 'taskFinished' }).catch(() => {});
            }
        }
    });
}

// ---------- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ----------

function waitForIframe() {
    return new Promise((resolve) => {
        const iframe = document.querySelector('iframe.viewer, iframe[title*="Средство просмотра отчетов"]');
        if (iframe?.contentDocument?.readyState === 'complete') {
            resolve(iframe);
            return;
        }
        const observer = new MutationObserver(() => {
            const iframe = document.querySelector('iframe.viewer, iframe[title*="Средство просмотра отчетов"]');
            if (iframe?.contentDocument?.readyState === 'complete') {
                observer.disconnect();
                resolve(iframe);
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    });
}

function getCurrentMonthFirstDay() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}-01`;
}

function setDateAndEnter(field, dateValue) {
    if (!field) return;
    const parts = dateValue.split('-');
    if (parts.length === 3) {
        const formatted = `${parts[2]}.${parts[1]}.${parts[0]}`;
        field.value = formatted;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        field.dispatchEvent(new KeyboardEvent('keypress', {
            key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
            bubbles: true, cancelable: true
        }));
        console.log(`A.MOTIVAC: дата установлена ${formatted}`);
    }
}

function normalizeText(text) {
    if (!text) return '';
    return text.replace(/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g, ' ')
               .replace(/\s+/g, ' ')
               .trim();
}

async function retry(operation, name, maxAttempts = 3, delay = 1500) {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        console.log(`[${name}] Попытка ${attempt} из ${maxAttempts}`);
        try {
            const result = await operation();
            console.log(`[${name}] Успешно на попытке ${attempt}`);
            return result;
        } catch (error) {
            console.warn(`[${name}] Ошибка на попытке ${attempt}:`, error.message);
            if (attempt === maxAttempts) {
                console.error(`[${name}] Не удалось после ${maxAttempts} попыток`);
                throw error;
            }
            await new Promise(r => setTimeout(r, delay));
        }
    }
}

async function waitForVisibleElement(doc, selector, timeout = 5000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
        const el = doc.querySelector(selector);
        if (el && el.offsetParent !== null && !el.disabled) {
            return el;
        }
        await new Promise(r => setTimeout(r, 200));
    }
    return null;
}

async function closeMenu(doc, wait, cfg) {
    const yesNoSelect = doc.querySelector(cfg.selectors.closeMenuSelect);
    if (yesNoSelect) {
        yesNoSelect.click();
        console.log('   Кликнули по селекту "Да/Нет"');
        await wait(cfg.delays.closeMenuClick);
    }
    doc.body.click();
    await wait(cfg.delays.closeMenuClick);
}

async function selectManager(doc, wait, cfg) {
    await retry(async () => {
        const managerField = await waitForVisibleElement(doc, cfg.selectors.managerField, 5000);
        if (!managerField) throw new Error('Поле руководителя не найдено');
        
        console.log('1. Выбор руководителя...');
        managerField.click();
        await wait(cfg.delays.afterManagerFieldClick);
        
        await waitForVisibleElement(doc, 'label', 3000);
        
        const labels = doc.querySelectorAll('label');
        let found = false;
        const targetName = cfg.defaultManagers[0]; // берём первого из конфига
        for (const label of labels) {
            if (normalizeText(label.innerText) === targetName) {
                label.click();
                console.log(`   ✓ Руководитель "${targetName}" выбран`);
                found = true;
                break;
            }
        }
        if (!found) throw new Error('Не найден лейбл с руководителем');
        
        await wait(cfg.delays.clickManagerLabel);
        await closeMenu(doc, wait, cfg);
        console.log('   ✓ Меню руководителей закрыто');
    }, 'SelectManager', 3, 1000);
}

async function selectSubdivisions(doc, wait, cfg, finalPairs) {
    await retry(async () => {
        let subdivField = doc.querySelector(cfg.selectors.subdivisionField);
        if (!subdivField) {
            subdivField = doc.querySelector('[id*="ctl05_txtValue"]');
        }
        if (!subdivField) throw new Error('Поле подразделений не найдено');
        
        console.log('2. Выбор подразделений...');
        
        let attempts = 0;
        while (subdivField.disabled && attempts < 20) {
            await wait(500);
            subdivField = doc.querySelector(`#${subdivField.id}`);
            attempts++;
        }
        
        if (subdivField.disabled) throw new Error('Поле подразделений остаётся disabled');
        
        subdivField.click();
        await wait(cfg.delays.afterSubdivOpen);
        
        await waitForVisibleElement(doc, 'span', 5000);
        
        const allSpans = doc.querySelectorAll('span');
        let selectedCount = 0;
        for (const pairName of finalPairs) {
            let found = false;
            for (const span of allSpans) {
                if (span.innerText?.trim() === pairName) {
                    const td = span.closest('td');
                    const checkbox = td?.querySelector('input[type="checkbox"]');
                    if (checkbox && !checkbox.checked) {
                        checkbox.click();
                        console.log(`   ✓ ${pairName}`);
                        selectedCount++;
                        found = true;
                        break;
                    }
                }
            }
            if (!found) console.warn(`   ! Не найден элемент: ${pairName}`);
            await wait(cfg.delays.betweenSubdivClicks);
        }
        
        if (selectedCount === 0) throw new Error('Не удалось выбрать ни одного подразделения');
        
        await closeMenu(doc, wait, cfg);
        console.log('   ✓ Меню подразделений закрыто');
    }, 'SelectSubdivisions', 3, 1500);
}

async function runActions(startDate, managers, pairs) {
    const finalManagers = managers || window.AppConfig.defaultManagers;
    const finalPairs = pairs || window.AppConfig.defaultPairs;
    
    console.log('=== runActions START ===');
    
    const mainIframe = await waitForIframe();
    if (!mainIframe) {
        console.error('❌ Не удалось найти iframe отчёта');
        return;
    }
    const doc = mainIframe.contentDocument;
    if (!doc) {
        console.error('❌ Нет доступа к документу iframe');
        return;
    }
    
    const wait = ms => new Promise(r => setTimeout(r, ms));
    const cfg = window.AppConfig;
    
    // 1. Дата
    const effectiveStartDate = startDate || getCurrentMonthFirstDay();
    const dateField = await waitForVisibleElement(doc, cfg.selectors.dateField, 5000) || doc.querySelector(cfg.selectors.dateField);
    if (dateField) {
        setDateAndEnter(dateField, effectiveStartDate);
    } else {
        console.warn('⚠ Поле даты не найдено');
    }
    await wait(cfg.delays.afterDateEnter);
    
    // 2. Руководитель
    try {
        await selectManager(doc, wait, cfg);
    } catch (err) {
        console.error('❌ Не удалось выбрать руководителя после всех попыток:', err);
    }
    
    // 3. Подразделения
    if (finalPairs.length > 0) {
        try {
            await selectSubdivisions(doc, wait, cfg, finalPairs);
        } catch (err) {
            console.error('❌ Не удалось выбрать подразделения после всех попыток:', err);
        }
    }
    
    // 4. Кнопка "Просмотр"
    const submitBtn = await waitForVisibleElement(doc, cfg.selectors.submitButton, 5000);
    if (submitBtn && !submitBtn.disabled) {
        await wait(cfg.delays.beforeSubmit);
        submitBtn.click();
        console.log('3. ✓ Отчёт сформирован (кнопка нажата)');
    } else {
        // Попробуем другие возможные селекторы
        const altBtn = doc.querySelector('input[value="Просмотр"], button:contains("Просмотр")');
        if (altBtn && !altBtn.disabled) {
            await wait(cfg.delays.beforeSubmit);
            altBtn.click();
            console.log('3. ✓ Отчёт сформирован (альтернативная кнопка)');
        } else {
            console.error('❌ Кнопка отправки не найдена или недоступна');
        }
    }
    
    console.log('✅ ГОТОВО!');
}