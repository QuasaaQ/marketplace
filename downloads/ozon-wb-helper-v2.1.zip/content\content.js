// ===== BEST PRICE + SORT REVIEWS: CONTENT ENTRY POINT =====
// Объединённый скрипт для Ozon и Wildberries

// ===== ГЛОБАЛЬНЫЙ CONFIG =====
var config = {
    SettingsOnOff: true,
    isRunningAsExtension: true,
    bestPriceEnabled: true,
    sortReviewsEnabled: true,
    scrollDurationSec: 3,
    debugEnabled: false,
    ozonHideRecommended: true,
    ozonHideTogether: true,
    ozonHideCollections: true,
    ozonHideFintech: true,
    ozonHideMessageCounter: true,
    ozonHideAdChats: true,
    ozonAdChatNames: 'Ozon Банк, Захар из Морковска, Travel Лента',
    ozonMoveStoreAboveDelivery: true,
    ozonRedirectToReviews: false,
    ozonCatalogSortByRating: false
};

// ===== ОСТАЛЬНОЙ КОД =====
(function() {
    'use strict';

    // ===== НЕМЕДЛЕННАЯ УСТАНОВКА ПЕРЕХВАТЧИКОВ =====
    var currentURL = window.location.href;
    var host = window.location.host;
    
    if (host.indexOf('ozon.ru') !== -1 || host.indexOf('ozon.com') !== -1 || host.indexOf('ozon.by') !== -1) {
        // Метка Ozon на <html> для CSS: стили Ozon-специфичных правил
        // (например html.gm-ozon .GM-bp-row - строка цены на поиске и
        // каталоге). На Wildberries класс не ставится, WB не затрагивается.
        try {
            document.documentElement.classList.add('gm-ozon');
        } catch (e) {}
        interceptWindowOpen(ozonUrlModifier);
        setupLinkInterception({
            linkSelectors: 'a[href^="/product/"]',
            urlModifier: ozonUrlModifier,
            dataAttr: 'ozonIntercepted'
        });
        // Перемещение блока «Магазин» над «Доставкой и возвратом» запускаем
        // максимально рано (document_start): observer ловит добавление блоков
        // в момент появления в DOM - до первого paint, без видимого «прыжка».
        if (config.ozonMoveStoreAboveDelivery) {
            ozonStartMoveStoreObserver();
        }
    }
    
    if (host.indexOf('wildberries.ru') !== -1) {
        interceptWindowOpen(wbUrlModifier);
        setupLinkInterception({
            linkSelectors: ['a[href*="/catalog/"]', 'a[href*="/feedbacks"]'],
            urlModifier: wbUrlModifier,
            dataAttr: 'wbIntercepted'
        });
    }

    // ===== РЕДИРЕКТ ДЛЯ ДОБАВЛЕНИЯ sort-ПАРАМЕТРА =====
    if ((host.indexOf('ozon.ru') !== -1 || host.indexOf('ozon.com') !== -1 || host.indexOf('ozon.by') !== -1) &&
        currentURL.indexOf('/product/') !== -1 && currentURL.indexOf('sort=') === -1) {
        var newURL = currentURL + (currentURL.indexOf('?') !== -1 ? '&' : '?') + 'sort=score_asc';
        window.location.replace(newURL);
        return;
    }
    
    if (host.indexOf('wildberries.ru') !== -1 &&
        currentURL.indexOf('/feedbacks') !== -1 && currentURL.indexOf('sort=') === -1) {
        var newURL = currentURL + (currentURL.indexOf('?') !== -1 ? '&' : '?') + 'sort=valueup';
        window.location.replace(newURL);
        return;
    }

    // Получаем API браузера
    var api = typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.id !== 'undefined'
        ? chrome
        : typeof browser !== 'undefined' && browser.runtime && typeof browser.runtime.id !== 'undefined'
        ? browser
        : null;

    // ===== КЛАССЫ СКРЫТИЯ РЕКЛАМЫ OZON =====
    // Блоки рекламы скрываются через классы на <html> (см. content.css).
    // Классы выставляются сразу на document_start - до отрисовки блоков, поэтому мерцания нет.
    // Изменения настроек применяются после обновления страницы.
    var OZON_HIDE_CLASSES = [
        { storageKey: 'OzonHideRecommended', configKey: 'ozonHideRecommended', className: 'gm-ozon-hide-rec' },
        { storageKey: 'OzonHideTogether', configKey: 'ozonHideTogether', className: 'gm-ozon-hide-together' },
        { storageKey: 'OzonHideCollections', configKey: 'ozonHideCollections', className: 'gm-ozon-hide-collections' },
        { storageKey: 'OzonHideFintech', configKey: 'ozonHideFintech', className: 'gm-ozon-hide-fintech' },
        { storageKey: 'OzonHideMessageCounter', configKey: 'ozonHideMessageCounter', className: 'gm-ozon-hide-message-counter' }
    ];

    function applyOzonHideClasses(values) {
        try {
            var root = document.documentElement;
            if (!root) return;
            for (var i = 0; i < OZON_HIDE_CLASSES.length; i++) {
                var item = OZON_HIDE_CLASSES[i];
                var val = values ? values[item.storageKey] : config[item.configKey];
                if (val === undefined) val = true; // по умолчанию рекламу скрываем
                root.classList.toggle(item.className, !!val);
            }
        } catch (e) {}
    }

    // Применяем классы СРАЗУ синхронно (по умолчанию - всё скрыто), затем уточняем из storage.
    // Это гарантирует мгновенное скрытие рекламы ещё до отрисовки страницы.
    applyOzonHideClasses(null);

    // Применяем классы сразу при загрузке страницы (до появления рекламных блоков)
    if (api && api.storage) {
        api.storage.local.get(["OzonHideRecommended", "OzonHideTogether", "OzonHideCollections", "OzonHideFintech", "OzonHideMessageCounter"], function(res) {
            applyOzonHideClasses(res);
        });
    }

    // ===== НАСТРОЙКИ =====
    // Будет установлен в true после загрузки из storage
    var settingsLoaded = false;
    
    function initSettings() {
        if (api && api.storage) {
            api.storage.local.get(["SettingsOnOff", "BestPriceEnabled", "SortReviewsEnabled", "ScrollDurationSec", "DebugEnabled", "OzonHideRecommended", "OzonHideTogether", "OzonHideCollections", "OzonHideFintech", "OzonHideMessageCounter", "OzonHideAdChats", "OzonAdChatNames", "OzonMoveStoreAboveDelivery", "OzonRedirectToReviews", "OzonCatalogSortByRating"], function(res) {
                config.SettingsOnOff = res.SettingsOnOff !== undefined ? res.SettingsOnOff : true;
                config.bestPriceEnabled = res.BestPriceEnabled !== undefined ? res.BestPriceEnabled : true;
                config.sortReviewsEnabled = res.SortReviewsEnabled !== undefined ? res.SortReviewsEnabled : true;
                config.scrollDurationSec = res.ScrollDurationSec !== undefined ? res.ScrollDurationSec : 3;
                config.debugEnabled = res.DebugEnabled !== undefined ? res.DebugEnabled : false;
                config.ozonHideRecommended = res.OzonHideRecommended !== undefined ? res.OzonHideRecommended : true;
                config.ozonHideTogether = res.OzonHideTogether !== undefined ? res.OzonHideTogether : true;
                config.ozonHideCollections = res.OzonHideCollections !== undefined ? res.OzonHideCollections : true;
                config.ozonHideFintech = res.OzonHideFintech !== undefined ? res.OzonHideFintech : true;
                config.ozonHideMessageCounter = res.OzonHideMessageCounter !== undefined ? res.OzonHideMessageCounter : true;
                config.ozonHideAdChats = res.OzonHideAdChats !== undefined ? res.OzonHideAdChats : true;
                config.ozonAdChatNames = res.OzonAdChatNames !== undefined ? res.OzonAdChatNames : 'Ozon Банк, Захар из Морковска, Travel Лента';
                config.ozonMoveStoreAboveDelivery = res.OzonMoveStoreAboveDelivery !== undefined ? res.OzonMoveStoreAboveDelivery : true;
                config.ozonRedirectToReviews = res.OzonRedirectToReviews !== undefined ? res.OzonRedirectToReviews : false;
                config.ozonCatalogSortByRating = res.OzonCatalogSortByRating !== undefined ? res.OzonCatalogSortByRating : false;

                // РЕДИРЕКТ КАТАЛОГА OZON: если включено, открываем страницы
                // каталога/поиска сразу с сортировкой по рейтингу (?sorting=rating)
                if (config.ozonCatalogSortByRating &&
                    (host.indexOf('ozon.ru') !== -1 || host.indexOf('ozon.com') !== -1 || host.indexOf('ozon.by') !== -1)) {
                    var pathname = window.location.pathname;
                    var isCatalogPage = pathname.indexOf('/category/') === 0 ||
                        pathname.indexOf('/search/') === 0 ||
                        pathname.indexOf('/highlight/') === 0 ||
                        pathname.indexOf('/brand/') === 0 ||
                        pathname.indexOf('/seller/') === 0;
                    if (isCatalogPage && window.location.href.indexOf('sorting=') === -1) {
                        var catalogURL = window.location.href;
                        var catalogNewURL = catalogURL + (catalogURL.indexOf('?') !== -1 ? '&' : '?') + 'sorting=rating';
                        window.location.replace(catalogNewURL);
                        return;
                    }
                }
                settingsLoaded = true;
                // Флаг для модулей вне IIFE (ozon.js): настройки уже загружены,
                // можно применять изменения DOM по сохранённым значениям
                window.__gmSettingsLoaded = true;
                // Запускаем приложение только после того, как настройки загружены
                startApp();
            });
        } else {
            settingsLoaded = true;
            window.__gmSettingsLoaded = true;
            startApp();
        }
    }

    // Слушаем изменения настроек
    if (api && api.storage) {
        api.storage.onChanged.addListener(function(changes, area) {
            if (area === 'local') {
                if (changes.SettingsOnOff !== undefined) {
                    config.SettingsOnOff = changes.SettingsOnOff.newValue;
                }
                if (changes.BestPriceEnabled !== undefined) {
                    config.bestPriceEnabled = changes.BestPriceEnabled.newValue;
                }
                if (changes.SortReviewsEnabled !== undefined) {
                    config.sortReviewsEnabled = changes.SortReviewsEnabled.newValue;
                }
                if (changes.ScrollDurationSec !== undefined) {
                    config.scrollDurationSec = changes.ScrollDurationSec.newValue;
                }
                if (changes.DebugEnabled !== undefined) {
                    config.debugEnabled = changes.DebugEnabled.newValue;
                }
                if (changes.OzonHideRecommended !== undefined) {
                    config.ozonHideRecommended = changes.OzonHideRecommended.newValue;
                }
                if (changes.OzonHideTogether !== undefined) {
                    config.ozonHideTogether = changes.OzonHideTogether.newValue;
                }
                if (changes.OzonHideCollections !== undefined) {
                    config.ozonHideCollections = changes.OzonHideCollections.newValue;
                }
                if (changes.OzonHideFintech !== undefined) {
                    config.ozonHideFintech = changes.OzonHideFintech.newValue;
                }
                if (changes.OzonHideMessageCounter !== undefined) {
                    config.ozonHideMessageCounter = changes.OzonHideMessageCounter.newValue;
                }
                if (changes.OzonHideAdChats !== undefined) {
                    config.ozonHideAdChats = changes.OzonHideAdChats.newValue;
                }
                if (changes.OzonAdChatNames !== undefined) {
                    config.ozonAdChatNames = changes.OzonAdChatNames.newValue;
                }
                if (changes.OzonMoveStoreAboveDelivery !== undefined) {
                    config.ozonMoveStoreAboveDelivery = changes.OzonMoveStoreAboveDelivery.newValue;
                }
                if (changes.OzonRedirectToReviews !== undefined) {
                    config.ozonRedirectToReviews = changes.OzonRedirectToReviews.newValue;
                }
                if (changes.OzonCatalogSortByRating !== undefined) {
                    config.ozonCatalogSortByRating = changes.OzonCatalogSortByRating.newValue;
                }
                // Обновляем классы скрытия рекламы Ozon на <html> в реальном времени
                applyOzonHideClasses(null);
                runAllScripts();
            }
        });
    }

    // ===== ЗАПУСК ВСЕХ СКРИПТОВ =====
    function runAllScripts() {
        if (!config.SettingsOnOff) return;

        var host = window.location.host;
        var pathname = window.location.pathname;

        try {
            // ===== OZON =====
            if (host.indexOf('ozon.ru') !== -1 || host.indexOf('ozon.com') !== -1 || host.indexOf('ozon.by') !== -1) {
                dbg("[OZON debug] Entry point");
                
                if (pathname.indexOf('/product/') === 0) {
                    ozonInitProductPage();
                }
                
                if (pathname.indexOf('/category/') === 0 || pathname.indexOf('/highlight/') === 0 ||
                    pathname.indexOf('/search/') === 0 || pathname.indexOf('/brand/') === 0 ||
                    pathname.indexOf('/seller/') === 0 || pathname === '/') {
                    ozonInitCatalog();
                }
                
                // Страница чатов Ozon - скрываем рекламные чаты.
                // Чаты подгружаются SPA-способом - ставим observer (один раз)
                if (pathname.indexOf('/my/chat') === 0) {
                    ozonHideAdChats();
                    if (!window.__gmOzonChatObserver) {
                        var chatTimer = null;
                        window.__gmOzonChatObserver = new MutationObserver(function() {
                            if (chatTimer) return;
                            chatTimer = setTimeout(function() {
                                chatTimer = null;
                                ozonHideAdChats();
                            }, 150);
                        });
                        try {
                            window.__gmOzonChatObserver.observe(document.body, {
                                childList: true,
                                subtree: true
                            });
                        } catch (e) {}
                    }
                }
            }

            // ===== WILDBERRIES =====
            else if (host.indexOf('wildberries.ru') !== -1) {
                dbg("[WB debug] Entry point");
                
                if (pathname.indexOf('/catalog/') === 0 && pathname.indexOf('/detail.aspx') !== -1 && pathname.lastIndexOf('/detail.aspx') === pathname.length - 12) {
                    if (config.bestPriceEnabled) wbInitProductPage();
                    if (pathname.indexOf('/feedbacks') === -1 && config.sortReviewsEnabled) {
                        wbShowSpecsUnderPhoto();
                    }
                } else if (pathname.indexOf('/catalog/') === 0 && pathname.indexOf('/feedbacks') !== -1) {
                    if (config.sortReviewsEnabled) sortWildberriesReviews();
                    if (config.bestPriceEnabled) wbInitProductPage();
                } else {
                    if (config.bestPriceEnabled) {
                        wbInitCatalog();
                        wbInitPopup();
                    }
                }
            }

            // ===== WILDBERRIES GLOBAL =====
            else if (host === 'global.wildberries.ru') {
                if (pathname.indexOf('/product/') === 0 && pathname.indexOf('/feedbacks') !== -1) {
                    if (config.sortReviewsEnabled) wbGlobalSortReviews();
                }
                if (config.bestPriceEnabled) wbInitProductPage();
            }

        } catch (e) {
            dbg('[SYSTEM] runAllScripts error:', e);
        }
    }

    // ===== ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ =====
    function startApp() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                waitCompletePage(runAllScripts, { runOnce: false, delay: 300 });
            });
        } else {
            waitCompletePage(runAllScripts, { runOnce: false, delay: 300 });
        }
    }

    initSettings();

    // Перехватываем history.pushState/replaceState и popstate
    var originalPushState = history.pushState;
    history.pushState = function(state) {
        var args = Array.prototype.slice.call(arguments, 0);
        originalPushState.apply(this, args);
        setTimeout(runAllScripts, 500);
    };

    history.replaceState = new Proxy(history.replaceState, {
        apply: function(target, thisArg, argArray) {
            target.apply(thisArg, argArray);
            setTimeout(runAllScripts, 500);
        }
    });

    window.addEventListener('popstate', function() {
        setTimeout(runAllScripts, 500);
    });

})();
