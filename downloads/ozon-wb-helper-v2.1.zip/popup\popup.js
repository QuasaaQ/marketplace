// popup.js - скрипт для управления попапом

document.addEventListener('DOMContentLoaded', function() {
    // Версия берётся из manifest.json, чтобы не расходиться с реальной
    const footerVersion = document.getElementById('footerVersion');
    if (footerVersion) {
        footerVersion.textContent = 'Версия ' + chrome.runtime.getManifest().version;
    }

    const toggleMain = document.getElementById('toggleMain');
    const toggleBestPrice = document.getElementById('toggleBestPrice');
    const toggleSortReviews = document.getElementById('toggleSortReviews');
    const toggleDebug = document.getElementById('toggleDebug');
    const toggleHideRecommended = document.getElementById('toggleHideRecommended');
    const toggleHideTogether = document.getElementById('toggleHideTogether');
    const toggleHideCollections = document.getElementById('toggleHideCollections');
    const toggleHideFintech = document.getElementById('toggleHideFintech');
    const toggleHideMessageCounter = document.getElementById('toggleHideMessageCounter');
    const toggleHideAdChats = document.getElementById('toggleHideAdChats');
    const chatNamesList = document.getElementById('chatNamesList');
    const toggleMoveStore = document.getElementById('toggleMoveStore');
    const toggleRedirectToReviews = document.getElementById('toggleRedirectToReviews');
    const toggleCatalogSortByRating = document.getElementById('toggleCatalogSortByRating');
    const scrollDuration = document.getElementById('scrollDuration');
    const scrollMinus = document.getElementById('scrollMinus');
    const scrollPlus = document.getElementById('scrollPlus');
    const statusDot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');

    // Загрузка сохраненного состояния
    chrome.storage.local.get(['SettingsOnOff', 'BestPriceEnabled', 'SortReviewsEnabled', 'ScrollDurationSec', 'DebugEnabled', 'OzonHideRecommended', 'OzonHideTogether', 'OzonHideCollections', 'OzonHideFintech', 'OzonHideMessageCounter', 'OzonHideAdChats', 'OzonAdChatNames', 'OzonMoveStoreAboveDelivery', 'OzonRedirectToReviews', 'OzonCatalogSortByRating'], function(result) {
        const isEnabled = result.SettingsOnOff !== undefined ? result.SettingsOnOff : true;
        const bestPrice = result.BestPriceEnabled !== undefined ? result.BestPriceEnabled : true;
        const sortReviews = result.SortReviewsEnabled !== undefined ? result.SortReviewsEnabled : true;
        const scrollSec = result.ScrollDurationSec !== undefined ? result.ScrollDurationSec : 3;
        const debug = result.DebugEnabled !== undefined ? result.DebugEnabled : false;
        const hideRec = result.OzonHideRecommended !== undefined ? result.OzonHideRecommended : true;
        const hideTog = result.OzonHideTogether !== undefined ? result.OzonHideTogether : true;
        const hideCol = result.OzonHideCollections !== undefined ? result.OzonHideCollections : true;
        const hideFintech = result.OzonHideFintech !== undefined ? result.OzonHideFintech : true;
        const hideMessageCounter = result.OzonHideMessageCounter !== undefined ? result.OzonHideMessageCounter : true;
        const hideAdChats = result.OzonHideAdChats !== undefined ? result.OzonHideAdChats : true;
        const adChatNames = result.OzonAdChatNames !== undefined ? result.OzonAdChatNames : 'Ozon Банк, Захар из Морковска, Travel Лента';
        const moveStore = result.OzonMoveStoreAboveDelivery !== undefined ? result.OzonMoveStoreAboveDelivery : true;
        const redirectReviews = result.OzonRedirectToReviews !== undefined ? result.OzonRedirectToReviews : false;
        const catalogSortByRating = result.OzonCatalogSortByRating !== undefined ? result.OzonCatalogSortByRating : false;
        
        toggleMain.checked = isEnabled;
        toggleBestPrice.checked = bestPrice;
        toggleSortReviews.checked = sortReviews;
        toggleDebug.checked = debug;
        toggleHideRecommended.checked = hideRec;
        toggleHideTogether.checked = hideTog;
        toggleHideCollections.checked = hideCol;
        toggleHideFintech.checked = hideFintech;
        toggleHideMessageCounter.checked = hideMessageCounter;
        toggleHideAdChats.checked = hideAdChats;
        chatNamesList.value = adChatNames;
        toggleMoveStore.checked = moveStore;
        toggleRedirectToReviews.checked = redirectReviews;
        toggleCatalogSortByRating.checked = catalogSortByRating;
        scrollDuration.value = scrollSec;
        updateUI(isEnabled);
    });

    // Обработчик изменения главного переключателя
    toggleMain.addEventListener('change', function() {
        const isEnabled = toggleMain.checked;
        updateUI(isEnabled);
        saveSettings();
    });

    // Обработчики для остальных переключателей
    toggleBestPrice.addEventListener('change', saveSettings);
    toggleSortReviews.addEventListener('change', saveSettings);
    toggleDebug.addEventListener('change', saveSettings);
    toggleHideRecommended.addEventListener('change', saveSettings);
    toggleHideTogether.addEventListener('change', saveSettings);
    toggleHideCollections.addEventListener('change', saveSettings);
    toggleHideFintech.addEventListener('change', saveSettings);
    toggleHideMessageCounter.addEventListener('change', saveSettings);
    toggleHideAdChats.addEventListener('change', saveSettings);
    chatNamesList.addEventListener('change', saveSettings);
    toggleMoveStore.addEventListener('change', saveSettings);
    toggleRedirectToReviews.addEventListener('change', saveSettings);
    toggleCatalogSortByRating.addEventListener('change', saveSettings);
    scrollDuration.addEventListener('change', saveSettings);

    // Кнопки «−» и «+» для секунд скролла
    function changeScrollDuration(delta) {
        var current = parseInt(scrollDuration.value, 10);
        if (isNaN(current)) current = 3;
        current = Math.max(1, Math.min(30, current + delta));
        scrollDuration.value = current;
        saveSettings();
    }

    scrollMinus.addEventListener('click', function() {
        changeScrollDuration(-1);
    });

    scrollPlus.addEventListener('click', function() {
        changeScrollDuration(1);
    });

    // Сохранение настроек
    function saveSettings() {
        const isEnabled = toggleMain.checked;
        const sec = parseInt(scrollDuration.value, 10) || 3;
        scrollDuration.value = Math.max(1, Math.min(30, sec));
        const settings = {
            SettingsOnOff: isEnabled,
            BestPriceEnabled: toggleBestPrice.checked,
            SortReviewsEnabled: toggleSortReviews.checked,
            DebugEnabled: toggleDebug.checked,
            OzonHideRecommended: toggleHideRecommended.checked,
            OzonHideTogether: toggleHideTogether.checked,
            OzonHideCollections: toggleHideCollections.checked,
            OzonHideFintech: toggleHideFintech.checked,
            OzonHideMessageCounter: toggleHideMessageCounter.checked,
            OzonHideAdChats: toggleHideAdChats.checked,
            OzonAdChatNames: chatNamesList.value,
            OzonMoveStoreAboveDelivery: toggleMoveStore.checked,
            OzonRedirectToReviews: toggleRedirectToReviews.checked,
            OzonCatalogSortByRating: toggleCatalogSortByRating.checked,
            ScrollDurationSec: parseInt(scrollDuration.value, 10)
        };
        
        chrome.storage.local.set(settings);
        
        // Отправка сообщения всем вкладкам
        chrome.tabs.query({}, function(tabs) {
            tabs.forEach(function(tab) {
                chrome.tabs.sendMessage(tab.id, {
                    action: "settingsChanged",
                    SettingsOnOff: settings.SettingsOnOff,
                    BestPriceEnabled: settings.BestPriceEnabled,
                    SortReviewsEnabled: settings.SortReviewsEnabled,
                    DebugEnabled: settings.DebugEnabled,
                    OzonHideRecommended: settings.OzonHideRecommended,
                    OzonHideTogether: settings.OzonHideTogether,
                    OzonHideCollections: settings.OzonHideCollections,
                    OzonHideFintech: settings.OzonHideFintech,
                    OzonHideMessageCounter: settings.OzonHideMessageCounter,
                    OzonHideAdChats: settings.OzonHideAdChats,
                    OzonAdChatNames: settings.OzonAdChatNames,
                    OzonMoveStoreAboveDelivery: settings.OzonMoveStoreAboveDelivery,
                    OzonRedirectToReviews: settings.OzonRedirectToReviews,
                    OzonCatalogSortByRating: settings.OzonCatalogSortByRating,
                    ScrollDurationSec: settings.ScrollDurationSec
                }).catch(function() {
                    // Игнорируем ошибки
                });
            });
        });
    }

    // Обновление UI
    function updateUI(isEnabled) {
        if (isEnabled) {
            statusDot.className = 'status active';
            statusText.textContent = 'Включено';
            toggleBestPrice.disabled = false;
            toggleSortReviews.disabled = false;
            toggleDebug.disabled = false;
            toggleHideRecommended.disabled = false;
            toggleHideTogether.disabled = false;
            toggleHideCollections.disabled = false;
            toggleHideFintech.disabled = false;
            toggleHideMessageCounter.disabled = false;
            toggleHideAdChats.disabled = false;
            chatNamesList.disabled = false;
            toggleMoveStore.disabled = false;
            toggleRedirectToReviews.disabled = false;
            toggleCatalogSortByRating.disabled = false;
            scrollDuration.disabled = false;
            scrollMinus.disabled = false;
            scrollPlus.disabled = false;
        } else {
            statusDot.className = 'status inactive';
            statusText.textContent = 'Выключено';
            toggleBestPrice.disabled = true;
            toggleSortReviews.disabled = true;
            toggleDebug.disabled = true;
            toggleHideRecommended.disabled = true;
            toggleHideTogether.disabled = true;
            toggleHideCollections.disabled = true;
            toggleHideFintech.disabled = true;
            toggleHideMessageCounter.disabled = true;
            toggleHideAdChats.disabled = true;
            chatNamesList.disabled = true;
            toggleMoveStore.disabled = true;
            toggleRedirectToReviews.disabled = true;
            toggleCatalogSortByRating.disabled = true;
            scrollDuration.disabled = true;
            scrollMinus.disabled = true;
            scrollPlus.disabled = true;
        }
    }
});
