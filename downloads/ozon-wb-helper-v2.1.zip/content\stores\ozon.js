// ===== STORE: OZON =====
// Вся логика для Ozon: сортировка отзывов, Best Price на карточке товара и в каталоге

// OZON: Добавление параметра сортировки в URL
function ozonAddSortParam(url) {
    if (!url) return url;
    
    if (url.indexOf('sort=score_asc') !== -1 || url.indexOf('sort=score_desc') !== -1) {
        return url;
    }
    
    try {
        var fullUrl = url;
        if (url.charAt(0) === '/') {
            fullUrl = window.location.origin + url;
        }
        
        var urlObj = new URL(fullUrl);
        urlObj.searchParams.set('sort', 'score_asc');
        
        if (url.charAt(0) === '/') {
            return urlObj.pathname + urlObj.search + urlObj.hash;
        }
        return urlObj.toString();
    } catch (e) {
        if (url.indexOf('?') !== -1) {
            return url + '&sort=score_asc';
        } else {
            return url + '?sort=score_asc';
        }
    }
}

// OZON: Модификатор URL для перехвата ссылок
function ozonUrlModifier(url) {
    if (typeof url !== 'string') return url;
    
    // Если опция "Переход к отзывам" выключена - не трогаем ссылки на отзывы,
    // оставляем Ozon сам скроллить к отзывам
    if (!config.ozonRedirectToReviews && (url.indexOf('/reviews') !== -1 || url.indexOf('/feedbacks') !== -1)) {
        return url;
    }
    
    if (url.indexOf('/product/') !== -1 && url.indexOf('sort=score_asc') === -1 && url.indexOf('sort=score_desc') === -1) {
        return ozonAddSortParam(url);
    }
    return url;
}

function ozonInitProductPage() {
    // Метка страницы товара: flex-выравнивание блока цены применяется
    // только здесь (не на поиске/каталоге, где это растягивает карточку)
    try {
        document.documentElement.classList.add('gm-ozon-product');
    } catch (e) {}

    setupLinkInterception({
        linkSelectors: 'a[href^="/product/"]',
        urlModifier: ozonUrlModifier,
        dataAttr: 'ozonIntercepted'
    });

    // Скрываем fintech-рекламу в самом начале (работает и без контейнера)
    ozonApplyFintechHidden();

    // Скрываем счётчик сообщений (если включено)
    if (config.ozonHideMessageCounter) {
        ozonApplyMessageCounterHidden();
    }

    // Перемещаем блок «Магазин» над «Доставкой и возвратом» (если включено).
    // Запуск максимально ранний (document_start, observer стартует в content.js) -
    // блоки ловятся в момент добавления в DOM, до первого paint, без «прыжка»
    // на глазах у пользователя. Здесь дополнительно пробуем ещё раз на случай,
    // если ранний observer что-то пропустил.
    if (config.ozonMoveStoreAboveDelivery) {
        ozonMoveStoreAboveDelivery();
        ozonStartMoveStoreObserver();
    }

    var productRoot = document.querySelector('[data-widget="container"]');
    if (!productRoot) return;

    if (config.sortReviewsEnabled) {
        var webToAppBanner = document.querySelector('div[data-widget="webToAppBanner"]');
        if (webToAppBanner) webToAppBanner.style.display = 'none';
        
        var skuGrids = document.querySelectorAll('div[data-widget="skuGrid"]');
        for (var i = 0; i < skuGrids.length; i++) { skuGrids[i].remove(); }
        
        var banners = document.querySelectorAll('div[data-widget="bannerCarousel"]');
        for (var i = 0; i < banners.length; i++) { banners[i].remove(); }
        
        var ReviewsFoto = document.querySelector("#layoutPage > div.b2 > div:nth-child(7) > div > div.container.b6 > div:nth-child(1)");
        if (ReviewsFoto) ReviewsFoto.style.display = 'none';
    }

    // ===== СКРЫТИЕ РЕКЛАМНЫХ БЛОКОВ =====
    // Блоки скрываются CSS через классы на <html> (см. content.css, content.js).
    // Здесь дополнительно ищем блоки по заголовкам («Рекомендуем также»,
    // «Покупают вместе» и т.п.) и ставим на контейнеры атрибут-маркер,
    // который скрывается CSS - это не зависит от меняющихся data-widget.
    ozonApplySectionHidden();

    if (config.bestPriceEnabled) {
        var titleEl = document.querySelector("[data-widget='webProductHeading']");
        var title = titleEl ? titleEl.textContent : null;

        // Fallback заголовка: если webProductHeading не найден (Ozon меняет
        // data-widget), берём h1 - он есть на любой карточке товара
        if (!title) {
            var h1 = document.querySelector("h1");
            if (h1) title = h1.textContent;
        }
        if (!title) return;

        processProductCard(productRoot, {
            // Реальная цена: крупный span с актуальной ценой в контейнере цены.
            // Варианты вёрстки Ozon (классы меняются при релизах):
            //   - div.pdp_h2b > span.tsHeadline600Large (актуальная вёрстка:
            //     цена в pdp_h2b внутри pdp_hb2, рядом подпись «С банками»)
            //   - div.pdp_gb4.pdp_gb3 > span.tsHeadline600Large (прежняя вёрстка)
            //   - div.pdp_g2b > div > span.tsHeadline600Large (старая вёрстка)
            //   - div.c35_5_1-a0 / c35_5_2-a0 / c35_6_0-a0 > span.tsHeadline500Medium
            // Ищем по всей странице (price_root = document) - цена может быть
            // вне [data-widget="container"]
            price_sel: 'div.pdp_h2b > span.tsHeadline600Large, div.pdp_gb4.pdp_gb3 > span.tsHeadline600Large, div.pdp_g2b > div > span.tsHeadline600Large, div.c35_5_1-a0 > span.tsHeadline500Medium, div.c35_5_2-a0 > span.tsHeadline500Medium, div.c35_6_0-a0 > span.tsHeadline500Medium, div.c35_6_0-a0 > span.tsHeadline600Large, [data-widget="webOzonAccountPrice"], [data-widget="webPrice"]',
            title_sel: '[data-widget="webProductHeading"]',
            price_root: document,
            to_render: {
                // Вставляем блок сразу после реальной цены (первого span),
                // чтобы он был в той же строке, перед старой ценой и скидкой.
                // Родитель цены (pdp_h2b / c35_*-a0) становится flex-строкой
                // правилами в content.css (html.gm-ozon-product ...)
                sel: 'div.pdp_h2b > span.tsHeadline600Large, div.pdp_gb4.pdp_gb3 > span.tsHeadline600Large, div.pdp_g2b > div > span.tsHeadline600Large, div.c35_5_1-a0 > span.tsHeadline500Medium, div.c35_5_2-a0 > span.tsHeadline500Medium, div.c35_6_0-a0 > span.tsHeadline500Medium, div.c35_6_0-a0 > span.tsHeadline600Large, [data-widget="webOzonAccountPrice"]',
                pos: "after"
            },
            force: false
        });
    }
}

// Универсальное скрытие fintech-рекламы Ozon по текстовым маркерам.
// Селекторы Ozon меняются часто, а тексты маркеров («Оплатить позже»,
// «Без переплат», «Купить сейчас») стабильны.
function ozonApplyFintechHidden() {
    var groups = [
        ['Оплатить позже', 'Без переплат', 'частями на 6', 'частично на 6'],
        ['Покупайте за 1'],
        ['Купить сейчас']
    ];
    var shouldHide = config.ozonHideFintech !== false;

    // Блоки, которые уже обработали (чтобы не трогать повторно)
    var processed = new WeakSet();

    function isBig(el) {
        if (!el || !el.getBoundingClientRect) return false;
        try {
            var r = el.getBoundingClientRect();
            if (r.width > 700 || r.height > 500) return true;
        } catch (e) {}
        // На раннем рендере размеры 0 - считаем крупным контейнером элемент
        // с большим числом вложенных виджетов (карточка/секция)
        try {
            if (el.querySelectorAll && el.querySelectorAll('[data-widget]').length >= 5) return true;
        } catch (e) {}
        return false;
    }

    function hideBlock(el) {
        if (!el || processed.has(el)) return;
        if (el === document.documentElement || el === document.body) return;
        if (isBig(el)) return; // не скрываем крупные контейнеры
        processed.add(el);
        if (shouldHide) {
            el.style.display = 'none';
        } else {
            el.style.display = '';
        }
    }

    // Поиск самых глубоких элементов с маркером
    function findLeavesByText(marker) {
        var leaves = [];
        var xpath = "//*[text()[contains(., '" + marker + "')]]";
        try {
            var xr = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
            for (var i = 0; i < xr.snapshotLength; i++) {
                var el = xr.snapshotItem(i);
                if (!el) continue;
                if (el === document.documentElement || el === document.body) continue;
                leaves.push(el);
            }
        } catch (e) {}
        return leaves;
    }

    // Общий предок набора элементов
    function commonAncestor(nodes) {
        if (!nodes.length) return null;
        var node = nodes[0];
        while (node && node !== document.documentElement) {
            var all = true;
            for (var i = 1; i < nodes.length; i++) {
                if (!node.contains(nodes[i])) { all = false; break; }
            }
            if (all) return node;
            node = node.parentElement;
        }
        return null;
    }

    // Подъём к контейнеру виджета: стоп на крупных контейнерах и на любом
    // data-widget, который НЕ является известным финтех-виджетом
    // (это корень карточки/секции - его нельзя скрывать!)
    var FINTECH_WIDGETS = ['webPricePerStars', 'webOneClickButton'];

    function raiseToContainer(start) {
        var target = null;
        var cur = start;
        for (var i = 0; i < 5 && cur && cur.parentElement; i++) {
            var parent = cur.parentElement;
            if (parent === document.body || parent === document.documentElement) return null;
            if (isBig(parent)) return null;
            var widget = parent.getAttribute && parent.getAttribute('data-widget');
            var style = (parent.getAttribute && parent.getAttribute('style')) || '';
            if (/background(-color)?\s*:/i.test(style)) {
                return parent;
            }
            if (widget) {
                if (FINTECH_WIDGETS.indexOf(widget) !== -1) return parent;
                return null;
            }
            cur = parent;
        }
        return target;
    }

    // 1) Обрабатываем каждую группу маркеров
    for (var g = 0; g < groups.length; g++) {
        var markers = groups[g];
        var allLeaves = [];
        var found = false;
        for (var m = 0; m < markers.length; m++) {
            var leaves = findLeavesByText(markers[m]);
            if (leaves.length) {
                found = true;
                allLeaves = allLeaves.concat(leaves);
            }
        }
        if (!found) continue;

        var start = allLeaves.length > 1 ? commonAncestor(allLeaves) : allLeaves[0];
        if (!start) continue;

        if (isBig(start)) {
            for (var li = 0; li < allLeaves.length; li++) {
                hideBlock(raiseToContainer(allLeaves[li]));
            }
            continue;
        }

        var container = raiseToContainer(start);
        hideBlock(container);
    }

    // 2) Поиск по известным селекторам (если верстка не менялась)
    var known = [
        '[data-widget="webPricePerStars"]',
        '[data-widget="webOneClickButton"]',
        '[data-widget="webPdpGrid"] [data-widget="webPricePerStars"]',
        'a[href*="multipromoCreditProduct"]'
    ];
    for (var k = 0; k < known.length; k++) {
        var nodes2 = document.querySelectorAll(known[k]);
        for (var n = 0; n < nodes2.length; n++) {
            hideBlock(nodes2[n]);
        }
    }

    // 3) MutationObserver: Ozon подгружает виджеты SPA-способом,
    //    повторяем поиск при добавлении новых узлов (с debounce)
    if (!window.__gmOzonFintechObserver) {
        var obsTimer = null;
        window.__gmOzonFintechObserver = new MutationObserver(function(mutations) {
            if (obsTimer) return;
            obsTimer = setTimeout(function() {
                obsTimer = null;
                ozonApplyFintechHidden();
            }, 200);
        });
        try {
            window.__gmOzonFintechObserver.observe(document.body, {
                childList: true,
                subtree: true
            });
        } catch (e) {}
    }

    return true;
}

// ===== СКРЫТИЕ СЕКЦИЙ OZON ПО ЗАГОЛОВКАМ =====
// Скрывает «Рекомендуем также», «Покупают вместе», «Подборки товаров» и т.п.
// Селекторы data-widget на Ozon меняются при каждом релизе, поэтому блоки
// ищем по стабильным текстам заголовков. Контейнеру секции ставим
// атрибут data-gm-hidden-section="<ключ>", а CSS (html.gm-ozon-hide-* [data-gm-hidden-section="..."])
// скрывает его. Настройка применяется мгновенно (без обновления страницы).
function ozonApplySectionHidden() {
    try {
        var groups = [
            { keys: ['ozonHideRecommended'], names: ['Рекомендуем также', 'Рекомендуем для вас', 'Похожие товары'], attr: 'rec' },
            { keys: ['ozonHideTogether'], names: ['Покупают вместе', 'Часто покупают вместе', 'С этим товаром покупают'], attr: 'tog' },
            { keys: ['ozonHideCollections'], names: ['Подборки товаров', 'Подборки', 'Подборка'], attr: 'col' }
        ];

        // Все известные заголовки секций (для распознавания общего контейнера)
        var allNames = [];
        for (var gi = 0; gi < groups.length; gi++) {
            allNames = allNames.concat(groups[gi].names);
        }

        // Убираем маркеры, которые больше не актуальны (выключено) -
        // чтобы при выключении настройки блоки снова появились
        var currentAttrs = ['rec', 'tog', 'col'];
        for (var a = 0; a < currentAttrs.length; a++) {
            var old = document.querySelectorAll('[data-gm-hidden-section="' + currentAttrs[a] + '"]');
            for (var oi = 0; oi < old.length; oi++) {
                old[oi].removeAttribute('data-gm-hidden-section');
            }
        }

        for (var g = 0; g < groups.length; g++) {
            var group = groups[g];
            var shouldHide = true;
            for (var k = 0; k < group.keys.length; k++) {
                if (config[group.keys[k]] === false) { shouldHide = false; break; }
            }
            if (!shouldHide) continue;

            var headers = document.querySelectorAll('div, span, h1, h2, h3, h4, p');
            for (var h = 0; h < headers.length; h++) {
                var headerEl = headers[h];
                if (headerEl.childElementCount !== 0) continue;
                var t = (headerEl.textContent || '').replace(/\s+/g, ' ').trim();
                if (!t) continue;
                var matched = false;
                for (var n = 0; n < group.names.length; n++) {
                    if (t === group.names[n]) { matched = true; break; }
                }
                if (!matched) continue;

                // Поднимаемся до контейнера секции: ближайший предок с несколькими
                // дочерними элементами (заголовок + контент). Секцией может быть
                // и широкий блок (например data-widget="tileScrollDesktop" -
                // карусель «Рекомендуем также»/«Покупают вместе» занимает всю
                // колонку), поэтому НЕ ограничиваем по ширине. Если найденный
                // контейнер содержит ещё один заголовок наших секций - значит это
                // общий контейнер страницы, и берём последний кандидат (саму секцию).
                var section = null;
                var candidate = headerEl;
                var cur = headerEl.parentElement;
                for (var s = 0; s < 8 && cur && cur !== document.body && cur !== document.documentElement; s++) {
                    var childCount = 0;
                    for (var c = 0; c < cur.children.length; c++) {
                        if ((cur.children[c].textContent || '').trim()) childCount++;
                    }
                    if (childCount >= 2) {
                        var otherCount = ozonCountSectionHeadersIn(cur, allNames, headerEl);
                        if (otherCount > 0) {
                            section = candidate !== headerEl ? candidate : null;
                        } else {
                            section = cur;
                        }
                        break;
                    }
                    candidate = cur;
                    cur = cur.parentElement;
                }
                if (!section) continue;
                if (section === document.body || section === document.documentElement) continue;

                section.setAttribute('data-gm-hidden-section', group.attr);
            }
        }

        // Ozon подгружает секции SPA-способом - повторяем поиск при добавлении
        // новых узлов (с debounce), чтобы скрыть блоки, появившиеся позже
        if (!window.__gmOzonSectionObserver) {
            var secTimer = null;
            window.__gmOzonSectionObserver = new MutationObserver(function() {
                if (secTimer) return;
                secTimer = setTimeout(function() {
                    secTimer = null;
                    ozonApplySectionHidden();
                }, 150);
            });
            try {
                window.__gmOzonSectionObserver.observe(document.body, {
                    childList: true,
                    subtree: true
                });
            } catch (e) {}
        }
    } catch (e) {}
}

// Сколько заголовков секций (из allNames) содержится внутри root, кроме excludeEl.
// Используется, чтобы отличить контейнер самой секции от общего контейнера страницы.
function ozonCountSectionHeadersIn(root, allNames, excludeEl) {
    var count = 0;
    if (!root || !root.querySelectorAll) return 0;
    var els = root.querySelectorAll('div, span, h1, h2, h3, h4, p');
    for (var i = 0; i < els.length; i++) {
        var el = els[i];
        if (el === excludeEl) continue;
        if (el.childElementCount !== 0) continue;
        var t = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (!t) continue;
        for (var n = 0; n < allNames.length; n++) {
            if (t === allNames[n]) { count++; break; }
        }
    }
    return count;
}

// Перемещает блок «Магазин» (название магазина, рейтинг, кнопки) над
// блоком «Доставка и возврат». Поиск - по ТЕКСТОВЫМ маркерам и структуре,
// а не по обфусцированным классам Ozon (те меняются при каждом релизе).
//
// Алгоритм устойчив к изменениям вёрстки:
//   1) находим заголовок доставки и блок магазина (название продавца);
//   2) берём ближайшего общего предка - это контейнер колонки;
//   3) секции = прямые дети этого контейнера, содержащие найденные элементы;
//   4) переносим секцию магазина перед секцией доставки.
// Так переносится ровно одна секция, сколько бы обёрток ни добавил Ozon,
// а не «диапазон соседей», который при смене вёрстки не находился.
function ozonMoveStoreAboveDelivery() {
    try {
        var deliveryHeader = ozonFindSectionHeader(['Доставка и возврат', 'Доставка и оплата', 'Доставка']);
        if (!deliveryHeader) {
            dbg('[OZON debug] move store: delivery header not found');
            return false;
        }

        var storeAnchor = ozonFindStoreAnchor(deliveryHeader);
        if (!storeAnchor) {
            dbg('[OZON debug] move store: store anchor not found');
            return false;
        }

        // Ближайший общий предок - контейнер, в котором лежат оба блока
        var common = deliveryHeader;
        while (common && common !== document.body && common !== document.documentElement && !common.contains(storeAnchor)) {
            common = common.parentElement;
        }
        if (!common || common === document.body || common === document.documentElement) {
            dbg('[OZON debug] move store: common ancestor not found');
            return false;
        }

        var deliveryBlock = ozonDirectChildContaining(common, deliveryHeader);
        var storeBlock = ozonDirectChildContaining(common, storeAnchor);
        if (!deliveryBlock || !storeBlock || deliveryBlock === storeBlock) {
            dbg('[OZON debug] move store: blocks not resolved');
            return false;
        }

        // Уже стоит перед блоком доставки - считаем успехом
        if (deliveryBlock.previousElementSibling === storeBlock) return true;

        // Магазин уже выше доставки - не трогаем
        try {
            if (deliveryBlock.getBoundingClientRect && storeBlock.getBoundingClientRect) {
                var dRect = deliveryBlock.getBoundingClientRect();
                var sRect = storeBlock.getBoundingClientRect();
                if (dRect.height > 0 && sRect.height > 0) {
                    if (sRect.top < dRect.top) return true;
                    // Разные колонки (сильно разный левый край) - не трогаем,
                    // иначе переставим соседнюю колонку целиком
                    if (Math.abs(sRect.left - dRect.left) > 80) {
                        dbg('[OZON debug] move store: different columns, skip');
                        return false;
                    }
                }
            }
        } catch (e) {}

        // Убираем вертикальные отступы, чтобы между «Магазин / Подписаться»
        // и карточкой с названием/рейтингом не было разрыва
        storeBlock.style.marginTop = '0';
        storeBlock.style.marginBottom = '0';

        common.insertBefore(storeBlock, deliveryBlock);
        dbg('[OZON debug] move store above delivery: OK');
        return true;
    } catch (e) {
        dbg('[OZON debug] move store error:', e);
        return false;
    }
}

// Собирает элементы, у которых есть ПРЯМОЙ текстовый узел, точно совпадающий
// с одним из names. Обход текстовых узлов: вложенные обёртки и иконки внутри
// заголовка поиску не мешают (раньше требовался элемент без дочерних
// элементов, и заголовок с иконкой не находился).
// Возвращает объект вида { имя: [элементы в порядке DOM] }.
function ozonCollectTextElements(names) {
    var res = {};
    for (var i = 0; i < names.length; i++) {
        if (!Object.prototype.hasOwnProperty.call(res, names[i])) res[names[i]] = [];
    }
    try {
        var walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT, null);
        var node;
        while ((node = walker.nextNode())) {
            var t = (node.nodeValue || '').replace(/\s+/g, ' ').trim();
            if (!t) continue;
            if (!Object.prototype.hasOwnProperty.call(res, t)) continue;
            var el = node.parentElement;
            if (el && el !== document.body && el !== document.documentElement) {
                res[t].push(el);
            }
        }
    } catch (e) {}
    return res;
}

// Ищет заголовок секции по точному тексту. Имена перебираются по приоритету:
// сначала «Доставка и возврат», и только если такого текста нет - короче.
function ozonFindSectionHeader(names) {
    var map = ozonCollectTextElements(names);
    for (var i = 0; i < names.length; i++) {
        var list = map[names[i]];
        if (list && list.length) return list[0];
    }
    return null;
}

// Ищет «якорь» блока магазина на карточке товара:
//   1) название магазина (класс менялся: .b35_5_3-b7 -> .b35_5_4-b7);
//   2) ссылка на страницу продавца (a[href*="/seller/"]) вне шапки/футера/меню;
//   3) заголовок «Магазин» / «Продавец» (в актуальной вёрстке Ozon ссылки
//      в карточке магазина нет - вся карточка кликабельна через JS, поэтому
//      заголовок обязателен как кандидат).
// Если известен заголовок доставки, выбираем кандидата, ближайшего к нему
// по DOM (наименьшая высота подъёма до общего предка) - это карточка
// магазина в той же колонке, а не одноимённая ссылка в другом месте страницы.
function ozonFindStoreAnchor(deliveryHeader) {
    var candidates = [];

    var nameSels = ['.b35_5_3-b7', '.b35_5_4-b7'];
    for (var s = 0; s < nameSels.length; s++) {
        var byClass = document.querySelectorAll(nameSels[s]);
        for (var i = 0; i < byClass.length; i++) candidates.push(byClass[i]);
    }

    var links = document.querySelectorAll('a[href*="/seller/"]');
    for (var j = 0; j < links.length; j++) {
        var link = links[j];
        if (link.closest && link.closest('header, footer, nav')) continue;
        candidates.push(link);
    }

    var headingNames = ['Магазин', 'Продавец'];
    var headingMap = ozonCollectTextElements(headingNames);
    for (var h = 0; h < headingNames.length; h++) {
        var headList = headingMap[headingNames[h]] || [];
        for (var hi = 0; hi < headList.length; hi++) candidates.push(headList[hi]);
    }

    if (!candidates.length) return null;
    if (!deliveryHeader) return candidates[0];

    var best = null;
    var bestDepth = Infinity;
    for (var k = 0; k < candidates.length; k++) {
        var cur = candidates[k];
        var depth = 0;
        var parent = cur.parentElement;
        while (parent && parent !== document.body && parent !== document.documentElement &&
               !parent.contains(deliveryHeader) && depth < 60) {
            parent = parent.parentElement;
            depth++;
        }
        if (!parent || !parent.contains(deliveryHeader)) continue;
        if (depth < bestDepth) {
            bestDepth = depth;
            best = cur;
        }
    }
    return best || candidates[0];
}

// Прямой ребёнок контейнера root, внутри которого лежит el.
function ozonDirectChildContaining(root, el) {
    if (!root || !el) return null;
    var node = el;
    var guard = 0;
    while (node && node.parentElement && node.parentElement !== root && guard++ < 60) {
        node = node.parentElement;
    }
    return node && node.parentElement === root ? node : null;
}

// Запускает перемещение блока «Магазин» максимально рано - с document_start.
// Ozon рендерит страницу SPA-способом; ловим добавление блоков
// MutationObserver'ом. После перерисовки React блок может вернуться на
// исходное место, поэтому перемещение ПОВТОРЯЕТСЯ на каждое изменение DOM
// (с debounce), а не выполняется один раз. Если блок уже на месте, функция
// ozonMoveStoreAboveDelivery выходит сразу - лишней работы нет.
function ozonStartMoveStoreObserver() {
    if (!config.ozonMoveStoreAboveDelivery) return;
    if (window.__gmOzonMoveStoreObserverEarly) return;
    // Перемещение нужно только на странице товара
    if (window.location.pathname.indexOf('/product/') !== 0) return;

    var observer = new MutationObserver(function() {
        try {
            if (!config.ozonMoveStoreAboveDelivery) return;
            // Ждём загрузки настроек, иначе перенесём блок при выключенной опции
            if (!window.__gmSettingsLoaded) return;
            if (window.__gmOzonMoveStoreTimer) return;
            window.__gmOzonMoveStoreTimer = setTimeout(function() {
                window.__gmOzonMoveStoreTimer = null;
                try {
                    ozonMoveStoreAboveDelivery();
                } catch (e) {}
            }, 150);
        } catch (e) {}
    });
    window.__gmOzonMoveStoreObserverEarly = observer;

    function tryObserve() {
        if (!document.body || !(document.body instanceof Node)) {
            setTimeout(tryObserve, 10);
            return;
        }
        try {
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        } catch (e) {}
    }
    tryObserve();
}

// Скрывает рекламные чаты на странице /my/chat Ozon.
// Элемент чата: [data-perf="chatItem"], название - внутри span.om_7inde--eOP1V.
// Список названий для скрытия хранится в настройке OzonAdChatNames (через запятую).
function ozonHideAdChats() {
    try {
        if (!config.ozonHideAdChats) return;
        var namesRaw = config.ozonAdChatNames || '';
        var names = namesRaw.split(',').map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 0; });
        if (!names.length) return;

        var items = document.querySelectorAll('[data-perf="chatItem"]');
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var nameEl = item.querySelector('.om_7inde--eOP1V');
            if (!nameEl) continue;
            var name = (nameEl.textContent || '').trim();
            for (var n = 0; n < names.length; n++) {
                if (name.indexOf(names[n]) !== -1) {
                    item.style.display = 'none';
                    break;
                }
            }
        }
    } catch (e) {}
}

// Скрывает счётчик непрочитанных сообщений Ozon (красный бейдж с числом).
// Ищем по уникальным признакам: классу cj01_2_8-a2, фону bgAccentPrimary,
// маленькому размеру и содержимому из цифр/плюса. Скрываем и срабатываем
// на изменениях DOM (SPA).
function ozonApplyMessageCounterHidden() {
    try {
        function hide(el) {
            if (el) el.style.display = 'none';
        }

        // 1) По известному классу (если вёрстка не менялась)
        var byClass = document.querySelectorAll('.cj01_2_8-a2');
        for (var i = 0; i < byClass.length; i++) hide(byClass[i]);

        // 2) По фону bgAccentPrimary (уникальный акцентный фон счётчика)
        var all = document.querySelectorAll('div[style*="bgAccentPrimary"]');
        for (var j = 0; j < all.length; j++) hide(all[j]);

        // 3) Универсальный поиск: маленький элемент, чей текст - цифры (или "+"),
        //    и у которого рядом фон bgAccentPrimary (родитель или сам элемент)
        var candidates = document.querySelectorAll('div, span');
        for (var k = 0; k < candidates.length; k++) {
            var el = candidates[k];
            var txt = (el.textContent || '').trim();
            if (!txt || txt.length > 4) continue;
            if (!/^[0-9+\s]+$/.test(txt)) continue;
            var style = (el.getAttribute && el.getAttribute('style')) || '';
            var parentStyle = (el.parentElement && el.parentElement.getAttribute && el.parentElement.getAttribute('style')) || '';
            if (style.indexOf('bgAccentPrimary') !== -1 || parentStyle.indexOf('bgAccentPrimary') !== -1) {
                hide(el);
            }
        }
    } catch (e) {}
}

// Ищет элемент с текстом цены (лист, текст вида «1 042 ₽») внутри карточки.
// Ozon регулярно меняет обфусцированные классы (c35_5_1-a0 -> c35_6_0-a0),
// поэтому опираемся на сам текст цены, а не на класс. Возвращаем первый по
// DOM: в карточке первой идёт цена товара, затем цена без скидки и процент.
function ozonFindPriceSpan(root) {
    if (!root) return null;
    var spans = root.querySelectorAll('span');
    for (var i = 0; i < spans.length; i++) {
        var s = spans[i];
        // только листовые элементы - иначе поймаем контейнер со всеми ценами
        if (s.childElementCount !== 0) continue;
        var t = (s.textContent || '').replace(/\s+/g, ' ').trim();
        if (!t || t.length > 40) continue;
        if (t.indexOf('₽') === -1) continue;
        // текст начинается с числа, далее цифры/пробелы/разделители и «₽»
        if (!/^[\d\s.,\u00A0]+₽/.test(t)) continue;
        return s;
    }
    return null;
}

function ozonProcessProductCardOld(cardEl) {
    if (!config.bestPriceEnabled) return;
    if (!cardEl) return;
    
    var wrapEl = getElementByXpath("(a|div/a)/following-sibling::div[1]", cardEl);
    if (!wrapEl || wrapEl.querySelector(".GM-best-price")) {
        storeParsedTitleToElement(cardEl, null);
        return;
    }

    // Цена. Сначала ищем span с ценой по тексту (ozonFindPriceSpan) -
    // это работает при любом переименовании классов Ozon. Старые селекторы
    // и парсинг из wrapEl оставлены как fallback (страница /seller/ и др.).
    var price = null;
    var priceAnchorEl = ozonFindPriceSpan(cardEl);
    if (priceAnchorEl) {
        price = getPriceFromElement(priceAnchorEl);
    }
    if (!priceAnchorEl) {
        var bySel = cardEl.querySelector('div.c35_5_1-a0 > span.tsHeadline500Medium, div.c35_5_2-a0 > span.tsHeadline500Medium, div.c35_6_0-a0 > span.tsHeadline500Medium');
        if (bySel) {
            var selPrice = getPriceFromElement(bySel);
            if (selPrice !== null) {
                priceAnchorEl = bySel;
                price = selPrice;
            }
        }
    }
    if (price === null) {
        price = getPriceFromElement(wrapEl.querySelector("div"));
    }
    if (priceAnchorEl === null) {
        var priceSpans = cardEl.querySelectorAll('span');
        for (var ps = 0; ps < priceSpans.length; ps++) {
            var psText = (priceSpans[ps].textContent || '').trim();
            if (psText.indexOf('₽') !== -1 && /\d/.test(psText)) {
                var psPrice = getPriceFromElement(priceSpans[ps]);
                if (psPrice !== null) {
                    price = psPrice;
                    priceAnchorEl = priceSpans[ps];
                    break;
                }
            }
        }
    }

    var titleEl = wrapEl.querySelector("a span.tsBodyL, a span.tsBodyM:not([style]), a span.tsBodyM[style='color:;'], a span.tsBody500Medium");
    var title = titleEl ? titleEl.textContent : null;

    if (!title || !price) {
        storeParsedTitleToElement(cardEl, null);
        return;
    }

    var parsedTitle = parseTitleWithPrice(title, price);
    var bestPriceEl = renderBestPrice(parsedTitle);

    // Вставляем блок ПОСЛЕ реальной цены (в ту же строку), если нашли цену.
    // Иначе - fallback: после элемента с ценой внутри wrapEl
    var inserted = false;
    if (priceAnchorEl && priceAnchorEl.after && typeof priceAnchorEl.after === 'function') {
        try {
            priceAnchorEl.after(bestPriceEl);
            inserted = true;
        } catch (e) {}
    }
    if (!inserted) {
        var priceWrap = wrapEl.querySelector("div");
        if (priceWrap && priceWrap.after && typeof priceWrap.after === 'function') {
            try {
                priceWrap.after(bestPriceEl);
                inserted = true;
            } catch (e) {}
        }
    }
    if (!inserted && titleEl && titleEl.before && typeof titleEl.before === 'function') {
        try {
            titleEl.before(bestPriceEl);
            inserted = true;
        } catch (e) {}
    }

    // Контейнеру цены ставим класс GM-bp-row: CSS делает его flex-строкой,
    // чтобы блок «цена за кг/шт» стоял в одной строке с ценой сразу после
    // неё, а не уезжал на вторую строку. Класс ставим только когда цену
    // нашли по селектору (priceAnchorEl) - его родитель и есть контейнер
    // цены, а не общий блок карточки, который flex-строкой делать нельзя.
    if (inserted && priceAnchorEl && priceAnchorEl.parentElement) {
        priceAnchorEl.parentElement.classList.add('GM-bp-row');
    }

    storeParsedTitleToElement(cardEl, parsedTitle);
}

function ozonInitCatalog() {
    setupLinkInterception({
        linkSelectors: 'a[href^="/product/"]',
        urlModifier: ozonUrlModifier,
        dataAttr: 'ozonIntercepted'
    });

    // Скрываем fintech-рекламу и в каталоге
    ozonApplyFintechHidden();

    // Скрываем секции («Подборки» и т.п.) и в каталоге
    ozonApplySectionHidden();

    // Скрываем счётчик сообщений в шапке (если включено)
    if (config.ozonHideMessageCounter) {
        ozonApplyMessageCounterHidden();
    }

    if (!config.bestPriceEnabled) return;

    // Контейнер каталога для сортировки - пробуем несколько вариантов
    // (страница продавца /seller/ может иметь другой контейнер)
    var catalogSels = [
        "#contentScrollPaginator div[data-widget='tileGridDesktop'] > div:nth-child(1)",
        "#contentScrollPaginator div[data-widget='tileGridDesktop'] > div:first-child",
        ".widget-search-result-container > div:first-child",
        "[data-widget='searchResultsV2'] > div > div > div"
    ];
    var catalogEl = null;
    for (var cs = 0; cs < catalogSels.length; cs++) {
        catalogEl = document.querySelector(catalogSels[cs]);
        if (catalogEl) break;
    }
    if (!catalogEl) {
        dbg("[OZON debug] no catalogEl");
        return;
    }

    // Парсим все карточки - этот селектор находит сотни.
    // Дополнительно пытаемся взять прямых детей контейнера каталога
    // (покрывает страницу продавца /seller/ и другие вёрстки)
    var cardList = document.querySelectorAll(".widget-search-result-container > div > div, #contentScrollPaginator div[data-widget='tileGridDesktop'] > div > div, [data-widget='skuLine'] > div:nth-child(2) > div, [data-widget='skuGridSimple'] > div:nth-child(2) > div, [data-widget='skuGridSimple'] > div:nth-child(1) > div, [data-widget='skuLine'] > div:nth-child(1) > div, [data-widget='skuLineLR'] > div:nth-child(2) > div, [data-widget='skuGrid'][style] > div:nth-child(2) > div, [data-widget='skuGrid'] > div:nth-child(2) > div, [data-widget='skuGrid']:not([style]) > div:nth-child(1) > div, [data-widget='skuShelfGoods'] > div:nth-child(2) > div > div > div > div");
    if (cardList.length === 0 && catalogEl) {
        cardList = catalogEl.querySelectorAll(":scope > div");
    }
    dbg("[OZON debug] cardList count: " + cardList.length);

    for (var i = 0; i < cardList.length; i++) {
        try {
            ozonProcessProductCardOld(cardList[i]);
        } catch (e) {
            dbg("[OZON debug] old parse error:", e);
        }
    }

    // Контейнер для кнопок сортировки: #paginator или родитель каталога
    var paginatorEl = document.querySelector("#paginator");
    if (!paginatorEl) {
        paginatorEl = catalogEl.parentElement || catalogEl;
    }
    var buttonWrapEl = ElementGetOrCreate(paginatorEl, {
        className: "GM-button-wrap",
        pos: "before"
    });
    if (!buttonWrapEl) return;

    // Собираем все children из catalog в catalogEl (без innerHTML = "")
    // Используем все найденные контейнеры каталога (catalogSels)
    var allItems = [];
    for (var cs2 = 0; cs2 < catalogSels.length; cs2++) {
        var catalogNodes = document.querySelectorAll(catalogSels[cs2]);
        for (var cn = 0; cn < catalogNodes.length; cn++) {
            var items = catalogNodes[cn].querySelectorAll(":scope > div");
            for (var cj = 0; cj < items.length; cj++) {
                allItems.push(items[cj]);
            }
        }
    }
    
    // Перемещаем все items в catalogEl (просто append, не клонируем)
    for (var ai = 0; ai < allItems.length; ai++) {
        if (allItems[ai].parentNode !== catalogEl) {
            catalogEl.appendChild(allItems[ai]);
        }
    }

    if (buttonWrapEl) {
        initReorderCatalog(catalogEl, buttonWrapEl);
    }

    var paginator = document.querySelector('[data-widget="megaPaginator"] > div:nth-child(2)');
    var paginatorWrap = document.querySelector(".widget-search-result-container");
    if (paginator && paginator.querySelector("a") && paginatorWrap) {
        copyElementToNewRoot(paginator, paginatorWrap, { pos: "before" });
    }
}
