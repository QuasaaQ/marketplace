(() => {
  'use strict';

  const RATE_KEY = 'yenToRubRate';
  const MARKER_ATTR = 'data-yen-to-rub';
  const SCALE_ATTR = 'data-yen-to-rub-scale';
  const BLOCK_SCALE = 0.8;
  const DEFAULT_RATE = 13.7;

  let rate = DEFAULT_RATE;

  const fmtRub = (value) => {
    try {
      return new Intl.NumberFormat('ru-RU', {
        style: 'currency',
        currency: 'RUB',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(value);
    } catch {
      return '₽' + value.toFixed(2).replace('.', ',');
    }
  };

  const parseYen = (text) => {
    if (!text) return null;
    let m = text.match(/¥\s*([\d\s.,]+)/);
    if (!m) m = text.match(/([\d\s.,]+)\s*¥/);
    if (!m) return null;
    const num = parseFloat(m[1].replace(/[\s,]/g, ''));
    return Number.isFinite(num) && num > 0 ? num : null;
  };

  // Уменьшает шрифт всего блока на 20% (обе исходные строки: $0.00 USD,
  // ¥86.01 CNY и знак +), чтобы всё помещалось и не ломало вёрстку.
  // Рублёвая цена исключается: она и так меньше остальных, поэтому её
  // размер сохраняем неизменным. Исходные размеры хранятся в SCALE_ATTR,
  // чтобы reset() вернул всё как было.
  const scaleBlock = (block, priceEl) => {
    if (!block) return;

    const nodes = [block, ...block.querySelectorAll('*')];
    const items = [];
    for (const node of nodes) {
      if (node === priceEl || node.classList.contains('yen-to-rub-price')) continue;
      if (node.hasAttribute(SCALE_ATTR)) continue;
      const size = parseFloat(getComputedStyle(node).fontSize);
      if (Number.isFinite(size) && size > 0) items.push({ node, size });
    }

    // Размер рублёвой цены читаем до изменений и затем фиксируем тем же.
    let priceSize = 0;
    if (priceEl) {
      const s = parseFloat(getComputedStyle(priceEl).fontSize);
      if (Number.isFinite(s) && s > 0) priceSize = s;
    }

    for (const { node, size } of items) {
      node.setAttribute(SCALE_ATTR, String(size));
      node.style.fontSize = (size * BLOCK_SCALE).toFixed(2) + 'px';
    }

    if (priceEl && priceSize > 0) {
      priceEl.setAttribute(SCALE_ATTR, String(priceSize));
      priceEl.style.fontSize = priceSize.toFixed(2) + 'px';
    }
  };

  const restoreScale = () => {
    document.querySelectorAll(`[${SCALE_ATTR}]`).forEach((el) => {
      el.style.removeProperty('font-size');
      el.removeAttribute(SCALE_ATTR);
    });
  };

  const convert = () => {
    const nodes = document.querySelectorAll('span[data-usage-layout-font="value"]');
    for (const el of nodes) {
      if (el.hasAttribute(MARKER_ATTR)) continue;

      const yen = parseYen(el.textContent);
      if (yen === null) continue;

      // Контейнер с ценой и единицей измерения (CNY): в него вставляем цену справа
      const container = el.parentElement;
      const unit = container
        ? container.querySelector('[data-usage-layout-font="unit"]')
        : null;
      const anchor = unit || el;

      const price = document.createElement('span');
      price.className = 'yen-to-rub-price';
      price.setAttribute(MARKER_ATTR, '1');
      price.textContent = fmtRub(yen * rate);
      anchor.insertAdjacentElement('afterend', price);

      el.setAttribute(MARKER_ATTR, '1');

      // Уменьшаем шрифт блока на 20% (обе исходные строки).
      // Рублёвая цена сохраняет свой размер.
      const block = container && container.parentElement ? container.parentElement : container;
      scaleBlock(block, price);
    }
  };

  const reset = () => {
    document.querySelectorAll('.yen-to-rub-price').forEach((e) => e.remove());
    document.querySelectorAll(`[${MARKER_ATTR}]`).forEach((e) => e.removeAttribute(MARKER_ATTR));
    restoreScale();
    convert();
  };

  const style = document.createElement('style');
  style.textContent = `
    .yen-to-rub-price {
      margin-left: 6px;
      color: #9b1c1c;
      font-weight: 500;
      white-space: nowrap;
    }
  `;
  document.head.appendChild(style);

  const observer = new MutationObserver(() => convert());
  observer.observe(document.body, { childList: true, subtree: true });

  const init = async () => {
    const data = await chrome.storage.sync.get(RATE_KEY);
    const v = parseFloat(data[RATE_KEY]);
    if (Number.isFinite(v) && v > 0) rate = v;
    convert();
  };

  init();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes[RATE_KEY]) {
      const v = parseFloat(changes[RATE_KEY].newValue);
      if (Number.isFinite(v) && v > 0) rate = v;
      reset();
    }
  });
})();
