/**
 * Q.Proxy - логика страницы настроек.
 *
 * Управляет:
 *  - общими настройками;
 *  - списком своих прокси (добавление, проверка, удаление);
 *  - авто-тестированием;
 *  - списком проксируемых сайтов.
 */

// Защитный fallback, если logger.js не загрузился.
const log =
  window.QProxyLog ||
  {
    debug() {},
    info() {},
    warn() {},
    error() {},
  };

log.info('options: скрипт загружен');

if (!window.QProxyStorage) {
  log.error('options: QProxyStorage не найден - storage.js не загрузился');
}

const {
  normalizeDomain,
  parseProxyString,
  formatProxyString,
  generateProxyId,
  collectCountries,
  isArchiveWorking,
  AI_SITES,
} = window.QProxyStorage;

const els = {
  enabledCheckbox: document.getElementById('enabledCheckbox'),
  proxyAllTrafficCheckbox: document.getElementById('proxyAllTrafficCheckbox'),

  proxyProtocolSelect: document.getElementById('proxyProtocolSelect'),
  proxyNameInput: document.getElementById('proxyNameInput'),
  proxyServerInput: document.getElementById('proxyServerInput'),
  addProxyButton: document.getElementById('addProxyButton'),
  proxyFormError: document.getElementById('proxyFormError'),
  pasteProxiesButton: document.getElementById('pasteProxiesButton'),
  copyAllProxiesButton: document.getElementById('copyAllProxiesButton'),
  pasteStatus: document.getElementById('pasteStatus'),

  proxySourcesList: document.getElementById('proxySourcesList'),
  sourcesLimitInput: document.getElementById('sourcesLimitInput'),
  saveSourcesButton: document.getElementById('saveSourcesButton'),
  fetchSourcesButton: document.getElementById('fetchSourcesButton'),
  sourcesStatus: document.getElementById('sourcesStatus'),

  countryDetectStatus: document.getElementById('countryDetectStatus'),
  countryFilterMode: document.getElementById('countryFilterMode'),
  countryFilterBase: document.getElementById('countryFilterBase'),
  countryFilterList: document.getElementById('countryFilterList'),
  countryFilterUnknownCheckbox: document.getElementById('countryFilterUnknownCheckbox'),
  countryFilterAutoCheckbox: document.getElementById('countryFilterAutoCheckbox'),
  applyCountryFilterButton: document.getElementById('applyCountryFilterButton'),
  keepOnlyCountrySelect: document.getElementById('keepOnlyCountrySelect'),
  keepOnlyCountryButton: document.getElementById('keepOnlyCountryButton'),

  testTargetSelect: document.getElementById('testTargetSelect'),
  testAllProxiesButton: document.getElementById('testAllProxiesButton'),
  stopTestProxiesButton: document.getElementById('stopTestProxiesButton'),
  removeDeadProxiesButton: document.getElementById('removeDeadProxiesButton'),
  removeUntestedProxiesButton: document.getElementById('removeUntestedProxiesButton'),
  removeAllProxiesButton: document.getElementById('removeAllProxiesButton'),
  checkProgress: document.getElementById('checkProgress'),
  checkProgressFill: document.getElementById('checkProgressFill'),
  checkProgressText: document.getElementById('checkProgressText'),
  proxyImportMsg: document.getElementById('proxyImportMsg'),
  proxyCount: document.getElementById('proxyCount'),
  proxyList: document.getElementById('proxyList'),
  selectAllProxies: document.getElementById('selectAllProxies'),
  selectionInfo: document.getElementById('selectionInfo'),

  autoTestEnabledCheckbox: document.getElementById('autoTestEnabledCheckbox'),
  autoTestIntervalInput: document.getElementById('autoTestIntervalInput'),
  autoTestTimesInput: document.getElementById('autoTestTimesInput'),
  autoTestDeleteDeadCheckbox: document.getElementById('autoTestDeleteDeadCheckbox'),
  autoTestDeleteLimitedCheckbox: document.getElementById('autoTestDeleteLimitedCheckbox'),
  autoTestRefillCheckbox: document.getElementById('autoTestRefillCheckbox'),
  autoTestDeleteUntestedCheckbox: document.getElementById('autoTestDeleteUntestedCheckbox'),
  autoTestStatus: document.getElementById('autoTestStatus'),
  disableOnDeadProxyCheckbox: document.getElementById('disableOnDeadProxyCheckbox'),
  autoDeleteDeadCheckbox: document.getElementById('autoDeleteDeadCheckbox'),
  testUrlInput: document.getElementById('testUrlInput'),
  testTimeoutInput: document.getElementById('testTimeoutInput'),

  proxiedSitesTextarea: document.getElementById('proxiedSitesTextarea'),
  saveProxiedSitesButton: document.getElementById('saveProxiedSitesButton'),
  addAiSitesButton: document.getElementById('addAiSitesButton'),
  proxiedSitesStatus: document.getElementById('proxiedSitesStatus'),

  archiveCount: document.getElementById('archiveCount'),
  archiveList: document.getElementById('archiveList'),
  archiveLimitInput: document.getElementById('archiveLimitInput'),
  archiveCopyButton: document.getElementById('archiveCopyButton'),
  archiveTestButton: document.getElementById('archiveTestButton'),
  archiveFilterAllButton: document.getElementById('archiveFilterAllButton'),
  archiveFilterWorkingButton: document.getElementById('archiveFilterWorkingButton'),
  archiveFilterOtherButton: document.getElementById('archiveFilterOtherButton'),
  archiveFailLimitInput: document.getElementById('archiveFailLimitInput'),
  archivePruneButton: document.getElementById('archivePruneButton'),
  archiveClearButton: document.getElementById('archiveClearButton'),
  archiveMsg: document.getElementById('archiveMsg'),

  incognitoHint: document.getElementById('incognitoHint'),
  incognitoStatus: document.getElementById('incognitoStatus'),
  openExtensionsPageButton: document.getElementById('openExtensionsPageButton'),

  journalFilter: document.getElementById('journalFilter'),
  journalProgress: document.getElementById('journalProgress'),
  journalList: document.getElementById('journalList'),
  journalCount: document.getElementById('journalCount'),
  journalStatus: document.getElementById('journalStatus'),
  refreshJournalButton: document.getElementById('refreshJournalButton'),
  clearJournalButton: document.getElementById('clearJournalButton'),

  statProxies: document.getElementById('statProxies'),
  statSites: document.getElementById('statSites'),
  navItems: document.querySelectorAll('.nav__item'),
  sections: document.querySelectorAll('.section'),
};

// Версия из manifest.json: показывается внизу страницы настроек, править
// вручную не нужно.
const footerVersion = document.getElementById('footerVersion');
if (footerVersion) {
  footerVersion.textContent = 'Версия ' + chrome.runtime.getManifest().version;
}

let state = {
  settings: null,
  proxies: [],
  proxiedSites: [],
  activeProxy: null,
  stats: {},
  archive: {},
  sources: [],
  journal: [],
  autoTest: null,
};

// Таймер опроса прогресса проверки.
let progressTimer = null;

// Последние известные статусы строк («проверка…» / «в очереди»). Нужны, чтобы
// после перерисовки таблицы статусы не терялись.
let lastRowStatus = { checking: [], queued: [] };

// Шла ли проверка на предыдущем опросе: по переходу «идёт -> завершилась»
// подтягиваем свежую статистику.
let wasRunning = false;

// Прокси, отмеченные чекбоксами. По этому набору работают кнопки «Проверить»
// и «Удалить»: пустой набор означает «весь список».
const selectedProxies = new Set();

// Идёт ли проверка прямо сейчас: пока идёт, подпись кнопки не переписывается.
let testRunning = false;

// Идёт ли проверка по данным service worker: она могла быть запущена фоном
// (таймер авто-тестирования, автозагрузка источников), а не этой страницей.
let progressRunning = false;

// Нажата ли кнопка «Остановить»: до фактического завершения проверки кнопка
// остаётся в состоянии «Останавливаю…».
let stopRequested = false;

/**
 * Отправляет сообщение в service worker.
 * @param {object} message
 * @returns {Promise<object>}
 */
function sendMessage(message) {
  log.debug('options → background:', message.type, message);
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        log.error('options: ошибка sendMessage:', chrome.runtime.lastError.message);
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      log.debug('options ← background:', message.type, response);
      resolve(response || { ok: false });
    });
  });
}

/**
 * Загружает состояние из service worker.
 * @returns {Promise<void>}
 */
async function loadState() {
  const response = await sendMessage({ type: 'getState' });
  if (response && response.ok !== false) {
    state = {
      settings: response.settings,
      proxies: response.proxies || [],
      proxiedSites: response.proxiedSites || [],
      activeProxy: response.activeProxy || null,
      stats: response.stats || {},
      archive: response.archive || {},
      sources: state.sources,
      journal: response.journal || [],
      autoTest: response.autoTest || null,
    };
    log.info('options: состояние загружено', {
      proxies: state.proxies.length,
      sites: state.proxiedSites.length,
    });
  } else {
    log.error('options: не удалось загрузить состояние', response);
  }

  const sourcesResponse = await sendMessage({ type: 'getProxySources' });
  if (sourcesResponse && sourcesResponse.ok !== false) {
    state.sources = sourcesResponse.sources || [];
  }
}

/**
 * Отрисовывает все секции.
 */
function render() {
  renderGeneral();
  renderProxies();
  updateSortIndicator();
  // Перерисовка таблицы не должна стирать статусы идущей проверки.
  updateRowStatuses(lastRowStatus.checking, lastRowStatus.queued);
  renderAutoTest();
  renderProxiedSites();
  renderSources();
  renderCountryFilter();
  renderStats();
  renderJournal();
  renderArchive();
}

/**
 * Обновляет только «живые» части страницы: таблицу прокси, счётчики, журнал и
 * хранилище прокси.
 *
 * Отличается от render() тем, что не трогает поля формы. Во время проверки
 * статистика пишется после каждого прокси - несколько раз в секунду, - и полная
 * перерисовка затирала бы текст, который пользователь набирает прямо сейчас
 * (например, новую страну в фильтре): поле возвращалось бы к сохранённому
 * значению после каждого проверенного прокси.
 */
function renderLive() {
  renderProxies();
  updateSortIndicator();
  // Перерисовка таблицы не должна стирать статусы идущей проверки.
  updateRowStatuses(lastRowStatus.checking, lastRowStatus.queued);
  renderStats();
  renderJournal();
  renderArchive();
  // Список «Оставить одну страну» собирается из текущих прокси: во время прогона
  // страны входа и выхода дозаполняются, поэтому его тоже обновляем.
  renderFilterCountries();
}

/**
 * Обновляет счётчики в боковой панели.
 */
function renderStats() {
  els.statProxies.textContent = String(state.proxies.length);
  els.statSites.textContent = String(state.proxiedSites.length);
}

/**
 * Подписи и цвета записей журнала по типу события.
 */
const JOURNAL_KINDS = {
  switch: { label: 'замена прокси', className: 'journal__badge--switch' },
  remove: { label: 'удаление прокси', className: 'journal__badge--remove' },
  test: { label: 'прогон проверки', className: 'journal__badge--test' },
  skip: { label: 'пропуск', className: 'journal__badge--skip' },
  warn: { label: 'внимание', className: 'journal__badge--warn' },
  info: { label: 'инфо', className: 'journal__badge--info' },
};

/**
 * Время записи журнала: сегодня - только часы и минуты, иначе с датой.
 * @param {number} at
 * @returns {string}
 */
function formatJournalTime(at) {
  const date = new Date(Number(at) || Date.now());
  if (Number.isNaN(date.getTime())) return '';

  const time = date.toLocaleTimeString('ru-RU', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
  const now = new Date();
  const sameDay =
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate();
  if (sameDay) return time;

  return date.toLocaleDateString('ru-RU') + ' ' + time;
}

/**
 * Живая строка прогресса на вкладке «Журнал».
 *
 * Нужна, чтобы проверку было видно и там, когда её запустило расписание, а не
 * пользователь: в разделе «Свой прокси» прогресс виден всегда (полоса, счётчики
 * и статусы строк), но если открыта вкладка журнала, без этой строки казалось
 * бы, что ничего не происходит.
 *
 * @param {{total: number, done: number, alive: number, limited: number, dead: number}|null} info
 */
function updateJournalProgress(info) {
  const el = els.journalProgress;
  if (!el) return;

  if (!info) {
    el.hidden = true;
    el.textContent = '';
    return;
  }

  el.hidden = false;
  el.textContent =
    'Идёт проверка: ' +
    info.done +
    ' из ' +
    info.total +
    ' · работает: ' +
    info.alive +
    ', ограничено: ' +
    info.limited +
    ', недоступен: ' +
    info.dead;
}

/**
 * Отрисовывает журнал: свежие записи сверху.
 *
 * В журнал попадают только действия расширения (замена активного прокси,
 * удаление прокси после проверки, пропущенный прогон): недоступные прокси в
 * него не пишутся, иначе список событий был бы нечитаемым.
 */
function renderJournal() {
  const filter = els.journalFilter ? els.journalFilter.value : 'all';
  const all = Array.isArray(state.journal) ? state.journal : [];
  const entries = filter === 'all' ? all : all.filter((entry) => entry.kind === filter);

  els.journalCount.textContent = entries.length
    ? `Записей: ${entries.length}` + (filter === 'all' ? '' : ` из ${all.length}`)
    : '';

  els.journalList.innerHTML = '';

  if (!entries.length) {
    const empty = document.createElement('div');
    empty.className = 'empty';
    empty.textContent = all.length
      ? 'В журнале нет записей выбранного типа.'
      : 'Журнал пуст: расширение ещё не меняло прокси и ничего не удаляло.';
    els.journalList.appendChild(empty);
    return;
  }

  for (const entry of entries) {
    const kind = JOURNAL_KINDS[entry.kind] || JOURNAL_KINDS.info;

    const item = document.createElement('div');
    item.className = 'journal__item';

    const head = document.createElement('div');
    head.className = 'journal__head';

    const time = document.createElement('span');
    time.className = 'journal__time';
    time.textContent = formatJournalTime(entry.at);
    head.appendChild(time);

    const badge = document.createElement('span');
    badge.className = 'journal__badge ' + kind.className;
    badge.textContent = kind.label;
    head.appendChild(badge);

    const title = document.createElement('span');
    title.className = 'journal__title';
    title.textContent = entry.title || '';
    head.appendChild(title);

    item.appendChild(head);

    if (entry.text) {
      const text = document.createElement('div');
      text.className = 'journal__text';
      text.textContent = entry.text;
      item.appendChild(text);
    }

    if (entry.proxy) {
      const proxy = document.createElement('div');
      proxy.className = 'journal__proxy';
      proxy.textContent = entry.proxy;
      item.appendChild(proxy);
    }

    els.journalList.appendChild(item);
  }
}

/**
 * Переключает активный раздел.
 * @param {string} targetId
 */
function switchSection(targetId) {
  for (const item of els.navItems) {
    item.classList.toggle('nav__item--active', item.dataset.target === targetId);
  }
  for (const section of els.sections) {
    section.hidden = section.id !== targetId;
  }
}

/**
 * Отрисовывает общие настройки.
 */
function renderGeneral() {
  const settings = state.settings || {};
  els.enabledCheckbox.checked = settings.enabled !== false;
  els.proxyAllTrafficCheckbox.checked = !!settings.proxyAllTraffic;
  els.proxyProtocolSelect.value = settings.proxyProtocol || 'socks5';
}

/**
 * Текущая сортировка таблицы прокси. По умолчанию - по пингу: после проверки
 * самые быстрые прокси должны быть сверху. Клик по заголовку столбца меняет
 * сортировку и её направление.
 */
const sortState = { key: 'ping', dir: 'asc' };

/**
 * Текущая сортировка таблицы «Хранилище прокси». Состояние отдельное: у таблиц
 * свои столбцы, поэтому стрелка сортировки не должна переезжать между ними.
 */
const archiveSortState = { key: 'ping', dir: 'asc' };

// Сколько строк «Хранилища рабочих» рисовать в таблице. Записей там может быть
// тысячи, и полная отрисовка (тысячи строк по 9 ячеек) подвесила бы страницу
// настроек: это не «нагрузка проверки», а вес DOM. Кнопки при этом работают со
// всей выборкой - ограничение только на показ.
const ARCHIVE_ROWS_LIMIT = 300;

// Быстрый фильтр таблицы хранилища: all - все записи, working - рабочие,
// other - остальные (нерабочие).
let archiveFilter = 'all';

/**
 * Прокси помечен «ограниченным»: тестовый сайт через него не открылся.
 *
 * Состояние не зависит от того, отвечает ли прокси на пинг: при проверке по
 * событию (активный прокси не открыл страницу) пинг не проверяется, поэтому
 * живость может быть неизвестна.
 *
 * @param {object} stat
 * @returns {boolean}
 */
function isLimitedStat(stat) {
  if (!stat || !stat.checkedAt) return false;
  // Явный флаг есть в новых записях. Старые записи распознаём по прежнему
  // признаку: живой прокси без открывшегося тестового сайта.
  if (typeof stat.limited === 'boolean') return stat.limited;
  return !!(stat.alive && stat.siteLatency == null);
}

/**
 * Ранг статуса прокси для сортировки: рабочие - первыми.
 * @param {object} stat
 * @returns {number}
 */
function statusRank(stat) {
  if (!stat || !stat.checkedAt) return 4;
  // Ограниченные идут сразу после полностью рабочих.
  if (isLimitedStat(stat)) return 1;
  if (stat.alive) return 0;
  if (stat.needsAuth) return 2;
  return 3;
}

/**
 * Значение прокси по ключу столбца.
 * @param {object} proxy
 * @param {string} key
 * @returns {string|number}
 */
function sortValue(proxy, key) {
  const stat = state.stats[proxy.id] || {};
  switch (key) {
    case 'name':
      return String(proxy.name || '').toLowerCase();
    case 'address':
      return formatProxyString(proxy);
    case 'country':
      return String(proxy.country || '');
    case 'exit':
      return String(stat.exitCountry || '');
    case 'ping':
      return stat.ping != null ? stat.ping : Infinity;
    case 'site':
      return stat.siteLatency != null ? stat.siteLatency : Infinity;
    case 'status':
      return statusRank(stat);
    default:
      return '';
  }
}

/**
 * Список прокси в порядке текущей сортировки. Прокси без данных (например,
 * без пинга) всегда остаются в конце списка.
 * @returns {Array<object>}
 */
function sortedProxies() {
  const dir = sortState.dir === 'desc' ? -1 : 1;
  const key = sortState.key;
  return state.proxies.slice().sort((a, b) => {
    // Для пинга и статуса сначала группируем по состоянию: работающие сверху,
    // ниже ограниченные, затем требующие авторизации и недоступные. Группы не
    // переворачиваются сменой направления, внутри группы работает обычная
    // сортировка по столбцу.
    if (key === 'ping' || key === 'status') {
      const ra = statusRank(state.stats[a.id]);
      const rb = statusRank(state.stats[b.id]);
      if (ra !== rb) return ra - rb;
    }

    const va = sortValue(a, key);
    const vb = sortValue(b, key);
    if (va === Infinity && vb === Infinity) return 0;
    if (va === Infinity) return 1;
    if (vb === Infinity) return -1;
    if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir;
    const cmp = String(va).localeCompare(String(vb), 'ru');
    if (cmp !== 0) return cmp * dir;
    // Одинаковый статус и одинаковое значение - сравниваем по адресу.
    return formatProxyString(a).localeCompare(formatProxyString(b));
  });
}

/**
 * Таблица, в которой лежит строка или ячейка: нужна, чтобы сортировка одной
 * таблицы не трогала заголовки другой.
 * @param {HTMLElement|null} el
 * @returns {HTMLTableElement|null}
 */
function tableOf(el) {
  return el ? el.closest('table') : null;
}

/**
 * Показывает стрелку у активного столбца сортировки таблицы прокси.
 */
function updateSortIndicator() {
  const table = tableOf(els.proxyList);
  if (!table) return;
  for (const th of table.querySelectorAll('th[data-sort]')) {
    const active = th.dataset.sort === sortState.key;
    th.classList.toggle('th-sort--asc', active && sortState.dir === 'asc');
    th.classList.toggle('th-sort--desc', active && sortState.dir === 'desc');
  }
}

/**
 * Включает сортировку по клику на заголовок столбца таблицы прокси.
 */
function initSortableHeaders() {
  const table = tableOf(els.proxyList);
  if (!table) return;
  for (const th of table.querySelectorAll('th[data-sort]')) {
    th.addEventListener('click', () => {
      const key = th.dataset.sort;
      if (sortState.key === key) {
        sortState.dir = sortState.dir === 'asc' ? 'desc' : 'asc';
      } else {
        sortState.key = key;
        sortState.dir = 'asc';
      }
      renderProxies();
      updateSortIndicator();
    });
  }
}

/**
 * Значение записи хранилища по ключу столбца.
 * @param {object} entry
 * @param {string} key
 * @returns {string|number}
 */
function archiveSortValue(entry, key) {
  switch (key) {
    case 'address':
      return `${entry.host}:${entry.port}`;
    case 'country':
      return String(entry.country || '');
    case 'exit':
      return String(entry.exitCountry || '');
    case 'ping':
      return entry.ping != null ? entry.ping : Infinity;
    case 'site':
      return entry.siteLatency != null ? entry.siteLatency : Infinity;
    case 'first':
      return Number(entry.firstOkAt) || 0;
    case 'last':
      return archiveLastCheck(entry);
    case 'count':
      return Number(entry.okCount) || 0;
    case 'fail':
      return Number(entry.failCount) || 0;
    default:
      return '';
  }
}

/**
 * Когда запись хранилища проверяли в последний раз. Берётся самая поздняя из
 * проверок - удачная или нет; у записей старых версий отдельного поля нет,
 * поэтому смотрим и на прошлые даты.
 *
 * @param {object} entry
 * @returns {number} отметка времени, мс (0 - проверок ещё не было)
 */
function archiveLastCheck(entry) {
  return Math.max(
    Number(entry.lastCheckAt) || 0,
    Number(entry.lastOkAt) || 0,
    Number(entry.lastFailAt) || 0
  );
}

/**
 * Записи хранилища в порядке текущей сортировки. Записи без данных (например,
 * без пинга) остаются в конце списка, как и в таблице прокси.
 * @returns {Array<object>}
 */
function sortedArchiveEntries() {
  const dir = archiveSortState.dir === 'desc' ? -1 : 1;
  const key = archiveSortState.key;
  return archiveFilteredEntries().sort((a, b) => {
    const va = archiveSortValue(a, key);
    const vb = archiveSortValue(b, key);
    if (va === Infinity && vb === Infinity) return 0;
    if (va === Infinity) return 1;
    if (vb === Infinity) return -1;

    const cmp =
      typeof va === 'number' && typeof vb === 'number'
        ? va - vb
        : String(va).localeCompare(String(vb), 'ru');
    if (cmp !== 0) return cmp * dir;
    // Значения равны - сравниваем по адресу, чтобы порядок не «дрожал».
    return `${a.host}:${a.port}`.localeCompare(`${b.host}:${b.port}`);
  });
}

/**
 * Показывает стрелку у активного столбца сортировки хранилища.
 */
function updateArchiveSortIndicator() {
  const table = tableOf(els.archiveList);
  if (!table) return;
  for (const th of table.querySelectorAll('th[data-sort]')) {
    const active = th.dataset.sort === archiveSortState.key;
    th.classList.toggle('th-sort--asc', active && archiveSortState.dir === 'asc');
    th.classList.toggle('th-sort--desc', active && archiveSortState.dir === 'desc');
  }
}

/**
 * Включает сортировку по клику на заголовок столбца хранилища.
 */
function initArchiveSortableHeaders() {
  const table = tableOf(els.archiveList);
  if (!table) return;
  for (const th of table.querySelectorAll('th[data-sort]')) {
    th.addEventListener('click', () => {
      const key = th.dataset.sort;
      if (archiveSortState.key === key) {
        archiveSortState.dir = archiveSortState.dir === 'asc' ? 'desc' : 'asc';
      } else {
        archiveSortState.key = key;
        archiveSortState.dir = 'asc';
      }
      renderArchive();
    });
  }
}

/**
 * Возвращает эмодзи-флаг страны по двухбуквенному коду (как в оригинале).
 * @param {string} code
 * @returns {string}
 */
function countryFlag(code) {
  const letters = String(code || '').trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(letters)) return '';
  return String.fromCodePoint(
    ...[...letters].map((ch) => 0x1f1e6 + (ch.charCodeAt(0) - 65))
  );
}

/**
 * Подпись страны для таблицы: флаг плюс код, либо прочерк.
 * @param {string} code
 * @returns {string}
 */
function countryLabel(code) {
  const value = String(code || '').trim().toUpperCase();
  if (!value) return '-';
  const flag = countryFlag(value);
  return flag ? `${flag} ${value}` : value;
}

/**
 * Возвращает текст, класс и подсказку статуса прокси.
 *
 * Статусы: не проверено; ограничен - прокси не открыл тестовый сайт; недоступен;
 * требуется авторизация; работает.
 *
 * @param {object} stat статистика проверки прокси
 * @returns {{text: string, className: string, title: string}}
 */
function proxyStatusInfo(stat) {
  if (!stat || !stat.checkedAt) {
    return { text: 'не проверено', className: '', title: '' };
  }

  // «Ограничен» - прокси не открыл тестовый сайт. Проверяем это раньше живости:
  // при проверке по событию пинг не проверяется, поэтому прокси может быть
  // ограниченным и без подтверждённой живости.
  if (isLimitedStat(stat)) {
    return {
      text: 'ограничен',
      className: 'status--warn',
      title: 'Сайт через этот прокси не открылся',
    };
  }

  if (!stat.alive) {
    if (stat.needsAuth) {
      return {
        text: 'требуется авторизация',
        className: 'status--warn',
        title: stat.error ? String(stat.error) : '',
      };
    }
    return {
      text: 'недоступен',
      className: 'status--bad',
      title: stat.error ? String(stat.error) : '',
    };
  }

  return { text: 'работает', className: 'status--ok', title: '' };
}

/**
 * Отрисовывает список прокси в виде таблицы.
 */
function renderProxies() {
  els.proxyList.innerHTML = '';
  // «Работает» - только полностью рабочие прокси: живые и с открывшимся
  // тестовым сайтом. «Ограниченные» (сайт через них не открылся) в счёт рабочих
  // не идут.
  const workingCount = state.proxies.filter((proxy) => {
    const stat = state.stats[proxy.id];
    return stat && stat.alive && stat.siteLatency != null && !isLimitedStat(stat);
  }).length;
  // Лимит прокси считается по рабочим прокси, поэтому в счётчике видно и цель:
  // «работает: 14 из 40». Так понятно, сколько исправных сейчас и сколько нужно.
  const workingLimit = Math.max(0, parseInt((state.settings || {}).sourcesLimit, 10) || 0);
  els.proxyCount.textContent =
    `Всего: ${state.proxies.length} · работает: ${workingCount}` +
    (workingLimit ? ` из ${workingLimit}` : '');

  // В наборе выбора не должно оставаться id удалённых прокси.
  pruneSelection();

  if (!state.proxies.length) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 9;
    cell.className = 'empty';
    cell.textContent = 'Список прокси пуст. Добавьте свой прокси ниже.';
    row.appendChild(cell);
    els.proxyList.appendChild(row);
    updateSelectionUi();
    return;
  }

  for (const proxy of sortedProxies()) {
    const stat = state.stats[proxy.id] || {};
    const isActive = state.activeProxy && state.activeProxy.id === proxy.id;
    const isSelected = selectedProxies.has(proxy.id);

    const row = document.createElement('tr');
    row.className =
      'proxy-row' +
      (isActive ? ' proxy-row--active' : '') +
      (isSelected ? ' proxy-row--selected' : '');
    row.dataset.proxyId = proxy.id;

    // Первый столбец - чекбокс: по нему работают кнопки «Проверить» и «Удалить».
    const selectCell = document.createElement('td');
    selectCell.className = 'col-select';
    const selectBox = document.createElement('input');
    selectBox.type = 'checkbox';
    selectBox.className = 'proxy-select';
    selectBox.dataset.proxyId = proxy.id;
    selectBox.checked = isSelected;
    selectBox.title = 'Выбрать этот прокси';
    selectBox.setAttribute('aria-label', 'Выбрать прокси ' + formatProxyString(proxy));
    selectCell.appendChild(selectBox);

    // Название.
    const nameCell = document.createElement('td');
    nameCell.className = 'col-name';
    nameCell.textContent = proxy.name || '-';

    // Адрес.
    const addressCell = document.createElement('td');
    addressCell.className = 'col-address';
    addressCell.textContent = formatProxyString(proxy);

    // Страна прокси (по его IP): флаг плюс код, как в оригинале.
    const countryCell = document.createElement('td');
    countryCell.className = 'col-country';
    countryCell.textContent = countryLabel(proxy.country);

    // Страна выхода (определяется через прокси при проверке). Если вышел
    // другой IP, но страна ещё не определена, показываем «IP» - так видно,
    // что выход получен, а страна нет.
    const exitCell = document.createElement('td');
    exitCell.className = 'col-exit';
    if (stat.exitCountry) {
      exitCell.textContent = countryLabel(stat.exitCountry);
    } else if (stat.exitIp) {
      exitCell.textContent = 'IP';
      exitCell.title = stat.exitIp;
    } else {
      exitCell.textContent = '-';
    }

    // Пинг прокси (TCP-пинг хоста).
    const pingCell = document.createElement('td');
    pingCell.className = 'col-ping';
    pingCell.textContent = stat.ping != null ? `${stat.ping} мс` : '-';

    // Пинг сайта (второй).
    const siteCell = document.createElement('td');
    siteCell.className = 'col-site';
    siteCell.textContent = stat.siteLatency != null ? `${stat.siteLatency} мс` : '-';

    // Статус: текст и цвет берутся из общей функции, чтобы строка выглядела
    // одинаково и при отрисовке, и при обновлении во время проверки.
    const statusCell = document.createElement('td');
    statusCell.className = 'col-status';
    const statusInfo = proxyStatusInfo(stat);
    statusCell.textContent = statusInfo.text;
    if (statusInfo.title) statusCell.title = statusInfo.title;
    if (statusInfo.className) statusCell.classList.add(statusInfo.className);

    // Действия.
    const actionsCell = document.createElement('td');
    actionsCell.className = 'col-actions';

    const useButton = document.createElement('button');
    useButton.className = 'btn btn--sm';
    useButton.textContent = isActive ? 'Активен' : 'Использовать';
    useButton.disabled = isActive;
    useButton.addEventListener('click', () => {
      setActiveProxy(proxy).catch((error) => log.error('options: setActiveProxy', error));
    });

    const deleteButton = document.createElement('button');
    // Удаление одной строки - не акцентное действие: красный только при наведении.
    deleteButton.className = 'btn btn--sm btn--muted';
    deleteButton.textContent = 'Удалить';
    deleteButton.addEventListener('click', () => {
      deleteProxy(proxy.id).catch((error) => log.error('options: deleteProxy', error));
    });

    actionsCell.appendChild(useButton);
    actionsCell.appendChild(deleteButton);

    row.appendChild(selectCell);
    row.appendChild(nameCell);
    row.appendChild(addressCell);
    row.appendChild(countryCell);
    row.appendChild(exitCell);
    row.appendChild(pingCell);
    row.appendChild(siteCell);
    row.appendChild(statusCell);
    row.appendChild(actionsCell);
    els.proxyList.appendChild(row);
  }

  updateSelectionUi();
}

/**
 * Убирает из набора выбора id прокси, которых уже нет в списке: иначе счётчик
 * и подписи кнопок показывали бы удалённые строки.
 */
function pruneSelection() {
  if (!selectedProxies.size) return;
  const ids = new Set(state.proxies.map((proxy) => proxy.id));
  for (const id of Array.from(selectedProxies)) {
    if (!ids.has(id)) selectedProxies.delete(id);
  }
}

/**
 * Отмечает прокси выбранным или снимает отметку.
 *
 * @param {string} id
 * @param {boolean} selected
 */
function setProxySelected(id, selected) {
  if (!id) return;

  if (selected) {
    selectedProxies.add(id);
  } else {
    selectedProxies.delete(id);
  }

  // Обновляем строку без полной перерисовки: статусы проверки при этом
  // не сбрасываются.
  for (const row of els.proxyList.querySelectorAll('tr.proxy-row')) {
    if (row.dataset.proxyId !== id) continue;
    row.classList.toggle('proxy-row--selected', selected);
    const box = row.querySelector('input.proxy-select');
    if (box) box.checked = selected;
    break;
  }

  updateSelectionUi();
}

/**
 * Обновляет подписи кнопок, счётчик выбранных и состояние «выбрать все».
 *
 * Есть хотя бы один отмеченный прокси - кнопки работают по выбранным и
 * называются «Проверить» и «Удалить». Ничего не отмечено - по всему списку.
 */
function updateSelectionUi() {
  const selected = selectedProxies.size;
  const total = state.proxies.length;

  // Во время проверки подпись держит сама проверка («Проверка…») - и запущенная
  // этой страницей, и запущенная фоном.
  if (!testRunning && !progressRunning) {
    els.testAllProxiesButton.textContent = selected ? 'Проверить' : 'Проверить все';
    els.removeAllProxiesButton.textContent = selected ? 'Удалить' : 'Удалить все';
  }

  if (els.selectionInfo) {
    els.selectionInfo.textContent = selected ? `Выбрано прокси: ${selected}` : '';
    els.selectionInfo.hidden = !selected;
  }

  if (els.selectAllProxies) {
    els.selectAllProxies.disabled = total === 0;
    els.selectAllProxies.checked = total > 0 && selected === total;
    els.selectAllProxies.indeterminate = selected > 0 && selected < total;
  }
}

/**
 * Приводит настройку времён авто-теста к строке для поля ввода.
 * @param {Array<string>|string} value
 * @returns {string}
 */
function formatAutoTestTimes(value) {
  if (Array.isArray(value)) return value.join(', ');
  return String(value || '');
}

/**
 * Разбирает строку времён авто-теста в массив «HH:MM».
 *
 * Принимает значения через запятую, точку с запятой или пробел, в формате
 * «HH:MM» (допускается «H:MM» и «HH.MM»). Некорректные значения
 * отбрасываются, дубликаты убираются, результат сортируется по времени суток.
 *
 * @param {string} value
 * @returns {Array<string>}
 */
function parseAutoTestTimesInput(value) {
  const raw = String(value || '').split(/[,\s;]+/);
  const seen = new Set();
  const times = [];
  for (const item of raw) {
    const match = item.trim().match(/^([01]?\d|2[0-3])[:.]([0-5]\d)$/);
    if (!match) continue;
    const key = `${String(parseInt(match[1], 10)).padStart(2, '0')}:${match[2]}`;
    if (seen.has(key)) continue;
    seen.add(key);
    times.push(key);
  }
  times.sort();
  return times;
}

/**
 * Отрисовывает настройки авто-тестирования.
 */
function renderAutoTest() {
  const settings = state.settings || {};
  els.autoTestEnabledCheckbox.checked = settings.autoTestEnabled !== false;
  els.autoTestIntervalInput.value = settings.autoTestInterval || 15;
  els.autoTestTimesInput.value = formatAutoTestTimes(settings.autoTestTimes);
  els.autoDeleteDeadCheckbox.checked = settings.autoDeleteDead !== false;
  els.autoTestDeleteDeadCheckbox.checked = !!settings.autoTestDeleteDead;
  // «Удалять ограниченные»: включено по умолчанию.
  els.autoTestDeleteLimitedCheckbox.checked = settings.autoTestDeleteLimited !== false;
  els.autoTestRefillCheckbox.checked = !!settings.autoTestRefill;
  // «Удалять непроверенные»: включено по умолчанию.
  if (els.autoTestDeleteUntestedCheckbox) {
    els.autoTestDeleteUntestedCheckbox.checked = settings.autoTestDeleteUntested !== false;
  }
  // «Отключаться от нерабочих»: работает независимо от авто-тестирования.
  els.disableOnDeadProxyCheckbox.checked = !!settings.disableOnDeadProxy;
  els.testUrlInput.value = settings.testUrl || '';
  els.testTimeoutInput.value = settings.testTimeout || 8000;
  els.testTargetSelect.value = settings.testTarget || 'google';

  renderAutoTestStatus();
}

/**
 * Остаток времени в коротком виде: секунды, минуты, часы с минутами.
 * @param {number} ms
 * @returns {string}
 */
function formatRemaining(ms) {
  const seconds = Math.max(0, Math.round((Number(ms) || 0) / 1000));
  if (seconds < 60) return seconds + ' с';

  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return minutes + ' мин';

  return Math.floor(minutes / 60) + ' ч ' + (minutes % 60) + ' мин';
}

/**
 * Показывает состояние таймера авто-теста.
 *
 * Время берётся у самого Chrome (service worker читает chrome.alarms.get), а не
 * из настроек: по этой строке видно, стоит таймер на самом деле или нет, и когда
 * ждать следующую проверку. Строка обновляется каждую секунду, поэтому в
 * скобках идёт живой отсчёт.
 */
function renderAutoTestStatus() {
  const el = els.autoTestStatus;
  if (!el) return;

  const settings = state.settings || {};
  const info = state.autoTest || {};

  if (settings.autoTestEnabled === false) {
    el.textContent = 'авто-тест выключен';
    return;
  }

  const at = Number(info.scheduledTime || info.plannedAt || 0);
  if (!at) {
    el.textContent =
      'проверка не запланирована: не задано ни «Время проверок», ни «Интервал проверки (мин)»';
    return;
  }

  const left = at - Date.now();
  if (left <= 0) {
    el.textContent = 'проверка должна была начаться в ' + formatJournalTime(at) + ', ждём запуска';
    return;
  }

  el.textContent =
    'ближайшая проверка: ' + formatJournalTime(at) + ' (через ' + formatRemaining(left) + ')';
}

/**
 * Отрисовывает список проксируемых сайтов.
 */
function renderProxiedSites() {
  els.proxiedSitesTextarea.value = state.proxiedSites.join('\n');
}

/**
 * Отрисовывает настройки источников прокси.
 */
function renderSources() {
  const settings = state.settings || {};
  els.proxySourcesList.value = (state.sources || []).join('\n');
  els.sourcesLimitInput.value = settings.sourcesLimit || 0;
}

/**
 * Все записи «Хранилища прокси» в исходном порядке: самые быстрые сверху.
 *
 * Порядок для показа задаёт sortedArchiveEntries: он учитывает выбранный
 * столбец сортировки. Ключ записи - адрес прокси, поэтому хранилище переживает
 * удаление прокси из списка: здесь видно всё, что когда-либо подтверждало
 * работу.
 *
 * @returns {Array<object>}
 */
function archiveEntries() {
  const archive = state.archive || {};
  return Object.keys(archive)
    .map((key) => archive[key])
    .sort((a, b) => {
      const av = a.ping != null ? a.ping : Infinity;
      const bv = b.ping != null ? b.ping : Infinity;
      if (av !== bv) return av - bv;
      return (b.lastOkAt || 0) - (a.lastOkAt || 0);
    });
}

/**
 * Записи хранилища с учётом быстрого фильтра.
 *
 * «Рабочие» - те, у которых последняя проверка удалась; «Другие» - все
 * остальные. Именно нерабочие записи дозаливка не берёт из источников, поэтому
 * фильтр удобен, чтобы посмотреть, что уже отсеяно.
 *
 * @returns {Array<object>}
 */
function archiveFilteredEntries() {
  const entries = archiveEntries();
  if (archiveFilter === 'working') return entries.filter((entry) => isArchiveWorking(entry));
  if (archiveFilter === 'other') return entries.filter((entry) => !isArchiveWorking(entry));
  return entries;
}

/**
 * Отмечает активную кнопку быстрого фильтра хранилища.
 */
function renderArchiveFilter() {
  const pairs = [
    [els.archiveFilterAllButton, 'all'],
    [els.archiveFilterWorkingButton, 'working'],
    [els.archiveFilterOtherButton, 'other'],
  ];
  for (const pair of pairs) {
    const button = pair[0];
    if (!button) continue;
    button.classList.toggle('btn--primary', archiveFilter === pair[1]);
  }
}

/**
 * Сколько первых записей хранилища берут кнопки. 0 - все записи.
 * @returns {number}
 */
function archiveLimit() {
  if (!els.archiveLimitInput) return 0;
  return Math.max(0, parseInt(els.archiveLimitInput.value, 10) || 0);
}

/**
 * Адреса прокси, которых касаются кнопки хранилища.
 * @param {Array<object>} entries
 * @returns {Array<string>}
 */
function archiveAddresses(entries) {
  const limit = archiveLimit();
  const picked = limit ? entries.slice(0, limit) : entries;
  return picked.map((entry) => `${entry.host}:${entry.port}`);
}

/**
 * Отрисовывает таблицу «Хранилища рабочих».
 */
function renderArchive() {
  if (!els.archiveList) return;
  els.archiveList.innerHTML = '';

  // Порядок строк - текущая сортировка, состав - быстрый фильтр: кнопки
  // «Сколько сверху» берут верхние строки так, как они показаны на экране.
  const entries = sortedArchiveEntries();
  if (els.archiveCount) {
    const all = archiveEntries();
    const working = all.filter((entry) => isArchiveWorking(entry)).length;
    const parts = [
      `Всего: ${all.length}`,
      `рабочие: ${working}`,
      `другие: ${all.length - working}`,
    ];
    if (archiveFilter !== 'all') parts.push(`показано: ${entries.length}`);
    if (entries.length > ARCHIVE_ROWS_LIMIT) parts.push(`первые ${ARCHIVE_ROWS_LIMIT}`);
    els.archiveCount.textContent = parts.join(' · ');
  }
  updateArchiveSortIndicator();
  renderArchiveFilter();

  // Порог для кнопки «Удалить неудачные»: поле не трогаем, пока в нём набирают.
  if (els.archiveFailLimitInput && document.activeElement !== els.archiveFailLimitInput) {
    const failLimit = Math.max(0, parseInt((state.settings || {}).archiveFailLimit, 10) || 0);
    els.archiveFailLimitInput.value = String(failLimit);
  }

  if (!entries.length) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 9;
    cell.className = 'empty';
    cell.textContent = 'Хранилище пусто: рабочие прокси появятся здесь после проверки.';
    row.appendChild(cell);
    els.archiveList.appendChild(row);
    return;
  }

  for (const entry of entries.slice(0, ARCHIVE_ROWS_LIMIT)) {
    const row = document.createElement('tr');
    row.className = 'proxy-row';

    // Адрес. Именно его копирует кнопка «Скопировать адреса» и по нему прокси
    // возвращаются в список.
    const addressCell = document.createElement('td');
    addressCell.className = 'col-address';
    addressCell.textContent = `${entry.host}:${entry.port}`;

    const countryCell = document.createElement('td');
    countryCell.className = 'col-country';
    countryCell.textContent = countryLabel(entry.country);

    const exitCell = document.createElement('td');
    exitCell.className = 'col-exit';
    exitCell.textContent = countryLabel(entry.exitCountry);

    const pingCell = document.createElement('td');
    pingCell.className = 'col-ping';
    pingCell.textContent = entry.ping != null ? `${entry.ping} мс` : '-';

    const siteCell = document.createElement('td');
    siteCell.className = 'col-site';
    siteCell.textContent = entry.siteLatency != null ? `${entry.siteLatency} мс` : '-';

    // Дата первого попадания в хранилище: видно, как давно адрес в работе.
    const firstCell = document.createElement('td');
    firstCell.className = 'col-first';
    if (entry.firstOkAt) {
      const first = new Date(Number(entry.firstOkAt));
      firstCell.textContent = first.toLocaleDateString('ru-RU');
      firstCell.title = 'Первый раз попал в хранилище: ' + first.toLocaleString('ru-RU');
    } else {
      firstCell.textContent = '-';
    }

    // Последняя проверка: рядом с первой датой видно, когда адрес проверяли в
    // последний раз - неважно, удачно или нет.
    const lastCell = document.createElement('td');
    lastCell.className = 'col-last';
    const lastCheck = archiveLastCheck(entry);
    if (lastCheck) {
      const lastDate = new Date(lastCheck);
      lastCell.textContent = lastDate.toLocaleDateString('ru-RU');
      lastCell.title = 'Последняя проверка: ' + lastDate.toLocaleString('ru-RU');
    } else {
      lastCell.textContent = '-';
    }

    // «Удачных» - сколько прогонов проверки застали прокси полностью рабочим.
    const countCell = document.createElement('td');
    countCell.className = 'col-count';
    const okCount = Number(entry.okCount) || 0;
    const failCount = Number(entry.failCount) || 0;
    countCell.textContent = String(okCount);
    const okWhen = [];
    if (entry.firstOkAt) okWhen.push('первый раз ' + new Date(entry.firstOkAt).toLocaleString('ru-RU'));
    if (entry.lastOkAt) okWhen.push('последний раз ' + new Date(entry.lastOkAt).toLocaleString('ru-RU'));
    countCell.title =
      `Рабочим прокси оказывался в ${okCount} из ${okCount + failCount} прогонов` +
      (okWhen.length ? ' (' + okWhen.join(', ') + ')' : '');

    // «Неудачных» - сколько прогонов прокси не подтвердил работу.
    const failCell = document.createElement('td');
    failCell.className = 'col-fail';
    failCell.textContent = String(failCount);
    const failWhen = [];
    if (entry.lastFailAt) {
      failWhen.push('последний раз ' + new Date(entry.lastFailAt).toLocaleString('ru-RU'));
    }
    if (entry.lastFailError) failWhen.push('причина: ' + entry.lastFailError);
    failCell.title =
      `Прогонов, в которых прокси не подтвердил работу: ${failCount}` +
      (failWhen.length ? ' (' + failWhen.join(', ') + ')' : '');

    row.appendChild(addressCell);
    row.appendChild(countryCell);
    row.appendChild(exitCell);
    row.appendChild(pingCell);
    row.appendChild(siteCell);
    row.appendChild(firstCell);
    row.appendChild(lastCell);
    row.appendChild(countCell);
    row.appendChild(failCell);
    els.archiveList.appendChild(row);
  }
}

/**
 * Копирует адреса из «Хранилища рабочих» в буфер обмена.
 *
 * Копируются только адреса вида host:port, по строке на прокси: такой список
 * можно вставить в «Свой прокси» или в любой другой инструмент.
 *
 * @returns {Promise<void>}
 */
async function copyArchiveAddresses() {
  // Порядок тот же, что на экране: «Сколько сверху» отсчитывается от него.
  const addresses = archiveAddresses(sortedArchiveEntries());
  if (!addresses.length) {
    flashStatus(els.archiveMsg, 'Хранилище пусто.');
    return;
  }
  try {
    await navigator.clipboard.writeText(addresses.join('\n'));
    flashStatus(els.archiveMsg, `Скопировано адресов: ${addresses.length}`);
  } catch (error) {
    log.error('options: не удалось записать в буфер обмена', error);
    flashStatus(els.archiveMsg, 'Не удалось скопировать.');
  }
}

/**
 * Возвращает прокси из хранилища в список и запускает их проверку.
 *
 * Проверку запускает service worker сразу после ответа, поэтому здесь только
 * сообщаем, сколько прокси вернулось, и включаем опрос прогресса.
 *
 * @returns {Promise<void>}
 */
async function restoreArchiveProxies() {
  // Берём ровно те строки, которые видит пользователь: таблицу можно
  // отсортировать по любому столбцу, и «сверху» значит «сверху на экране».
  const addresses = archiveAddresses(sortedArchiveEntries());
  if (!addresses.length) {
    flashStatus(els.archiveMsg, 'Хранилище пусто.');
    return;
  }

  const response = await sendMessage({ type: 'archiveRestore', addresses });
  await loadState();
  render();

  if (!response || response.ok === false) {
    flashStatus(els.archiveMsg, 'Не удалось вернуть прокси из хранилища.');
    return;
  }
  if (!response.picked) {
    flashStatus(els.archiveMsg, 'Хранилище пусто.');
    return;
  }

  startProgressPolling();
  flashStatus(
    els.archiveMsg,
    `Взято из хранилища: ${response.picked}, новых в списке: ${response.added}. Проверка запущена.`
  );
}

/**
 * Удаляет из «Хранилища рабочих» записи с большим числом неудач.
 *
 * Порог берётся из поля «Неудачных для удаления»: записи, у которых неудачных
 * проверок не меньше порога, удаляются. Само расширение этого не делает - только
 * по нажатию кнопки.
 *
 * @returns {Promise<void>}
 */
async function pruneArchiveFails() {
  const limit = Math.max(0, parseInt(els.archiveFailLimitInput.value, 10) || 0);
  if (!limit) {
    flashStatus(els.archiveMsg, 'Укажите число неудач больше нуля.');
    return;
  }

  const response = await sendMessage({ type: 'archivePrune', limit });
  await loadState();
  render();

  if (!response || response.ok === false) {
    flashStatus(els.archiveMsg, 'Не удалось удалить неудачные записи.');
    return;
  }
  if (!response.removed) {
    flashStatus(els.archiveMsg, `Записей с ${limit} и более неудачами нет.`);
    return;
  }
  flashStatus(
    els.archiveMsg,
    `Удалено неудачных записей: ${response.removed}, осталось: ${response.left}`
  );
}

/**
 * Очищает «Хранилище прокси».
 *
 * Список прокси при этом не трогается: хранилище - отдельная таблица.
 *
 * @returns {Promise<void>}
 */
async function clearArchive() {
  if (!window.confirm('Очистить хранилище прокси? Список прокси это не затронет.')) return;
  const response = await sendMessage({ type: 'archiveClear' });
  await loadState();
  render();
  if (response && response.ok !== false) {
    flashStatus(els.archiveMsg, 'Хранилище очищено.');
  } else {
    flashStatus(els.archiveMsg, 'Не удалось очистить хранилище.');
  }
}

/**
 * Отрисовывает настройки фильтра по странам.
 */
function renderCountryFilter() {
  const settings = state.settings || {};
  els.countryFilterMode.value = settings.countryFilterMode || 'off';
  els.countryFilterBase.value = settings.countryFilterBase === 'exit' ? 'exit' : 'proxy';
  // Поле не трогаем, пока в нём набирают текст: значение вернётся само, когда
  // пользователь закончит (см. обработчик change у этого поля).
  if (document.activeElement !== els.countryFilterList) {
    els.countryFilterList.value = (settings.countryFilterList || []).join(', ');
  }
  els.countryFilterUnknownCheckbox.checked = !!settings.countryFilterUnknown;
  els.countryFilterAutoCheckbox.checked = !!settings.countryFilterAuto;

  renderFilterCountries();
}

/**
 * Заполняет список стран «Оставить одну страну» по выбранной базе: страна прокси
 * или страна выхода.
 *
 * Список пересобирается и во время прогона (renderLive): страны выхода
 * становятся известны только после проверки. Пока список открыт, его не трогаем -
 * иначе выбор сбрасывался бы прямо под пользователем.
 */
function renderFilterCountries() {
  if (!els.keepOnlyCountrySelect) return;
  if (document.activeElement === els.keepOnlyCountrySelect) return;

  const settings = state.settings || {};
  const countries = collectCountries(state.proxies, state.stats, settings.countryFilterBase);
  const current = els.keepOnlyCountrySelect.value;
  els.keepOnlyCountrySelect.innerHTML = '';
  for (const code of countries) {
    const option = document.createElement('option');
    option.value = code;
    option.textContent = code;
    els.keepOnlyCountrySelect.appendChild(option);
  }
  if (current && countries.includes(current)) {
    els.keepOnlyCountrySelect.value = current;
  }
}

/**
 * Показывает временное сообщение в статусе.
 * @param {HTMLElement} el
 * @param {string} text
 * @param {number} [timeout]
 */
function flashStatus(el, text, timeout = 4000) {
  if (!el) return;
  el.textContent = text;
  el.hidden = false;
  if (el._flashTimer) {
    clearTimeout(el._flashTimer);
    el._flashTimer = null;
  }
  if (timeout > 0) {
    el._flashTimer = setTimeout(() => {
      el.textContent = '';
      el.hidden = true;
      el._flashTimer = null;
    }, timeout);
  }
}

/**
 * Показывает постоянный статус (не скрывается сам).
 * @param {HTMLElement} el
 * @param {string} text
 */
function showStatus(el, text) {
  flashStatus(el, text, 0);
}

/**
 * Скрывает статус.
 * @param {HTMLElement} el
 */
function hideStatus(el) {
  if (!el) return;
  if (el._flashTimer) {
    clearTimeout(el._flashTimer);
    el._flashTimer = null;
  }
  el.textContent = '';
  el.hidden = true;
}

/**
 * Вставляет список прокси из буфера обмена.
 * @returns {Promise<void>}
 */
async function pasteProxies() {
  let text = '';
  try {
    text = await navigator.clipboard.readText();
  } catch (error) {
    log.error('options: не удалось прочитать буфер обмена', error);
    flashStatus(els.pasteStatus, 'Не удалось прочитать буфер обмена. Используйте Ctrl+V.');
    return;
  }

  if (!text || !text.trim()) {
    flashStatus(els.pasteStatus, 'Буфер обмена пуст.');
    return;
  }

  const response = await sendMessage({ type: 'addProxiesFromText', text });
  await loadState();
  render();

  if (response && response.ok !== false) {
    flashStatus(
      els.pasteStatus,
      `Найдено: ${response.parsed}, добавлено: ${response.added}, всего: ${response.total}`
    );
  } else {
    flashStatus(els.pasteStatus, 'Не удалось добавить прокси.');
  }
}

/**
 * Копирует все прокси в буфер обмена.
 * @returns {Promise<void>}
 */
async function copyAllProxies() {
  const lines = state.proxies.map((proxy) => formatProxyString(proxy));
  if (!lines.length) {
    flashStatus(els.pasteStatus, 'Список прокси пуст.');
    return;
  }
  try {
    await navigator.clipboard.writeText(lines.join('\n'));
    flashStatus(els.pasteStatus, `Скопировано прокси: ${lines.length}`);
  } catch (error) {
    log.error('options: не удалось записать в буфер обмена', error);
    flashStatus(els.pasteStatus, 'Не удалось скопировать.');
  }
}

/**
 * Сохраняет источники прокси.
 * @returns {Promise<void>}
 */
async function saveSources() {
  const sources = els.proxySourcesList.value
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean);

  await sendMessage({ type: 'setProxySources', sources });
  await saveSettings({
    // Лимит рабочих прокси в списке: 0 - без ограничения.
    sourcesLimit: Math.max(0, parseInt(els.sourcesLimitInput.value, 10) || 0),
  });
  await loadState();
  render();
  flashStatus(els.sourcesStatus, `Сохранено источников: ${sources.length}`);
}

/**
 * Загружает прокси из источников.
 * @returns {Promise<void>}
 */
async function fetchSources() {
  els.fetchSourcesButton.disabled = true;
  els.fetchSourcesButton.textContent = 'Загрузка…';
  showStatus(els.sourcesStatus, 'Загрузка списков…');
  try {
    const response = await sendMessage({ type: 'fetchProxySources' });
    await loadState();
    render();
    if (response && response.ok !== false) {
      const errors = (response.errors || []).length;
      flashStatus(
        els.sourcesStatus,
        `Добавлено: ${response.added} из ${response.sources} источников${errors ? `, ошибок: ${errors}` : ''}`
      );
    } else {
      flashStatus(els.sourcesStatus, 'Не удалось загрузить источники.');
    }
  } finally {
    els.fetchSourcesButton.disabled = false;
    els.fetchSourcesButton.textContent = 'Загрузить сейчас';
  }
}

/**
 * Доопределяет страны прокси, у которых они ещё неизвестны.
 *
 * Отдельной кнопки нет: страны определяются автоматически при импорте списка,
 * при загрузке источников и при открытии этой страницы. Функция запускает
 * добор остатка и показывает результат в статусе.
 *
 * @returns {Promise<void>}
 */
async function detectCountries() {
  showStatus(els.countryDetectStatus, 'Определение стран…');
  try {
    // Ограничиваем порцию: при большом списке дозаполняем страны по частям,
    // чтобы открытие настроек не запускало сразу тысячи внешних запросов.
    const response = await sendMessage({ type: 'detectCountries', limit: 300 });
    await loadState();
    render();
    if (response && response.ok !== false) {
      flashStatus(
        els.countryDetectStatus,
        `Определено: ${response.detected} из ${response.total}`
      );
    } else {
      flashStatus(els.countryDetectStatus, 'Не удалось определить страны.');
    }
  } catch (error) {
    log.error('options: detectCountries', error);
  }
}

/**
 * Разбирает строку со странами: «ru, by ir» превращается в ['RU', 'BY', 'IR'].
 *
 * @param {string} value
 * @returns {Array<string>}
 */
function parseCountryList(value) {
  return String(value || '')
    .split(/[,\s]+/)
    .map((code) => code.trim().toUpperCase())
    .filter(Boolean);
}

/**
 * Применяет фильтр по странам.
 * @returns {Promise<void>}
 */
async function applyCountryFilter() {
  const mode = els.countryFilterMode.value;
  const list = parseCountryList(els.countryFilterList.value);

  await saveSettings({
    countryFilterMode: mode,
    countryFilterBase: els.countryFilterBase.value === 'exit' ? 'exit' : 'proxy',
    countryFilterList: list,
    countryFilterUnknown: els.countryFilterUnknownCheckbox.checked,
    countryFilterAuto: els.countryFilterAutoCheckbox.checked,
  });

  if (mode === 'off') {
    flashStatus(els.countryDetectStatus, 'Фильтр выключен.');
    return;
  }

  const response = await sendMessage({ type: 'applyCountryFilter' });
  await loadState();
  render();
  if (response && response.ok !== false) {
    flashStatus(
      els.countryDetectStatus,
      `Удалено: ${response.removed}, осталось: ${response.kept}`
    );
  }
}

/**
 * Оставляет только выбранную страну.
 * @returns {Promise<void>}
 */
async function keepOnlyCountry() {
  const country = els.keepOnlyCountrySelect.value;
  if (!country) {
    flashStatus(els.countryDetectStatus, 'Сначала определите страны.');
    return;
  }
  const response = await sendMessage({ type: 'keepOnlyCountry', country });
  await loadState();
  render();
  if (response && response.ok !== false) {
    flashStatus(
      els.countryDetectStatus,
      `Оставлено: ${response.kept}, удалено: ${response.removed}`
    );
  }
}

/**
 * Запускает проверку прокси и следит за прогрессом.
 *
 * Если отмечены чекбоксы - проверяются только выбранные прокси, иначе весь
 * список.
 *
 * @returns {Promise<void>}
 */
async function testAllProxies() {
  const ids = Array.from(selectedProxies);
  const scope = ids.length ? `выбранных прокси (${ids.length})` : 'прокси';

  els.testAllProxiesButton.disabled = true;
  testRunning = true;
  els.testAllProxiesButton.textContent = 'Проверка…';
  els.stopTestProxiesButton.disabled = false;
  els.stopTestProxiesButton.textContent = 'Остановить';
  els.stopTestProxiesButton.classList.remove('hidden');
  showStatus(els.proxyImportMsg, `Идёт проверка ${scope}…`);
  startProgressPolling();
  try {
    const response = await sendMessage({ type: 'testAllProxies', ids });
    await loadState();
    // После проверки список сразу показываем отсортированным по пингу:
    // самый быстрый рабочий прокси оказывается в первой строке.
    sortState.key = 'ping';
    sortState.dir = 'asc';
    render();

    if (response && response.aborted) {
      flashStatus(els.proxyImportMsg, 'Проверка остановлена.');
    } else if (response && response.started === false && response.running) {
      flashStatus(els.proxyImportMsg, 'Проверка уже идёт - дождитесь её окончания.');
    } else {
      flashStatus(els.proxyImportMsg, 'Проверка завершена.');
    }
  } finally {
    testRunning = false;
    els.testAllProxiesButton.disabled = false;
    updateSelectionUi();
    refreshProgress().catch((error) => log.debug('options: progress', error));
  }
}

/**
 * Останавливает проверку прокси.
 *
 * Кнопка сразу переходит в состояние «Останавливаю…»: сама проверка закроется
 * после того, как service worker прервёт текущий запрос, и тогда прогресс
 * исчезнет сам.
 *
 * @returns {Promise<void>}
 */
async function stopTestProxies() {
  log.info('options: остановка проверки');
  stopRequested = true;
  els.stopTestProxiesButton.disabled = true;
  els.stopTestProxiesButton.textContent = 'Останавливаю…';
  const response = await sendMessage({ type: 'stopTestProxies' });
  log.info('options: остановка отправлена', response);
  flashStatus(els.proxyImportMsg, 'Проверка остановлена.');
}

/**
 * Запускает постоянный опрос прогресса проверки.
 *
 * Проверка запускается не только кнопкой, но и в фоне (автозагрузка списков
 * с проверкой, таймер авто-тестирования). Поэтому опрос идёт всё время, пока
 * открыта страница настроек: иначе шаги «в очереди» и «проверка» не видны,
 * а список прокси при этом ещё и перерисовывается по изменениям хранилища.
 */
function startProgressPolling() {
  if (progressTimer) return;
  refreshProgress().catch((error) => log.debug('options: progress', error));
  progressTimer = setInterval(() => {
    refreshProgress().catch((error) => log.debug('options: progress', error));
  }, 1000);
}

/**
 * Синхронизирует прогресс-бар и статусы строк с состоянием проверки.
 * @returns {Promise<void>}
 */
async function refreshProgress() {
  const response = await sendMessage({ type: 'getProgress' });

  if (!response || response.ok === false) {
    // Service worker не ответил - значит проверка не идёт (он перезапустился).
    // Снимаем «зависший» прогресс, иначе кнопки остаются заблокированными.
    progressRunning = false;
    stopRequested = false;
    updateJournalProgress(null);
    els.checkProgress.hidden = true;
    els.checkProgressFill.style.width = '0%';
    els.checkProgressText.textContent = '';
    els.stopTestProxiesButton.classList.add('hidden');
    els.stopTestProxiesButton.disabled = false;
    els.stopTestProxiesButton.textContent = 'Остановить';
    if (!testRunning) {
      els.testAllProxiesButton.disabled = false;
      updateSelectionUi();
    }
    return;
  }

  const { total, done, running, checking, queued, alive = 0, limited = 0, dead = 0 } =
    response.progress || {};

  lastRowStatus = { checking: checking || [], queued: queued || [] };
  // Строку прогресса на вкладке «Журнал» показываем только во время прогона:
  // без этой проверки она висела бы с нулями, когда проверка не идёт.
  updateJournalProgress(running ? { total, done, alive, limited, dead } : null);
  // Отсчёт до следующей проверки обновляется каждую секунду.
  renderAutoTestStatus();

  if (running) {
    const percent = total ? Math.round((done / total) * 100) : 0;
    els.checkProgress.hidden = false;
    els.checkProgressFill.style.width = percent + '%';
    // Счётчики работающих и недоступных прокси приходят из service worker.
    // «Работает» - без ограниченных: ограниченный прокси не открыл тестовый
    // сайт, поэтому рабочим он не считается.
    els.checkProgressText.textContent =
      `Проверено ${done} из ${total} · работает: ${alive}, ограничено: ${limited}, недоступен: ${dead}`;

    // Проверка может идти и без участия этой страницы (таймер авто-тестирования,
    // автозагрузка источников). Кнопку «Остановить» показываем всё время, пока
    // проверка идёт: иначе остановить её из интерфейса невозможно.
    els.stopTestProxiesButton.classList.remove('hidden');
    els.stopTestProxiesButton.disabled = stopRequested;
    els.stopTestProxiesButton.textContent = stopRequested ? 'Останавливаю…' : 'Остановить';
    els.testAllProxiesButton.disabled = true;
    els.testAllProxiesButton.textContent = 'Проверка…';
  } else {
    els.checkProgress.hidden = true;
    els.checkProgressFill.style.width = '0%';
    els.checkProgressText.textContent = '';

    stopRequested = false;
    els.stopTestProxiesButton.classList.add('hidden');
    els.stopTestProxiesButton.disabled = false;
    els.stopTestProxiesButton.textContent = 'Остановить';

    // Проверка закончилась (в том числе остановленная): возвращаем кнопкам
    // обычные подписи и состояние.
    if (!testRunning) {
      els.testAllProxiesButton.disabled = false;
      updateSelectionUi();
    }
  }

  progressRunning = !!running;

  // Обновляем статусы строк: «проверка…» и «в очереди».
  updateRowStatuses(lastRowStatus.checking, lastRowStatus.queued);

  // Проверка только что завершилась: перечитываем статистику, чтобы у
  // последнего прокси статус сменился с «проверка…» на фактический.
  if (wasRunning && !running) {
    // Обновляем «живые» части страницы, а не форму целиком: прогон мог
    // закончиться в тот момент, когда пользователь печатает в полях настроек.
    loadState()
      .then(() => renderLive())
      .catch((error) => log.debug('options: обновление после проверки', error));
  }
  wasRunning = !!running;
}

/**
 * Обновляет статусы строк таблицы во время проверки.
 *
 * @param {Array<string>} checkingIds ID прокси, которые проверяются сейчас
 * @param {Array<string>} queuedIds ID прокси, которые стоят в очереди
 */
function updateRowStatuses(checkingIds, queuedIds) {
  const checking = new Set(checkingIds);
  const queued = new Set(queuedIds);
  const rows = els.proxyList.querySelectorAll('tr.proxy-row');
  for (const row of rows) {
    const id = row.dataset.proxyId;
    const statusCell = row.querySelector('.col-status');
    if (!statusCell) continue;

    if (checking.has(id)) {
      statusCell.textContent = 'проверка…';
      statusCell.classList.remove('status--ok', 'status--bad', 'status--warn', 'status--queued');
      statusCell.classList.add('status--checking');
    } else if (queued.has(id)) {
      statusCell.textContent = 'в очереди';
      statusCell.classList.remove('status--ok', 'status--bad', 'status--warn', 'status--checking');
      statusCell.classList.add('status--queued');
    } else {
      // Возвращаем обычный статус: иначе у последнего проверенного прокси
      // остаётся текст «проверка…», хотя проверка уже завершена.
      statusCell.classList.remove('status--checking', 'status--queued', 'status--ok', 'status--bad', 'status--warn');
      const info = proxyStatusInfo(state.stats[id]);
      statusCell.textContent = info.text;
      statusCell.title = info.title;
      if (info.className) statusCell.classList.add(info.className);
    }
  }
}

/**
 * Останавливает опрос прогресса.
 */
function stopProgressPolling() {
  if (progressTimer) {
    clearInterval(progressTimer);
    progressTimer = null;
  }
}

/**
 * Выполняет действие удаления прокси и обновляет UI.
 * @param {string} type
 * @param {string} label
 * @returns {Promise<void>}
 */
async function removeProxies(type, label) {
  const response = await sendMessage({ type });
  await loadState();
  render();
  if (response && response.ok !== false) {
    flashStatus(els.proxyImportMsg, `${label}: удалено ${response.removed || 0}`);
  }
}

/**
 * Сохраняет настройки.
 * @param {object} patch
 * @returns {Promise<void>}
 */
async function saveSettings(patch) {
  const response = await sendMessage({ type: 'setSettings', settings: patch });
  if (response && response.settings) {
    state.settings = response.settings;
  }
}

/**
 * Добавляет прокси из формы.
 * @returns {Promise<void>}
 */
async function addProxy() {
  els.proxyFormError.hidden = true;
  const raw = els.proxyServerInput.value.trim();
  const parsed = parseProxyString(raw);
  if (!parsed) {
    els.proxyFormError.textContent = 'Неверный прокси. Формат: хост:порт (например 83.147.216.208:1080).';
    els.proxyFormError.hidden = false;
    return;
  }

  // Дубликаты в список не попадают: такой же host:port уже добавлен.
  const key = `${parsed.host}:${parsed.port}`.toLowerCase();
  const duplicate = state.proxies.some(
    (item) => `${item.host}:${item.port}`.toLowerCase() === key
  );
  if (duplicate) {
    els.proxyFormError.textContent = 'Такой прокси уже есть в списке.';
    els.proxyFormError.hidden = false;
    return;
  }

  const proxy = {
    id: generateProxyId(),
    name: els.proxyNameInput.value.trim(),
    ...parsed,
  };

  const proxies = [...state.proxies, proxy];
  await sendMessage({ type: 'setProxies', proxies });
  await loadState();
  render();

  els.proxyNameInput.value = '';
  els.proxyServerInput.value = '';
}

/**
 * Удаляет прокси по id.
 * @param {string} id
 * @returns {Promise<void>}
 */
async function deleteProxy(id) {
  const proxies = state.proxies.filter((proxy) => proxy.id !== id);
  await sendMessage({ type: 'setProxies', proxies });
  await loadState();
  render();
}

/**
 * Делает прокси активным.
 * @param {object} proxy
 * @returns {Promise<void>}
 */
async function setActiveProxy(proxy) {
  await sendMessage({ type: 'setActiveProxy', proxy });
  await loadState();
  render();
}

/**
 * Сохраняет список проксируемых сайтов из textarea.
 * @returns {Promise<void>}
 */
async function saveProxiedSites() {
  const lines = els.proxiedSitesTextarea.value
    .split('\n')
    .map(normalizeDomain)
    .filter(Boolean);
  const unique = Array.from(new Set(lines));

  const response = await sendMessage({ type: 'setProxiedSites', domains: unique });
  await loadState();
  render();

  els.proxiedSitesStatus.textContent = `Сохранено доменов: ${
    (response && response.count) || unique.length
  }`;
  setTimeout(() => {
    els.proxiedSitesStatus.textContent = '';
  }, 3000);
}

/**
 * Добавляет в список проксируемых сайтов готовый набор сервисов ИИ.
 *
 * Кнопка нужна, чтобы не набирать домены руками: это ровно тот сценарий, для
 * которого расширение и сделано. Какие сайты оставить в списке, пользователь
 * решает сам - набор можно править или удалить целиком.
 *
 * @returns {Promise<void>}
 */
async function addAiSites() {
  const current = els.proxiedSitesTextarea.value
    .split('\n')
    .map(normalizeDomain)
    .filter(Boolean);
  const merged = Array.from(new Set([...current, ...AI_SITES]));

  const response = await sendMessage({ type: 'setProxiedSites', domains: merged });
  await loadState();
  render();

  const added = merged.length - Array.from(new Set(current)).length;
  els.proxiedSitesStatus.textContent = added
    ? `Добавлено сервисов ИИ: ${added}, всего сайтов: ${(response && response.count) || merged.length}`
    : 'Сервисы ИИ уже есть в списке';
  setTimeout(() => {
    els.proxiedSitesStatus.textContent = '';
  }, 4000);
  log.info('options: добавлены сервисы ИИ', { added, total: merged.length });
}

/**
 * Показывает состояние приватных окон.
 *
 * В приватные окна расширение пишет настройки отдельным скоупом, и только если
 * в браузере разрешено «Разрешено в режиме инкогнито». Если разрешения нет,
 * приватные окна работают напрямую - об этом и сообщаем пользователю вместо
 * непонятных ошибок ERR_PROXY_CONNECTION_FAILED.
 *
 * @returns {Promise<void>}
 */
async function renderIncognito() {
  if (!els.incognitoStatus) return;

  const response = await sendMessage({ type: 'getIncognitoState' });
  const state = (response && response.incognito) || 'unknown';

  if (state === 'allowed') {
    els.incognitoStatus.textContent = 'Разрешено в инкогнито: сайты из списка идут через прокси';
    // Зелёный: разрешение выдано, приватные окна работают через прокси.
    els.incognitoStatus.classList.remove('status--warn', 'status--bad');
    els.incognitoStatus.classList.add('status--ok');
    els.incognitoStatus.hidden = false;
    if (els.incognitoHint) {
      els.incognitoHint.textContent =
        'Приватные окна используют тот же прокси и тот же список сайтов, что и обычные окна.';
    }
    return;
  }

  if (state === 'denied') {
    els.incognitoStatus.textContent =
      'Не разрешено в инкогнито: приватные окна открываются напрямую. Нажмите кнопку ниже, найдите Q.Proxy и включите переключатель';
    // Красный: разрешения нет, приватные окна идут напрямую.
    els.incognitoStatus.classList.remove('status--ok', 'status--warn');
    els.incognitoStatus.classList.add('status--bad');
    els.incognitoStatus.hidden = false;
    return;
  }

  els.incognitoStatus.textContent = '';
  els.incognitoStatus.classList.remove('status--ok', 'status--warn', 'status--bad');
  els.incognitoStatus.hidden = true;
}

/**
 * Открывает страницу управления расширениями: там включается режим инкогнито.
 *
 * @returns {Promise<void>}
 */
async function openExtensionsPage() {
  const url = 'chrome://extensions/?id=' + chrome.runtime.id;
  try {
    await chrome.tabs.create({ url });
  } catch (error) {
    log.warn('options: не удалось открыть страницу расширений', error);
    if (els.incognitoStatus) {
      els.incognitoStatus.textContent =
        'Откройте chrome://extensions вручную, найдите Q.Proxy и включите «Разрешено в режиме инкогнито»';
      els.incognitoStatus.classList.remove('status--ok');
      els.incognitoStatus.classList.add('status--bad');
      els.incognitoStatus.hidden = false;
    }
  }
}

// ---------------------------------------------------------------------------
// Обработчики событий
// ---------------------------------------------------------------------------

els.enabledCheckbox.addEventListener('change', () => {
  saveSettings({ enabled: els.enabledCheckbox.checked }).catch((error) =>
    log.error('options: enabled', error)
  );
});

els.proxyAllTrafficCheckbox.addEventListener('change', () => {
  saveSettings({ proxyAllTraffic: els.proxyAllTrafficCheckbox.checked }).catch((error) =>
    log.error('options: proxyAllTraffic', error)
  );
});

// «Отключаться от нерабочих»: проверка активного прокси по навигации.
// Настройка не зависит от авто-тестирования.
els.disableOnDeadProxyCheckbox.addEventListener('change', () => {
  saveSettings({ disableOnDeadProxy: els.disableOnDeadProxyCheckbox.checked }).catch((error) =>
    log.error('options: disableOnDeadProxy', error)
  );
});

els.addProxyButton.addEventListener('click', () => {
  addProxy().catch((error) => log.error('options: addProxy', error));
});

els.proxyProtocolSelect.addEventListener('change', () => {
  const protocol = els.proxyProtocolSelect.value;
  log.info('options: смена протокола списка', protocol);
  saveSettings({ proxyProtocol: protocol }).catch((error) =>
    log.error('options: proxyProtocol', error)
  );
});

// Вставка списка из буфера.
els.pasteProxiesButton.addEventListener('click', () => {
  pasteProxies().catch((error) => log.error('options: pasteProxies', error));
});

// Копирование всех прокси.
els.copyAllProxiesButton.addEventListener('click', () => {
  copyAllProxies().catch((error) => log.error('options: copyAllProxies', error));
});

// Источники.
els.saveSourcesButton.addEventListener('click', () => {
  saveSources().catch((error) => log.error('options: saveSources', error));
});

els.fetchSourcesButton.addEventListener('click', () => {
  fetchSources().catch((error) => log.error('options: fetchSources', error));
});

// Лимит прокси: сколько рабочих прокси держать в списке (0 - без ограничения).
els.sourcesLimitInput.addEventListener('change', () => {
  const value = Math.max(0, parseInt(els.sourcesLimitInput.value, 10) || 0);
  els.sourcesLimitInput.value = value;
  saveSettings({ sourcesLimit: value }).catch((error) =>
    log.error('options: sourcesLimit', error)
  );
});

// Страны.
els.applyCountryFilterButton.addEventListener('click', () => {
  applyCountryFilter().catch((error) => log.error('options: applyCountryFilter', error));
});

// Список стран сохраняется сразу после ввода (Enter или уход из поля), но без
// применения фильтра: применение - отдельное действие, потому что оно удаляет
// прокси из списка.
els.countryFilterList.addEventListener('change', () => {
  const list = parseCountryList(els.countryFilterList.value);
  els.countryFilterList.value = list.join(', ');
  saveSettings({ countryFilterList: list }).catch((error) =>
    log.error('options: countryFilterList', error)
  );
});

els.keepOnlyCountryButton.addEventListener('click', () => {
  keepOnlyCountry().catch((error) => log.error('options: keepOnlyCountry', error));
});

els.countryFilterUnknownCheckbox.addEventListener('change', () => {
  saveSettings({ countryFilterUnknown: els.countryFilterUnknownCheckbox.checked }).catch((error) =>
    log.error('options: countryFilterUnknown', error)
  );
});

els.countryFilterAutoCheckbox.addEventListener('change', () => {
  saveSettings({ countryFilterAuto: els.countryFilterAutoCheckbox.checked }).catch((error) =>
    log.error('options: countryFilterAuto', error)
  );
});

// База фильтра: страна прокси или страна выхода.
els.countryFilterBase.addEventListener('change', () => {
  const base = els.countryFilterBase.value === 'exit' ? 'exit' : 'proxy';
  saveSettings({ countryFilterBase: base })
    .then(() => loadState())
    .then(() => render())
    .catch((error) => log.error('options: countryFilterBase', error));
});

// Проверка.
els.testTargetSelect.addEventListener('change', () => {
  saveSettings({ testTarget: els.testTargetSelect.value }).catch((error) =>
    log.error('options: testTarget', error)
  );
});

els.testAllProxiesButton.addEventListener('click', () => {
  testAllProxies().catch((error) => log.error('options: testAllProxies', error));
});

els.stopTestProxiesButton.addEventListener('click', () => {
  stopTestProxies().catch((error) => log.error('options: stopTestProxies', error));
});

els.removeDeadProxiesButton.addEventListener('click', () => {
  removeProxies('removeDeadProxies', 'Нерабочие').catch((error) =>
    log.error('options: removeDeadProxies', error)
  );
});

els.removeUntestedProxiesButton.addEventListener('click', () => {
  removeProxies('removeUntestedProxies', 'Непроверенные').catch((error) =>
    log.error('options: removeUntestedProxies', error)
  );
});

// Изменение чекбокса в строке.
els.proxyList.addEventListener('change', (event) => {
  const box = event.target;
  if (!box || !box.classList || !box.classList.contains('proxy-select')) return;
  setProxySelected(box.dataset.proxyId, box.checked);
});

// Клик по строке (вне кнопок и полей ввода) тоже переключает выбор.
els.proxyList.addEventListener('click', (event) => {
  const target = event.target;
  if (!target || typeof target.closest !== 'function') return;

  const row = target.closest('tr.proxy-row');
  if (!row) return;
  if (target.closest('button, input, a, select, textarea')) return;

  const box = row.querySelector('input.proxy-select');
  if (!box) return;
  setProxySelected(row.dataset.proxyId, !box.checked);
});

// «Выбрать все» в шапке таблицы.
els.selectAllProxies.addEventListener('change', () => {
  const checked = els.selectAllProxies.checked;
  selectedProxies.clear();
  if (checked) {
    for (const proxy of state.proxies) selectedProxies.add(proxy.id);
  }

  for (const row of els.proxyList.querySelectorAll('tr.proxy-row')) {
    const box = row.querySelector('input.proxy-select');
    if (box) box.checked = checked;
    row.classList.toggle('proxy-row--selected', checked);
  }

  updateSelectionUi();
});

// Удаление: есть отмеченные - удаляем только их, иначе весь список.
els.removeAllProxiesButton.addEventListener('click', async () => {
  if (!selectedProxies.size) {
    await sendMessage({ type: 'setProxies', proxies: [] });
    await loadState();
    render();
    return;
  }

  const removed = selectedProxies.size;
  const proxies = state.proxies.filter((proxy) => !selectedProxies.has(proxy.id));
  selectedProxies.clear();

  await sendMessage({ type: 'setProxies', proxies });
  await loadState();
  render();
  flashStatus(els.proxyImportMsg, `Удалено выбранных прокси: ${removed}`);
  log.info('options: удалены выбранные прокси', { removed, left: proxies.length });
});

els.autoTestEnabledCheckbox.addEventListener('change', () => {
  saveSettings({ autoTestEnabled: els.autoTestEnabledCheckbox.checked }).catch((error) =>
    log.error('options: autoTestEnabled', error)
  );
});

// Интервал авто-теста в минутах. Работает, только если не задано точное
// время проверок: расписание берёт «Время проверок», иначе - интервал.
els.autoTestIntervalInput.addEventListener('change', () => {
  const value = Math.max(1, parseInt(els.autoTestIntervalInput.value, 10) || 15);
  els.autoTestIntervalInput.value = value;
  saveSettings({ autoTestInterval: value }).catch((error) =>
    log.error('options: autoTestInterval', error)
  );
});

// Точное время авто-теста: «09:00, 15:00, 21:00». Некорректные значения
// отбрасываются, дубликаты убираются, порядок приводится к возрастанию.
els.autoTestTimesInput.addEventListener('change', () => {
  const times = parseAutoTestTimesInput(els.autoTestTimesInput.value);
  els.autoTestTimesInput.value = times.join(', ');
  saveSettings({ autoTestTimes: times }).catch((error) =>
    log.error('options: autoTestTimes', error)
  );
});

els.autoTestDeleteDeadCheckbox.addEventListener('change', () => {
  saveSettings({ autoTestDeleteDead: els.autoTestDeleteDeadCheckbox.checked }).catch((error) =>
    log.error('options: autoTestDeleteDead', error)
  );
});

els.autoTestDeleteLimitedCheckbox.addEventListener('change', () => {
  saveSettings({ autoTestDeleteLimited: els.autoTestDeleteLimitedCheckbox.checked }).catch(
    (error) => log.error('options: autoTestDeleteLimited', error)
  );
});

els.autoTestRefillCheckbox.addEventListener('change', () => {
  saveSettings({ autoTestRefill: els.autoTestRefillCheckbox.checked }).catch((error) =>
    log.error('options: autoTestRefill', error)
  );
});

if (els.autoTestDeleteUntestedCheckbox) {
  els.autoTestDeleteUntestedCheckbox.addEventListener('change', () => {
    saveSettings({ autoTestDeleteUntested: els.autoTestDeleteUntestedCheckbox.checked }).catch((error) =>
      log.error('options: autoTestDeleteUntested', error)
    );
  });
}

els.autoDeleteDeadCheckbox.addEventListener('change', () => {
  saveSettings({ autoDeleteDead: els.autoDeleteDeadCheckbox.checked }).catch((error) =>
    log.error('options: autoDeleteDead', error)
  );
});

els.testUrlInput.addEventListener('change', () => {
  saveSettings({ testUrl: els.testUrlInput.value.trim() }).catch((error) =>
    log.error('options: testUrl', error)
  );
});

els.testTimeoutInput.addEventListener('change', () => {
  const value = Math.max(1000, parseInt(els.testTimeoutInput.value, 10) || 8000);
  els.testTimeoutInput.value = value;
  saveSettings({ testTimeout: value }).catch((error) =>
    log.error('options: testTimeout', error)
  );
});

els.saveProxiedSitesButton.addEventListener('click', () => {
  saveProxiedSites().catch((error) => log.error('options: saveProxiedSites', error));
});

els.addAiSitesButton.addEventListener('click', () => {
  addAiSites().catch((error) => log.error('options: addAiSites', error));
});

els.openExtensionsPageButton.addEventListener('click', () => {
  openExtensionsPage().catch((error) => log.error('options: openExtensionsPage', error));
});

// «Хранилище прокси»: фильтр, копирование адресов, возврат в список, очистка.
if (els.archiveCopyButton) {
  els.archiveCopyButton.addEventListener('click', () => {
    copyArchiveAddresses().catch((error) => log.error('options: archive copy', error));
  });
}

if (els.archiveTestButton) {
  els.archiveTestButton.addEventListener('click', () => {
    restoreArchiveProxies().catch((error) => log.error('options: archive restore', error));
  });
}

// Быстрый фильтр хранилища: все записи, только рабочие или только нерабочие.
for (const pair of [
  [els.archiveFilterAllButton, 'all'],
  [els.archiveFilterWorkingButton, 'working'],
  [els.archiveFilterOtherButton, 'other'],
]) {
  const button = pair[0];
  const value = pair[1];
  if (!button) continue;
  button.addEventListener('click', () => {
    archiveFilter = value;
    renderArchive();
  });
}

if (els.archiveFailLimitInput) {
  // Порог только сохраняем: удаление запускает кнопка, а не само расширение.
  els.archiveFailLimitInput.addEventListener('change', () => {
    const value = Math.max(0, parseInt(els.archiveFailLimitInput.value, 10) || 0);
    els.archiveFailLimitInput.value = String(value);
    saveSettings({ archiveFailLimit: value }).catch((error) =>
      log.error('options: archiveFailLimit', error)
    );
  });
}

if (els.archivePruneButton) {
  els.archivePruneButton.addEventListener('click', () => {
    pruneArchiveFails().catch((error) => log.error('options: archive prune', error));
  });
}

if (els.archiveClearButton) {
  els.archiveClearButton.addEventListener('click', () => {
    clearArchive().catch((error) => log.error('options: archive clear', error));
  });
}

// Журнал: фильтр по типу события, ручное обновление и очистка.
if (els.journalFilter) {
  els.journalFilter.addEventListener('change', () => renderJournal());
}

if (els.refreshJournalButton) {
  els.refreshJournalButton.addEventListener('click', () => {
    loadState()
      .then(() => {
        render();
        flashStatus(els.journalStatus, 'Журнал обновлён.');
      })
      .catch((error) => log.error('options: обновление журнала', error));
  });
}

if (els.clearJournalButton) {
  els.clearJournalButton.addEventListener('click', () => {
    if (!window.confirm('Очистить журнал событий?')) return;
    sendMessage({ type: 'clearJournal' })
      .then(() => loadState())
      .then(() => {
        render();
        flashStatus(els.journalStatus, 'Журнал очищен.');
      })
      .catch((error) => log.error('options: очистка журнала', error));
  });
}

// Пользователь мог переключить режим инкогнито на странице расширений и вернуться
// сюда: при возврате фокуса состояние перечитывается.
window.addEventListener('focus', () => {
  renderIncognito().catch((error) => log.debug('options: состояние инкогнито', error));
});

// Навигация по разделам.
for (const item of els.navItems) {
  item.addEventListener('click', () => {
    switchSection(item.dataset.target);
  });
}

// Обновляем UI при изменениях в хранилище.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;

  // Полная перерисовка нужна только когда изменились сами настройки: тогда
  // поля формы должны показать новые значения. Всё остальное (статистика
  // проверок, список прокси, журнал, хранилище) меняется само во время прогона,
  // поэтому обновляем только «живые» части страницы - иначе ввод в полях
  // стирался бы несколько раз в секунду.
  const update = 'settings' in changes ? render : renderLive;
  loadState()
    .then(update)
    .catch((error) => log.error('options: storage change', error));
});

(async () => {
  await loadState();
  render();
  switchSection('section-proxies');
  initSortableHeaders();
  initArchiveSortableHeaders();
  renderIncognito().catch((error) => log.debug('options: состояние инкогнито', error));
  // Проверка может идти прямо сейчас (в том числе фоновая) - сразу
  // подхватываем её статусы и прогресс.
  startProgressPolling();

  // Если у части прокси страна ещё не определена, дозаполняем её сразу при
  // открытии настроек: без этого колонка «Страна» остаётся с прочерками.
  const withoutCountry = (state.proxies || []).filter((proxy) => !proxy.country).length;
  if (withoutCountry) {
    log.info('options: автозаполнение стран', { count: withoutCountry });
    detectCountries().catch((error) => log.error('options: автозаполнение стран', error));
  }
})().catch((error) => log.error('options: init', error));
