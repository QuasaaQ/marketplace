/**
 * Q.Proxy - service worker.
 *
 * Задачи:
 *  - держать PAC-скрипт: сайты из списка - через прокси, остальные - напрямую;
 *  - автоматически тестировать прокси из списка в фоне (не нагружая ПК);
 *  - выбирать лучший рабочий прокси;
 *  - реагировать на изменения настроек.
 */

importScripts('shared/logger.js');
importScripts('shared/storage.js');

// Защитный fallback, если logger.js не загрузился.
const log =
  self.QProxyLog ||
  {
    debug() {},
    info() {},
    warn() {},
    error() {},
  };

log.info('background: service worker запущен');

if (!self.QProxyStorage) {
  log.error('background: QProxyStorage не найден - storage.js не загрузился');
}

const {
  getValue,
  setValue,
  getProxies,
  setProxies,
  getProxiedSites,
  setProxiedSites,
  getProxySources,
  setProxySources,
  getSettings,
  setSettings,
  getActiveProxy,
  setActiveProxy,
  getProxyStats,
  setProxyStats,
  getProxyArchive,
  setProxyArchive,
  isArchiveWorking,
  getProxyNotice,
  setProxyNotice,
  getJournal,
  setJournal,
  addJournalEntry,
  normalizeDomain,
  domainMatches,
  isProxied,
  formatProxyString,
  parseProxyList,
  dedupeProxies,
  passesCountryFilter,
  getFilterCountry,
  collectCountries,
  generateProxyId,
  TEST_TARGETS,
  GEOIP_SERVICES,
  IP_ECHO_SERVICES,
} = self.QProxyStorage;

const ALARM_TEST_PROXIES = 'qproxy-test-proxies';

// Сколько провалов подряд должно накопиться у прокси, прежде чем проверка
// сменит прежний вердикт. Одна неудачная проверка - не повод: публичные прокси
// отвечают с задержкой, а сбой сети выглядит как отказ всех прокси сразу.
const FAIL_RUNS_BEFORE_VERDICT = 2;

// Сколько провалов подряд должно накопиться, прежде чем авто-тест удалит прокси.
const FAIL_RUNS_BEFORE_DELETE = 3;

// Предел удаления за один прогон. Прогон мог случиться без связи (ноутбук ушёл
// в сон), и тогда пометка «ограничен» касалась всех прокси сразу: массовое
// удаление отменяется и попадает в журнал, список остаётся целым.
const MAX_DELETE_SHARE_PER_RUN = 0.25;
const MIN_DELETE_PER_RUN = 5;

// Сколько адресов удалённых прокси перечислять в журнале (остальные - счётчиком).
const JOURNAL_ADDRESS_LIMIT = 10;

// Сколько стран перечислять в записи журнала о добавленных прокси.
const COMPOSITION_COUNTRIES_LIMIT = 6;

// Насколько запуск по расписанию может опоздать, прежде чем это попадёт в журнал:
// небольшой сдвиг от нагрузки не интересен, а минуты и часы означают сон,
// гибернацию или пропажу интернета.
const AUTOTEST_LATE_THRESHOLD_MS = 2 * 60 * 1000;

// Причина вызова scheduleAutoTest после прогона: в этом случае время проверки
// законно уходит вперёд на интервал, и писать об этом в журнал не нужно.
const AUTOTEST_AFTER_RUN = 'после прогона';

// Отметка идущего прогона проверки в storage. Нужна, чтобы отличить прогон,
// который дошёл до конца, от прерванного: Chrome выгружает service worker, а
// проверка занимает минуты, поэтому прогон иногда обрывается на середине - и
// тогда в списке остаются прокси без результата («не проверено»).
const AUTOTEST_RUN_KEY = 'autoTestRun';

// Сколько записей хранить в «Хранилище прокси». Записи живут отдельно от
// списка прокси, поэтому ограничены только по количеству: при переполнении
// вытесняются те, что дольше всех не проверялись (см. trimArchive).
//
// 20000 записей - это примерно 2-3 МБ в chrome.storage.local (разрешение
// unlimitedStorage запрошено). Читается и пишется хранилище один раз за прогон,
// так что десятки миллисекунд на JSON туда-сюда на фоне проверки незаметны, а
// смысл хранилища как раз в том, чтобы не тестировать одни и те же мусорные
// адреса повторно.
const ARCHIVE_MAX_ENTRIES = 20000;

// Ключ расписания хранится в storage (ключ autoTestScheduled): по нему видно, что
// именно стоит в alarm сейчас. Нужен, чтобы не пересоздавать alarm, когда
// расписание не изменилось: create() перезапускает отсчёт, а service worker живёт
// не постоянно, поэтому без этой проверки проверка сдвигалась бы при каждом его
// перезапуске (например при перезапуске браузера) и могла не состояться вовсе.

// Текущая версия набора настроек - для одноразовых миграций. Когда появляются
// новые настройки с новыми значениями по умолчанию, у уже установленного
// расширения в storage лежат старые значения (туда пишется весь объект
// настроек целиком), поэтому одних DEFAULT_SETTINGS недостаточно.
// В DEFAULT_SETTINGS этот ключ намеренно не добавлен: иначе getSettings()
// подставлял бы текущую версию и миграция никогда бы не сработала.
//
// 2: включены «Отключаться от нерабочих», удаление недоступных при авто-тесте
//    и дозагрузка новых прокси.
// 3: убраны «Автозагрузка по таймеру» и «Проверять после загрузки».
// 4: включено «Удалять ограниченные».
// 5: включено «Удалять непроверенные» (после прерванного авто-теста).
const SETTINGS_VERSION = 5;

// Кэш настроек и списка сайтов для обработчика вкладок: читать storage на
// каждое событие вкладки - лишняя нагрузка. Кэш сбрасывается при изменениях
// в storage и освежается в applyProxySettings.
let settingsCache = null;
let proxiedSitesCache = null;

// Прогресс проверки прокси (для UI). alive - только полностью рабочие прокси,
// limited - не открывшие тестовый сайт, dead - недоступные.
let checkProgress = { total: 0, done: 0, running: false, alive: 0, limited: 0, dead: 0 };

// Доступ к приватным окнам: 'unknown' | 'allowed' | 'denied'. Страница
// настроек показывает подсказку, когда расширение не разрешено в инкогнито.
let incognitoState = 'unknown';

// ID прокси, которые проверяются прямо сейчас (для статуса «проверка…»).
const checkingIds = new Set();

// ID прокси, которые стоят в очереди (для статуса «в очереди»).
const queuedIds = new Set();

// Флаг остановки проверки.
let testAborted = false;

// Идёт ли проверка сейчас. Второй запуск поверх первого не допускается: иначе
// фоновый запуск (таймер или импорт источников) сбрасывает флаг остановки и
// нажатие «Остановить» теряется, а прогресс показывает чужие цифры.
let testInProgress = false;

// Контроллер отмены текущей проверки: по «Остановить» обрываем уже начатые
// запросы, не дожидаясь таймаута.
let testAbortController = null;

// ---------------------------------------------------------------------------
// Журнал действий
// ---------------------------------------------------------------------------

/**
 * Пишет запись в журнал: он показывается на вкладке «Журнал» в настройках.
 *
 * Недоступные прокси сюда не пишутся: такие события идут пачками и только
 * засоряют журнал. Пишутся именно действия - удаление прокси, автоматическая
 * замена, пропуск проверки.
 *
 * @param {string} kind switch | remove | skip | warn | info
 * @param {string} title
 * @param {string} [text]
 * @param {string} [proxy]
 * @returns {Promise<void>}
 */
async function addJournal(kind, title, text = '', proxy = '') {
  try {
    await addJournalEntry({ kind, title, text, proxy });
  } catch (error) {
    log.debug('background: не удалось записать в журнал', error);
  }
}

/**
 * Адреса прокси одной строкой для журнала (не длиннее лимита).
 * @param {Array<object>} proxies
 * @returns {string}
 */
function journalProxyList(proxies) {
  const list = (proxies || []).map((proxy) => formatProxyString(proxy));
  const shown = list.slice(0, JOURNAL_ADDRESS_LIMIT);
  const rest = list.length - shown.length;
  return shown.join(', ') + (rest > 0 ? ', и ещё ' + rest : '');
}

/**
 * Время в формате ЧЧ:ММ:СС для журнала.
 * @param {number} at отметка времени, мс
 * @returns {string}
 */
function formatClockTime(at) {
  const date = new Date(Number(at) || Date.now());
  return date.toLocaleTimeString('ru-RU', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

/**
 * Человекочитаемая длительность: миллисекунды, секунды, минуты.
 * @param {number} ms
 * @returns {string}
 */
function formatDuration(ms) {
  const value = Math.max(0, Math.round(Number(ms) || 0));
  if (value < 1000) return value + ' мс';
  if (value < 60000) return (value / 1000).toFixed(1) + ' с';
  const minutes = Math.floor(value / 60000);
  const seconds = Math.round((value % 60000) / 1000);
  return minutes + ' мин ' + seconds + ' с';
}

/**
 * Строка хронометража замены прокси для журнала.
 *
 * Точка отсчёта - начало загрузки проксируемой страницы, поэтому в журнале
 * видно, сколько времени прошло от попытки открыть сайт до включения другого
 * прокси и на что это время ушло (обнаружение сбоя, проверка связи, сама смена).
 *
 * @param {{startedAt?: number, detectedAt?: number, netCheckMs?: number}} timing
 * @param {number} switchedAt когда новый прокси встал в работу
 * @returns {string}
 */
function formatSwitchTiming(timing, switchedAt) {
  const detectedAt = Number(timing.detectedAt) || switchedAt;
  const parts = [];

  if (timing.startedAt) parts.push('загрузка ' + formatClockTime(timing.startedAt));
  parts.push('сбой ' + formatClockTime(detectedAt));
  if (Number(timing.netCheckMs) > 0) {
    parts.push('проверка связи ' + formatDuration(timing.netCheckMs));
  }
  parts.push('замена ' + formatClockTime(switchedAt));
  parts.push('вердикт ' + formatDuration(switchedAt - detectedAt));
  if (timing.startedAt) {
    parts.push('всего ' + formatDuration(switchedAt - Number(timing.startedAt)));
  }

  return 'Хронометраж: ' + parts.join(', ') + '.';
}

/**
 * Записывает в журнал, что расписание авто-теста поставлено или переставлено.
 *
 * Запись появляется, когда изменилось само расписание ИЛИ когда сдвинулось время
 * ближайшей проверки. Второе важно: при перезагрузке расширения Chrome удаляет
 * его alarms, и проверка переезжает на интервал вперёд - без такой записи это
 * выглядит как «авто-тест не пришёл в обещанное время», хотя расписание цело.
 *
 * Записи и плановое время хранятся в отдельных ключах, чтобы не трогать объект
 * настроек.
 *
 * @param {string} reason причина постановки расписания (для журнала)
 * @param {string} schedule описание расписания
 * @param {number} plannedAt плановое время ближайшей проверки (0 - проверок не будет)
 * @returns {Promise<void>}
 */
async function noteAutoTestSchedule(reason, schedule, plannedAt) {
  try {
    const previousSchedule = String((await getValue('autoTestScheduleInfo', '')) || '');
    const previousPlanned = Number(await getValue('autoTestExpectedAt', 0)) || 0;
    const planned = Number(plannedAt) || 0;

    // Ничего не изменилось: ни расписание, ни время ближайшей проверки.
    if (previousSchedule === schedule && previousPlanned === planned) return;

    await setValue('autoTestScheduleInfo', schedule);
    await setValue('autoTestExpectedAt', planned);

    const changed = previousSchedule !== schedule;
    const parts = [schedule + '.'];

    if (planned) parts.push('Ближайшая проверка: ' + formatClockTime(planned) + '.');

    // Расписание то же, а время уехало: так бывает, когда расширение
    // перезагрузили (Chrome при этом удаляет его alarms) или пропал интернет.
    if (!changed && planned && previousPlanned && planned !== previousPlanned) {
      parts.push(
        'Время сдвинуто с ' +
          formatClockTime(previousPlanned) +
          ' на ' +
          formatClockTime(planned) +
          ' (' +
          formatDuration(Math.abs(planned - previousPlanned)) +
          ').'
      );
    }

    if (reason) parts.push('Причина: ' + reason + '.');

    await addJournal(
      'info',
      changed ? 'Авто-тест: расписание обновлено' : 'Авто-тест: время проверки уточнено',
      parts.join(' ')
    );
  } catch (error) {
    log.debug('background: не удалось записать расписание в журнал', error);
  }
}

/**
 * Проверяет, есть ли вообще связь с интернетом, и возвращает подробности.
 *
 * Нужна, чтобы сбой всей сети (ноутбук ушёл в сон, отвалился Wi-Fi) не выглядел
 * как «все прокси не работают»: иначе один ночной прогон помечал ограниченными
 * и удалял весь список. Подробности (сколько заняла проверка, какой адрес
 * ответил, сколько адресов перебрали) идут в журнал: по ним видно, что именно
 * проверялось, когда связь пропала.
 *
 * Адрес выбирается среди тех, что идут напрямую: если проверять хост через сам
 * прокси, недоступность прокси снова выглядела бы как отсутствие интернета.
 *
 * @param {object} settings
 * @returns {Promise<{ok: boolean, ms: number, url: string, tried: number}>}
 */
async function checkNetwork(settings) {
  const started = Date.now();

  let proxiedSites = [];
  try {
    proxiedSites = await getProxiedSites();
  } catch (error) {
    /* проверяем как есть */
  }

  const candidates = [settings.testUrl, ...Object.values(TEST_TARGETS)].filter(Boolean);
  const direct = candidates.filter((url) => !isProxied(hostFromUrl(url), proxiedSites));
  const urls = direct.length ? direct : candidates;

  let tried = 0;
  for (const url of urls) {
    tried += 1;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch(url, { cache: 'no-store', signal: controller.signal });
      if (response && (response.ok || response.status < 500)) {
        return { ok: true, ms: Date.now() - started, url, tried };
      }
    } catch (error) {
      /* пробуем следующий адрес */
    } finally {
      clearTimeout(timer);
    }
  }

  return { ok: false, ms: Date.now() - started, url: urls[0] || '', tried };
}

/**
 * Пишет в журнал опоздание запуска по расписанию.
 *
 * Плановое время записывается при постановке alarm. Chrome выполняет пропущенный
 * alarm сразу после пробуждения машины, поэтому разница между планом и фактом
 * показывает сон, гибернацию или пропажу интернета - без этой записи поздний
 * запуск выглядел бы как обычный.
 *
 * @returns {Promise<void>}
 */
async function journalAutoTestDelay() {
  try {
    const planned = Number(await getValue('autoTestExpectedAt', 0)) || 0;
    if (!planned) return;

    const lateMs = Date.now() - planned;
    if (lateMs <= AUTOTEST_LATE_THRESHOLD_MS) return;

    await addJournal(
      'warn',
      'Авто-тест запущен с опозданием',
      'Планировалось ' +
        formatClockTime(planned) +
        ', запуск ' +
        formatClockTime(Date.now()) +
        ': опоздание ' +
        formatDuration(lateMs) +
        '. Так бывает после сна, гибернации или пропажи интернета.'
    );
  } catch (error) {
    log.debug('background: не удалось записать опоздание авто-теста', error);
  }
}

// ---------------------------------------------------------------------------
// PAC-скрипт
// ---------------------------------------------------------------------------

/**
 * Экранирует строку для безопасной вставки в JS-код PAC.
 * @param {string} value
 * @returns {string}
 */
function jsString(value) {
  return JSON.stringify(String(value));
}

/**
 * Преобразует прокси в формат, понятный PAC-скрипту.
 *
 * PAC не понимает URL-схемы вида `socks5://host:port`. Он ожидает одну из
 * строк: `PROXY host:port`, `SOCKS host:port`, `SOCKS5 host:port`,
 * `HTTPS host:port`.
 *
 * Протокол берётся из общего переключателя настроек (`proxyProtocol`),
 * а не из самого прокси - в списке хранятся только host:port.
 *
 * @param {object} proxy
 * @param {string} protocol
 * @returns {string}
 */
function toPacProxyString(proxy, protocol) {
  if (!proxy) return '';
  const hostPort = `${proxy.host}:${proxy.port}`;
  switch (protocol) {
    case 'socks5':
      return `SOCKS5 ${hostPort}`;
    case 'socks4':
      return `SOCKS ${hostPort}`;
    case 'https':
      return `HTTPS ${hostPort}`;
    case 'http':
    default:
      return `PROXY ${hostPort}`;
  }
}

/**
 * Общие функции PAC-скриптов: нормализация хоста, отсечение локальных адресов
 * и проверка домена вместе с поддоменами.
 *
 * PAC-скрипты не поддерживают модули, поэтому helper-функции вставляются
 * текстом в каждый скрипт.
 *
 * Отсечение локальных и приватных адресов обязательно: прокси не может
 * достать машину в её собственной сети, поэтому попытка проксировать
 * 192.168.1.1, роутер или локальный сервер делает их недоступными.
 */
const PAC_HELPERS = `
function pacHost(host) {
  var value = String(host || '').toLowerCase();
  if (value.charAt(value.length - 1) === '.') {
    value = value.substring(0, value.length - 1);
  }
  return value;
}

function isLocalHost(host) {
  if (!host) return true;
  if (host === 'localhost' || host === '127.0.0.1' || host === '::1') return true;
  if (host.substring(host.length - 6) === '.local') return true;
  if (/^127\\./.test(host)) return true;
  if (/^10\\./.test(host)) return true;
  if (/^192\\.168\\./.test(host)) return true;
  if (/^172\\.(1[6-9]|2[0-9]|3[01])\\./.test(host)) return true;
  if (/^169\\.254\\./.test(host)) return true;
  if (/^f[cd][0-9a-f]{2}:/i.test(host)) return true;
  if (/^fe80:/i.test(host)) return true;
  return false;
}

function hostMatches(host, domain) {
  host = pacHost(host);
  domain = pacHost(domain);
  if (!host || !domain) return false;
  return host === domain || host.substring(host.length - domain.length - 1) === '.' + domain;
}

function matchesAny(host, list) {
  for (var i = 0; i < list.length; i++) {
    if (hostMatches(host, list[i])) return true;
  }
  return false;
}
`.trim();

/**
 * Строит PAC-скрипт на основе текущих настроек.
 *
 * Логика простая:
 *  - если расширение выключено или нет прокси → DIRECT;
 *  - локальные и приватные адреса → всегда DIRECT;
 *  - если proxyAllTraffic → всё через прокси;
 *  - если домен в списке проксируемых → PROXY;
 *  - иначе → DIRECT.
 *
 * @param {object} config
 * @returns {string}
 */
function buildPacScript(config) {
  const { enabled, proxyAllTraffic, proxyString, proxiedDomains } = config;

  if (!enabled || !proxyString) {
    return 'function FindProxyForURL(url, host) { return "DIRECT"; }';
  }

  const domainsList = JSON.stringify(proxiedDomains || []);

  return `
var PROXY = ${jsString(proxyString)};
var PROXY_ALL = ${proxyAllTraffic ? 'true' : 'false'};
var DOMAINS = ${domainsList};
${PAC_HELPERS}
function FindProxyForURL(url, host) {
  host = pacHost(host);
  if (isLocalHost(host)) return "DIRECT";
  if (PROXY_ALL) return PROXY;
  if (matchesAny(host, DOMAINS)) return PROXY;
  return "DIRECT";
}
`.trim();
}

/**
 * Строит PAC-скрипт для проверки одного прокси.
 *
 * Проверка выполняется через временную подмену PAC браузера (в MV3 другого
 * способа нет), поэтому тестовый PAC намеренно «узкий»: через проверяемый
 * прокси идут ТОЛЬКО хосты проверки. Сайты из списка в это время продолжают
 * работать через активный прокси, остальные сайты - напрямую. Поэтому проверка
 * не ломает посторонние сайты и безопасна даже при выгрузке service worker.
 *
 * @param {object} config
 * @param {string} config.proxyString строка проверяемого прокси
 * @param {Array<string>} config.testHosts хосты, которые проверяются
 * @param {string} [config.keepProxyString] строка активного прокси
 * @param {Array<string>} [config.keepDomains] сайты из списка проксируемых
 * @param {boolean} [config.keepAllTraffic] режим «весь трафик через прокси»
 * @returns {string}
 */
function buildTestPacScript(config) {
  const { proxyString, testHosts, keepProxyString, keepDomains, keepAllTraffic } = config;

  return `
var PROXY = ${jsString(proxyString)};
var TEST_HOSTS = ${JSON.stringify(testHosts || [])};
var KEEP_PROXY = ${jsString(keepProxyString || '')};
var KEEP_DOMAINS = ${JSON.stringify(keepDomains || [])};
var KEEP_ALL = ${keepAllTraffic ? 'true' : 'false'};
${PAC_HELPERS}
function FindProxyForURL(url, host) {
  host = pacHost(host);
  if (isLocalHost(host)) return "DIRECT";
  if (matchesAny(host, TEST_HOSTS)) return PROXY;
  if (KEEP_PROXY && KEEP_ALL) return KEEP_PROXY;
  if (KEEP_PROXY && matchesAny(host, KEEP_DOMAINS)) return KEEP_PROXY;
  return "DIRECT";
}
`.trim();
}

/**
 * Достаёт хост из URL.
 * @param {string} url
 * @returns {string}
 */
function hostFromUrl(url) {
  try {
    return String(new URL(String(url || '')).hostname || '').toLowerCase();
  } catch (error) {
    return '';
  }
}

/**
 * Хосты, которые нужно провести через проверяемый прокси: цель проверки,
 * тестовый сайт и IP-echo сервисы (по ним определяется страна выхода).
 *
 * @param {object} settings
 * @returns {Array<string>}
 */
function collectTestHosts(settings) {
  const urls = [settings.testUrl, settings.siteTestUrl, ...IP_ECHO_SERVICES];
  const hosts = [];
  for (const url of urls) {
    const host = hostFromUrl(url);
    if (!host || host === 'localhost' || hosts.includes(host)) continue;
    hosts.push(host);
  }
  return hosts;
}

/**
 * Проверяет, разрешено ли расширению работать в приватных окнах.
 *
 * @returns {Promise<boolean|null>} null - состояние определить не удалось
 */
function isIncognitoAllowed() {
  return new Promise((resolve) => {
    try {
      if (!chrome.extension || typeof chrome.extension.isAllowedIncognitoAccess !== 'function') {
        resolve(null);
        return;
      }
      chrome.extension.isAllowedIncognitoAccess((allowed) => resolve(!!allowed));
    } catch (error) {
      resolve(null);
    }
  });
}

/**
 * Применяет конфиг прокси: отдельно в обычные окна, отдельно в инкогнито.
 *
 * Инкогнито - это отдельный скоуп настроек. Если расширение не разрешено в
 * приватных окнах, Chrome не даёт туда писать: результат попытки сохраняется в
 * incognitoState, а страница настроек показывает подсказку. Писать в инкогнито
 * нужно явно: тогда проксируемые сайты работают и в приватных окнах так же,
 * как в обычных.
 *
 * @param {object} config конфиг chrome.proxy
 * @returns {Promise<{regular: boolean, incognito: boolean}>}
 */
async function applyProxyConfig(config) {
  const applied = { regular: false, incognito: false };

  try {
    // Сначала очищаем, затем ставим - это гарантирует переприменение PAC
    // даже если Chrome закэшировал предыдущее значение.
    await chrome.proxy.settings.clear({ scope: 'regular' });
    await chrome.proxy.settings.set({ value: config, scope: 'regular' });
    applied.regular = true;
  } catch (error) {
    log.error('background: не удалось применить настройки прокси (обычные окна)', error);
  }

  const allowed = await isIncognitoAllowed();
  if (allowed === false) {
    incognitoState = 'denied';
    return applied;
  }

  try {
    await chrome.proxy.settings.set({ value: config, scope: 'incognito_persistent' });
    applied.incognito = true;
    incognitoState = 'allowed';
  } catch (error) {
    incognitoState = 'denied';
    log.debug('background: настройки прокси для инкогнито не применены', error);
  }

  return applied;
}

/**
 * Применяет PAC-скрипт в браузере.
 * @returns {Promise<void>}
 */
async function applyProxySettings() {
  const settings = await getSettings();
  const activeProxy = await getActiveProxy();
  const proxiedSites = await getProxiedSites();

  // Освежаем кэш для обработчика вкладок: applyProxySettings вызывается после
  // каждого изменения настроек и списка сайтов, поэтому иконка вкладки всегда
  // будет строиться на актуальных данных без лишних чтений storage.
  settingsCache = settings;
  proxiedSitesCache = proxiedSites;

  const proxiedDomains = Array.from(
    new Set(proxiedSites.map(normalizeDomain).filter(Boolean))
  );

  // ВАЖНО: PAC не понимает `socks5://host:port`, нужен формат `SOCKS5 host:port`.
  // Протокол берём из общего переключателя настроек.
  const proxyString = toPacProxyString(activeProxy, settings.proxyProtocol);
  const pacScript = buildPacScript({
    enabled: settings.enabled,
    proxyAllTraffic: settings.proxyAllTraffic,
    proxyString,
    proxiedDomains,
  });

  const config = {
    mode: 'pac_script',
    pacScript: { data: pacScript },
  };

  log.debug('background: применяем PAC', {
    enabled: settings.enabled,
    proxyAllTraffic: settings.proxyAllTraffic,
    proxy: proxyString || '(нет)',
    domains: proxiedDomains.length,
  });

  const applied = await applyProxyConfig(config);
  log.info('background: PAC применён', {
    proxy: proxyString || '(нет)',
    domains: proxiedDomains.length,
    scopes: applied,
  });

  // Диагностика: читаем фактические настройки прокси.
  try {
    const actual = await chrome.proxy.settings.get({ incognito: false });
    log.debug('background: фактические настройки прокси', {
      levelOfControl: actual.levelOfControl,
      mode: actual.value && actual.value.mode,
      hasPac: !!(actual.value && actual.value.pacScript),
    });

    if (actual.levelOfControl === 'controlled_by_other_extensions') {
      log.warn(
        'background: настройки прокси контролируются другим расширением - Q.Proxy не может применить PAC'
      );
    }
  } catch (error) {
    log.debug('background: не удалось прочитать фактические настройки прокси', error);
  }

  if (incognitoState === 'denied') {
    log.info(
      'background: приватные окна - расширение не разрешено в инкогнито. ' +
        'Включите «Разрешить в режиме инкогнито» на странице chrome://extensions'
    );
  }

  // Состояние проксирования могло измениться - обновляем иконку вкладки.
  refreshActiveTabIcon().catch((error) => log.debug('background: иконка вкладки', error));
}

// ---------------------------------------------------------------------------
// Иконка расширения на вкладке
// ---------------------------------------------------------------------------

// Иконка в панели расширений повторяет круглую кнопку из попапа: серая, когда
// сайт открывается напрямую, зелёная - когда через прокси.
const TAB_ICON_FILES = {
  default: 'proxy-off',
  proxy: 'proxy-on',
  disabled: 'proxy-off',
};

const TAB_ICON_SIZES = [16, 32, 48, 128];

// Последняя выставленная иконка по вкладкам: { state, at }. chrome.tabs.onUpdated
// срабатывает пачками, поэтому в пределах TAB_ICON_TTL повторно ту же иконку
// не ставим. Но и не «залипаем»: если Chrome сбросил иконку вкладки, следующий
// вызов её вернёт.
const tabIconState = new Map();
const TAB_ICON_TTL = 5000;

/**
 * Настройки из кэша (для частых вызовов - иконка вкладки).
 * Объявление кэша - выше, рядом с константами.
 * @returns {Promise<object>}
 */
async function getCachedSettings() {
  if (!settingsCache) settingsCache = await getSettings();
  return settingsCache;
}

/**
 * Список проксируемых сайтов из кэша (для частых вызовов - иконка вкладки).
 * @returns {Promise<Array<string>>}
 */
async function getCachedProxiedSites() {
  if (!proxiedSitesCache) proxiedSitesCache = await getProxiedSites();
  return proxiedSitesCache;
}

/**
 * Набор путей иконки для chrome.action.setIcon: все размеры, чтобы иконка
 * оставалась резкой на любом экране.
 *
 * @param {string} state default | proxy | disabled
 * @returns {object}
 */
function tabIconSet(state) {
  const name = TAB_ICON_FILES[state] || TAB_ICON_FILES.default;
  const path = {};
  for (const size of TAB_ICON_SIZES) {
    path[size] = chrome.runtime.getURL(`images/icons/${size}x${size}/${name}.png`);
  }
  return path;
}

const TAB_TITLES = {
  default: 'Q.Proxy',
  proxy: 'Q.Proxy - сайт открывается через прокси',
  disabled: 'Q.Proxy выключен',
};

/**
 * Ставит иконку и заголовок одной вкладки.
 * @param {number} tabId
 * @param {string} state default | proxy | disabled
 * @param {boolean} [force] поставить иконку даже если такая уже стоит
 */
function setTabIcon(tabId, state, force = false) {
  if (typeof tabId !== 'number' || tabId < 0) return;

  const prev = tabIconState.get(tabId);
  const now = Date.now();
  if (!force && prev && prev.state === state && now - prev.at < TAB_ICON_TTL) return;
  tabIconState.set(tabId, { state, at: now });

  try {
    chrome.action.setIcon({ tabId, path: tabIconSet(state) });
    chrome.action.setTitle({ tabId, title: TAB_TITLES[state] || TAB_TITLES.default });
  } catch (error) {
    log.debug('background: не удалось поставить иконку вкладки', error);
  }
}

/**
 * Значок на иконке расширения: показывает, что активный прокси был признан
 * нерабочим и заменён. Пустой текст убирает значок.
 * @param {string} text
 */
function setActionBadge(text) {
  try {
    chrome.action.setBadgeText({ text: text || '' });
    if (text) chrome.action.setBadgeBackgroundColor({ color: '#e5484d' });
  } catch (error) {
    log.debug('background: не удалось поставить значок', error);
  }
}

// Сколько держится сообщение о замене прокси (совпадает с попапом).
const NOTICE_TTL = 30 * 60 * 1000;

/**
 * Убирает значок «!» с иконки расширения, но только если сообщения о замене
 * прокси нет или оно устарело.
 *
 * Значок и сообщение в попапе показывают одно и то же событие, поэтому снимаются
 * вместе: крестиком в попапе, ручным выбором прокси или успешной проверкой.
 * Иначе значок «моргал» бы: замена только что произошла, а проверка нового
 * прокси тут же гасит «!».
 *
 * @returns {Promise<void>}
 */
async function clearActionBadgeIfNoNotice() {
  try {
    const notice = await getProxyNotice();
    if (notice && notice.at && Date.now() - notice.at < NOTICE_TTL) return;
    if (notice) await setProxyNotice(null);
    setActionBadge('');
  } catch (error) {
    log.debug('background: не удалось проверить сообщение о замене прокси', error);
  }
}

/**
 * Определяет состояние вкладки и обновляет её иконку.
 * @param {number} tabId
 * @param {string} url
 * @param {boolean} [force] не опираться на кэш последней иконки: нужен точный
 *   результат прямо сейчас (закрытие уведомления, смена активного прокси)
 * @returns {Promise<void>}
 */
async function refreshTabIcon(tabId, url, force = false) {
  const settings = await getCachedSettings();
  if (!settings.enabled) {
    setTabIcon(tabId, 'disabled', force);
    return;
  }

  const host = normalizeDomain(url || '');
  if (!host || (!host.includes('.') && host !== 'localhost')) {
    setTabIcon(tabId, 'default', force);
    return;
  }

  const proxiedSites = await getCachedProxiedSites();
  const viaProxy = !!settings.proxyAllTraffic || isProxied(host, proxiedSites);
  setTabIcon(tabId, viaProxy ? 'proxy' : 'default', force);
}

/**
 * Обновляет иконку активной вкладки: вызывается после смены настроек,
 * списка проксируемых сайтов и активного прокси.
 * @param {boolean} [force] пересчитать иконку, не опираясь на кэш
 * @returns {Promise<void>}
 */
async function refreshActiveTabIcon(force = false) {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const tab = tabs && tabs[0];
  if (tab) await refreshTabIcon(tab.id, tab.url, force);
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!tab) return;

  // Реагируем на начало загрузки (в том числе на обновление страницы), смену
  // URL и завершение загрузки. URL берём из tab.url: при перезагрузке
  // changeInfo.url не приходит. Повторные вызовы дешевы - storage читается из
  // кэша, а setTabIcon не дёргает API в пределах TAB_ICON_TTL.
  const relevant =
    typeof changeInfo.url === 'string' ||
    changeInfo.status === 'loading' ||
    changeInfo.status === 'complete';
  if (!relevant) return;

  // Последний настоящий адрес вкладки. На странице с ошибкой (ERR_CONNECTION_RESET
  // и подобные) Chrome показывает chrome-error://..., поэтому адрес, который не
  // открылся, приходится помнить: иначе непонятно, к какому сайту относится сбой.
  if (typeof changeInfo.url === 'string' && /^https?:/i.test(changeInfo.url)) {
    tabLastUrl.set(tabId, changeInfo.url);
  }

  if (changeInfo.status === 'loading') tabLoadStartedAt.set(tabId, Date.now());

  const errorPage = /^chrome-error:/i.test(tab.url || '');
  const effectiveUrl = /^https?:/i.test(tab.url || '')
    ? tab.url
    : tab.pendingUrl || tabLastUrl.get(tabId) || '';

  if (effectiveUrl) {
    refreshTabIcon(tabId, effectiveUrl).catch((error) =>
      log.debug('background: иконка вкладки при загрузке', error)
    );
  }

  // «Отключаться от нерабочих»: проверяем только факт открытия страницы, и
  // только после завершения загрузки. Постоянного опроса нет, а саму ошибку
  // прокси Chrome сообщает отдельно (chrome.proxy.onProxyError) - это самый
  // быстрый сигнал, он приходит раньше таймаута загрузки.
  if (changeInfo.status === 'complete') {
    verifyProxiedTabLoad(tab, tabLoadStartedAt.get(tabId) || 0, {
      url: effectiveUrl,
      errorPage,
    }).catch((error) => log.debug('background: проверка загрузки страницы', error));
  }
});

chrome.tabs.onActivated.addListener((info) => {
  chrome.tabs
    .get(info.tabId)
    .then((tab) => refreshTabIcon(info.tabId, tab && tab.url))
    .catch((error) => log.debug('background: иконка вкладки при активации', error));
});

chrome.tabs.onRemoved.addListener((tabId) => {
  tabIconState.delete(tabId);
  tabLoadStartedAt.delete(tabId);
  tabLastUrl.delete(tabId);
});

// Chrome сам сообщает о сетевых ошибках прокси - это самый быстрый сигнал:
// ERR_PROXY_CONNECTION_FAILED и подобные видны сразу, без ожидания таймаута
// проверки. Реакция мгновенная: прокси выводится из работы, включается
// следующий, а проверка нерабочего прокси прекращается.
if (chrome.proxy && chrome.proxy.onProxyError) {
  chrome.proxy.onProxyError.addListener((details) => {
    try {
      const errorText = details && details.error ? String(details.error) : 'proxy_error';
      log.warn('background: ошибка прокси от Chrome', {
        error: errorText,
        fatal: details && details.fatal,
      });
      // Подтверждающей проверки нет, но прокси меняется только тогда, когда
      // ошибка относится к запросу, который действительно шёл через прокси.
      // Момент прихода события сохраняем: он нужен для хронометража в журнале.
      handleProxyErrorImmediate(errorText, details, Date.now()).catch((error) =>
        log.debug('background: обработка ошибки прокси', error)
      );
    } catch (error) {
      log.debug('background: обработка ошибки прокси', error);
    }
  });
}

// ---------------------------------------------------------------------------
// Загрузка списков прокси из источников
// ---------------------------------------------------------------------------

/**
 * Загружает текст по URL.
 * @param {string} url
 * @returns {Promise<string>}
 */
async function fetchText(url) {
  const response = await fetch(url, { cache: 'no-store', redirect: 'follow' });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  return response.text();
}

/**
 * Случайная выборка без повторов (перемешивание Фишера-Йетса).
 *
 * Нужна для лимита прокси: в списках-источниках порядок строк не меняется,
 * поэтому без перемешивания каждый импорт брал бы одни и те же первые прокси
 * файла.
 *
 * @param {Array<*>} items
 * @param {number} count
 * @returns {Array<*>}
 */
function pickRandom(items, count) {
  const list = items.slice();
  for (let i = list.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const swap = list[i];
    list[i] = list[j];
    list[j] = swap;
  }
  return list.slice(0, Math.max(0, Number(count) || 0));
}

/**
 * Загружает прокси из всех источников и добавляет их в список.
 *
 * @returns {Promise<{added: number, sources: number, errors: Array<string>}>}
 */
async function fetchProxySources() {
  const settings = await getSettings();
  const sources = await getProxySources();
  const errors = [];

  if (!sources.length) {
    log.warn('background: источники прокси не заданы');
    return { added: 0, sources: 0, errors: [] };
  }

  log.info('background: загрузка источников прокси', { count: sources.length });

  // Сколько строк дал каждый источник: нужно для разбора состава выборки. Она
  // берётся из объединения источников, а не поровну от каждого, поэтому большой
  // список определяет, какие страны вообще попадут в прокси.
  const collected = [];
  const bySource = [];
  for (const url of sources) {
    try {
      const text = await fetchText(url);
      const parsed = parseProxyList(text);
      log.debug('background: источник загружен', { url, found: parsed.length });
      collected.push(...parsed);
      bySource.push({ url, found: parsed.length });
    } catch (error) {
      log.warn('background: не удалось загрузить источник', url, error);
      errors.push(`${url}: ${error && error.message ? error.message : error}`);
    }
  }

  const existing = await getProxies();
  const existingKeys = new Set(existing.map((p) => `${p.host}:${p.port}`));

  // Что из источника уже есть в «Хранилище прокси». Нерабочие записи повторно не
  // берём: иначе один и тот же мусор проверялся бы каждый раз заново. Записи,
  // которые когда-то работали, добору не мешают - у них остаётся шанс вернуться.
  const archive = await getProxyArchive();

  const fresh = [];
  let matchedArchive = 0;
  let skippedBad = 0;
  for (const parsed of collected) {
    const key = `${parsed.host}:${parsed.port}`;
    if (existingKeys.has(key)) continue;

    const known = archive[key];
    if (known) {
      matchedArchive += 1;
      if (!isArchiveWorking(known)) {
        skippedBad += 1;
        continue;
      }
    }

    existingKeys.add(key);
    fresh.push({
      id: generateProxyId(),
      name: '',
      ...parsed,
    });
  }

  if (matchedArchive) {
    log.info('background: из источников совпало с хранилищем', {
      matched: matchedArchive,
      skippedBad,
      collected: collected.length,
    });
  }

  // Лимит прокси: 0 - без ограничения. Считается он по РАБОЧИМ прокси, а не по
  // строкам списка: нерабочие и непроверенные место в лимите не занимают - иначе
  // список, забитый мусором, навсегда перекрыл бы дозаливку.
  //
  // Общий размер списка всё же ограничен: прокси проверяются по очереди, и сотни
  // строк проверялись бы слишком долго. Предел - двойной лимит.
  //
  // Из источника берём случайную выборку, а не первые строки: порядок строк в
  // публичных списках не меняется, поэтому раньше каждый импорт приносил одни и
  // те же прокси, хотя в файле их тысячи.
  const sourcesLimit = Math.max(0, parseInt(settings.sourcesLimit, 10) || 0);
  if (sourcesLimit) {
    const stats = await getProxyStats();
    const working = countWorkingProxies(existing, stats);
    const wanted = Math.max(0, sourcesLimit - working);
    const room = Math.min(wanted, Math.max(0, sourcesLimit * 2 - existing.length));
    if (fresh.length > room) {
      const picked = pickRandom(fresh, room);
      log.info('background: сработал лимит рабочих прокси - взята случайная выборка', {
        limit: sourcesLimit,
        working,
        current: existing.length,
        found: fresh.length,
        kept: picked.length,
        // Размер каждого источника: по нему видно, чей вклад в выборку больше.
        bySource,
      });
      fresh.length = 0;
      for (const proxy of picked) fresh.push(proxy);
    }
  }

  let merged = dedupeProxies([...existing, ...fresh]);

  // Фильтр по стране размещения применяется сразу после импорта. Если базой
  // выбрана страна выхода, фильтр выполняет testAllProxies: до проверки
  // exitCountry неизвестен.
  if (
    settings.countryFilterAuto &&
    settings.countryFilterMode !== 'off' &&
    settings.countryFilterBase !== 'exit'
  ) {
    const before = merged.length;
    merged = merged.filter((proxy) => passesCountryFilter(proxy, settings));
    log.info('background: фильтр стран удалил прокси', before - merged.length);
    if (before !== merged.length) {
      await addJournal(
        'remove',
        'Фильтр стран удалил прокси',
        'Удалено при загрузке источников: ' + (before - merged.length) + '.'
      );
    }
  }

  await setProxies(merged);
  log.info('background: источники обработаны', {
    added: fresh.length,
    total: merged.length,
    errors: errors.length,
  });

  // Страны новых прокси определяем сразу: иначе колонка «Страна» остаётся
  // пустой до ручного нажатия кнопки.
  //
  // Добавление прокси - тоже действие расширения, и оно видно в журнале: иначе
  // непонятно, сработала ли дозаливка. Запись идёт после определения стран, чтобы
  // в неё попал состав: сколько строк дал каждый источник и по каким странам
  // пришли адреса. По нему сразу видно, откуда в списке та или иная страна.
  if (fresh.length) {
    try {
      await detectCountries({ limit: 200 });
    } catch (error) {
      log.warn('background: определение стран после загрузки источников', error);
    }

    const composition = await describeAddedComposition(fresh, bySource);
    log.info('background: состав добавленных прокси', {
      added: fresh.length,
      byCountry: composition.byCountry,
      sources: composition.bySource,
      skippedBad,
    });

    await addJournal(
      'info',
      'Добавлены новые прокси',
      [
        'Из источников добавлено ' + fresh.length + ', всего в списке ' + merged.length + '.',
        formatSourceComposition(composition.bySource, composition.byCountry),
        matchedArchive
          ? 'Совпало с хранилищем: ' +
            matchedArchive +
            (skippedBad ? ' (из них нерабочих пропущено: ' + skippedBad + ')' : '') +
            '.'
          : '',
      ]
        .filter(Boolean)
        .join(' ')
    );

    // Фильтр по стране размещения теперь можно применить по-настоящему: страны
    // только что добавленных прокси уже известны. До этого прохода стран у них не
    // было, поэтому фильтр их пропускал - и они успевали попасть в проверку.
    await applyPlacementFilter(settings);
  }

  // Свежие прокси проверяем сразу после загрузки - так работает и кнопка
  // «Загрузить сейчас». Если проверка уже идёт (загрузка вызвана дозаливкой
  // внутри авто-теста), вызов пропускается: свежие прокси проверит текущий
  // запуск, потому что дозаливка выполняется до чтения списка.
  if (fresh.length && !testInProgress) {
    await testAllProxies(fresh.map((proxy) => proxy.id));
  } else {
    await selectBestProxy();
    await applyProxySettings();
  }

  return { added: fresh.length, sources: sources.length, errors };
}

/**
 * Применяет фильтр по стране размещения к текущему списку.
 *
 * Первый проход в fetchProxySources идёт до определения стран, поэтому только что
 * добавленные прокси его проходят «на всякий случай»: страны у них ещё нет. После
 * определения стран фильтр применяется ещё раз - иначе прокси из запрещённых
 * стран остаются в списке до следующей дозаливки и успевают попасть в проверку.
 *
 * @param {object} settings
 * @returns {Promise<number>} сколько прокси удалено
 */
async function applyPlacementFilter(settings) {
  if (!settings.countryFilterAuto) return 0;
  if (settings.countryFilterMode === 'off') return 0;
  if (settings.countryFilterBase === 'exit') return 0;

  const proxies = await getProxies();
  const kept = proxies.filter((proxy) => passesCountryFilter(proxy, settings));
  const removed = proxies.length - kept.length;
  if (!removed) return 0;

  await setProxies(kept);
  log.info('background: фильтр стран удалил прокси после определения стран', {
    removed,
    kept: kept.length,
  });
  await addJournal(
    'remove',
    'Фильтр стран удалил прокси',
    'Удалено после определения стран: ' + removed + ', осталось ' + kept.length + '.'
  );
  return removed;
}

/**
 * Считает состав добавленных прокси: по странам размещения и по источникам.
 *
 * Нужен и для журнала, и для лога: по составу видно, откуда в списке та или иная
 * страна. Это ответ на вопрос «почему в списке почти всё из одной страны»: выборка
 * берётся из объединения источников и равномерна по адресам, а не «поровну по
 * странам», поэтому большой список одной страны и определяет состав.
 *
 * @param {Array<object>} fresh добавленные прокси
 * @param {Array<{url: string, found: number}>} bySource размеры источников
 * @returns {Promise<{byCountry: Object<string, number>, bySource: Array<object>}>}
 */
async function describeAddedComposition(fresh, bySource) {
  const byCountry = {};

  try {
    // Страны берём из хранилища: они определяются уже после записи списка, а
    // объекты в памяти остаются без стран.
    const ids = new Set(fresh.map((proxy) => String(proxy.id)));
    for (const proxy of await getProxies()) {
      if (!ids.has(String(proxy.id))) continue;
      const code = proxy.country || '';
      byCountry[code] = (byCountry[code] || 0) + 1;
    }
  } catch (error) {
    log.debug('background: не удалось посчитать состав добавленных прокси', error);
  }

  return { byCountry, bySource: bySource || [] };
}

/**
 * Строка состава добавленных прокси для журнала: размеры источников и страны.
 *
 * @param {Array<{url: string, found: number}>} bySource размеры источников
 * @param {Object<string, number>} byCountry страны добавленных прокси ('' - страна
 *   ещё не определена)
 * @returns {string} готовая фраза или пустая строка, если данных нет
 */
function formatSourceComposition(bySource, byCountry) {
  const parts = [];

  if (bySource && bySource.length) {
    parts.push(
      'Источники (строк): ' + bySource.map((item) => Number(item.found) || 0).join(', ') + '.'
    );
  }

  const rows = Object.entries(byCountry || {}).sort((a, b) => b[1] - a[1]);
  if (rows.length) {
    const shown = rows
      .slice(0, COMPOSITION_COUNTRIES_LIMIT)
      .map(([code, count]) => (code ? code + ' ' + count : 'без страны ' + count));
    const rest = rows.length - shown.length;
    parts.push(
      'Страны новых: ' + shown.join(', ') + (rest > 0 ? ', и ещё стран: ' + rest : '') + '.'
    );
  }

  return parts.join(' ');
}

// ---------------------------------------------------------------------------
// Определение стран прокси
// ---------------------------------------------------------------------------

/**
 * Определяет страну по IP через внешние сервисы.
 *
 * Ответы бывают двух видов: JSON (ipwho.is, api.country.is) и просто код
 * страны текстом (ipapi.co, ipinfo.io). Поддерживаются оба варианта, а также
 * код страны разной длины в ответе - берём только двухбуквенный ISO-код.
 *
 * @param {string} ip
 * @returns {Promise<string|null>}
 */
async function detectCountryByIp(ip) {
  const target = String(ip || '').trim().replace(/^\[|\]$/g, '');
  if (!target) return null;

  for (const template of GEOIP_SERVICES) {
    const url = template.replace('{ip}', encodeURIComponent(target));
    try {
      const response = await fetch(url, { cache: 'no-store' });
      if (!response.ok) continue;
      const text = (await response.text()).trim();
      if (!text) continue;

      // JSON-ответ (ipwho.is, api.country.is, freeipapi.com).
      if (text.startsWith('{')) {
        try {
          const data = JSON.parse(text);
          const raw =
            data.country_code ||
            data.countryCode ||
            (data.country && data.country.code) ||
            data.country;
          const code = String(raw || '').trim().toUpperCase();
          if (code.length === 2) return code;
        } catch (error) {
          /* пробуем следующий сервис */
        }
        continue;
      }

      // Ответ в формате CSV: ip2c.org отдаёт "1;US;USA;United States".
      if (text.includes(';')) {
        const parts = text.split(';');
        const code = String(parts[1] || '').trim().toUpperCase();
        if (String(parts[0]).trim() === '1' && code.length === 2) return code;
        continue;
      }

      // Остальные отвечают просто кодом страны текстом.
      const code = text.replace(/[^A-Za-z]/g, '').toUpperCase();
      if (code.length === 2) return code;
    } catch (error) {
      /* пробуем следующий сервис */
    }
  }

  log.debug('background: страна не определена', { ip: target });
  return null;
}

/**
 * Определяет страны для прокси, у которых они неизвестны.
 *
 * @param {{limit?: number}} [options] limit - сколько прокси обработать за один
 *   проход (0 или не задано - все). Ограничение нужно для автозапуска после
 *   импорта больших списков: остальное дозаполняется при открытии настроек
 *   или по кнопке «Определить страны».
 * @returns {Promise<{detected: number, total: number}>}
 */
async function detectCountries(options = {}) {
  const limit = Number(options.limit) > 0 ? Math.floor(Number(options.limit)) : 0;

  const proxies = await getProxies();
  if (!proxies.length) {
    log.warn('background: список прокси пуст - определение стран пропущено');
    return { detected: 0, total: 0 };
  }

  const pending = proxies.filter((proxy) => !proxy.country);
  if (!pending.length) {
    log.info('background: страна уже определена у всех прокси', { total: proxies.length });
    return { detected: 0, total: proxies.length };
  }

  const queue = (limit ? pending.slice(0, limit) : pending).slice();
  log.info('background: определение стран', { withoutCountry: pending.length, inQueue: queue.length });

  const found = new Map();
  const concurrency = 4;

  /**
   * Обрабатывает один прокси из очереди.
   * @returns {Promise<void>}
   */
  async function worker() {
    while (queue.length) {
      const proxy = queue.shift();
      if (!proxy) break;

      const country = await detectCountryByIp(proxy.host);
      if (country) {
        found.set(proxy.id, country);
        log.debug('background: страна определена', {
          proxy: `${proxy.host}:${proxy.port}`,
          country,
        });
      }
    }
  }

  const workers = [];
  for (let i = 0; i < concurrency; i += 1) {
    workers.push(worker());
  }
  await Promise.all(workers);

  // Список мог измениться, пока шли запросы, поэтому результат применяется по
  // id к свежему списку, а не записью старого массива целиком.
  const fresh = await getProxies();
  let applied = 0;
  for (const proxy of fresh) {
    if (proxy.country) continue;
    const country = found.get(proxy.id);
    if (country) {
      proxy.country = country;
      applied += 1;
    }
  }

  if (applied) await setProxies(fresh);
  log.info('background: определение стран завершено', {
    detected: applied,
    total: fresh.length,
    inQueue: queue.length,
  });

  return { detected: applied, total: fresh.length };
}

// ---------------------------------------------------------------------------
// Проверка прокси
// ---------------------------------------------------------------------------

/**
 * Проверяет один прокси.
 *
 * В Chrome MV3 нет API для per-request прокси, поэтому проверка идёт через
 * временное переключение chrome.proxy. Ключевой момент: переключение делается
 * ОДИН раз на весь прокси, а все запросы (пинг, тестовый сайт, IP-echo)
 * выполняются внутри этой одной сессии. Ранее прокси переключался на каждый
 * запрос, и из-за постоянной смены прокси половина проверок обрывалась.
 *
 * @param {object} proxy
 * @param {object} settings
 * @returns {Promise<object>}
 */
async function testProxy(proxy, settings) {
  // Медленные публичные прокси не укладываются в прежние 8 секунд.
  const timeout = Math.max(Number(settings.testTimeout) || 8000, 10000);

  const result = {
    alive: false,
    // Проверка была остановлена: результат не записывается, прокси остаётся
    // «не проверено».
    aborted: false,
    needsAuth: false,
    latency: null,
    ping: null,
    siteLatency: null,
    exitIp: null,
    exitCountry: '',
    error: null,
  };

  try {
    const session = await withProxySession(proxy, settings, async (request) => {
      // Остановку проверяем перед каждым запросом: так «Остановить» срабатывает
      // почти сразу, а не после таймаута.
      if (testAborted) return { aborted: true };

      const probe = await request(settings.testUrl, timeout);
      const outcome = { probe, site: null, exit: { exitIp: null, exitCountry: '' }, aborted: false };
      if (!probe.ok) return outcome;
      if (testAborted) return { aborted: true };

      // Оба запроса идут внутри той же сессии прокси.
      outcome.site = await request(settings.siteTestUrl || 'https://www.google.com/', timeout);
      if (testAborted) return { aborted: true };

      outcome.exit = await probeExitInfo(request, timeout, proxy);
      return outcome;
    });

    if (session && session.aborted) {
      result.aborted = true;
      return result;
    }

    const { probe, site, exit } = session;

    result.ping = probe.ok ? probe.ms : null;
    result.latency = probe.ok ? probe.ms : null;
    // 407 - прокси требует авторизацию.
    result.needsAuth = probe.status === 407;

    if (!probe.ok) {
      result.error = probe.error || (probe.status ? 'bad_status' : 'network');
      return result;
    }

    result.alive = true;
    result.siteLatency = site && site.ok ? site.ms : null;
    result.exitIp = exit.exitIp;
    result.exitCountry = exit.exitCountry;

    return result;
  } catch (error) {
    result.error = error && error.name === 'AbortError' ? 'timeout' : 'network';
    return result;
  }
}

/**
 * Определяет IP и страну выхода внутри уже открытой сессии прокси.
 *
 * Запросы идут через переданную функцию request, поэтому прокси не
 * переключается повторно; тело ответа читается там же, внутри сессии.
 *
 * @param {(url: string, timeout: number) => Promise<object>} request
 * @param {number} timeout
 * @param {object} proxy
 * @returns {Promise<{exitIp: string|null, exitCountry: string}>}
 */
async function probeExitInfo(request, timeout, proxy) {
  let exitIp = null;
  const errors = [];

  for (const url of IP_ECHO_SERVICES) {
    const response = await request(url, timeout);
    if (!response.ok) {
      errors.push(`${url}: ${response.error || 'HTTP ' + response.status}`);
      continue;
    }

    const text = String(response.text || '').trim();
    if (!text) {
      errors.push(`${url}: пустой ответ`);
      continue;
    }

    let ip = null;
    if (text.startsWith('{')) {
      try {
        const data = JSON.parse(text);
        ip = data.ip || data.query || null;
      } catch (error) {
        /* пробуем следующий сервис */
      }
    } else {
      const match = text.match(/\b\d{1,3}(?:\.\d{1,3}){3}\b/);
      if (match) ip = match[0];
    }

    if (ip) {
      exitIp = ip;
      break;
    }
  }

  if (!exitIp) {
    log.warn('background: IP выхода через прокси не определён', {
      proxy: formatProxyString(proxy),
      errors,
    });
    return { exitIp: null, exitCountry: '' };
  }

  const country = await detectCountryByIp(exitIp);
  if (!country) {
    log.warn('background: страна выхода не определена', { exitIp });
  }
  return { exitIp, exitCountry: country || '' };
}

/**
 * Открывает одну сессию прокси и выполняет внутри неё все запросы проверки.
 *
 * В MV3 нет API «прокси на один запрос», поэтому проверка идёт через временную
 * подмену PAC-скрипта браузера. Подмена минимальная: через проверяемый прокси
 * идут ТОЛЬКО хосты проверки (цель проверки, тестовый сайт, IP-echo сервисы).
 * Остальной трафик в это время работает как обычно: обычные сайты - напрямую,
 * сайты из списка - через активный прокси. Раньше здесь выставлялся
 * fixed_servers на весь браузер, из-за чего во время проверки (и после
 * аварийной выгрузки service worker) через случайный прокси шли ВСЕ сайты и
 * падали с ERR_SOCKS_CONNECTION_FAILED.
 *
 * handler получает функцию request(url, timeout), которая ходит через этот
 * прокси и сразу читает тело ответа (тело обязательно читать до восстановления
 * PAC, иначе соединение через прокси уже закрыто и response.text() падает).
 * После handler рабочий PAC возвращается. Сессии сериализуются очередью, чтобы
 * не мешать друг другу.
 *
 * @param {object} proxy
 * @param {object} settings
 * @param {(request: Function) => Promise<*>} handler
 * @returns {Promise<*>}
 */
async function withProxySession(proxy, settings, handler) {
  return withProxyLock(async () => {
    const protocol = settings.proxyProtocol;
    const activeProxy = await getActiveProxy();
    const proxiedSites = await getProxiedSites();
    const testHosts = collectTestHosts(settings);
    const keepDomains = Array.from(
      new Set(proxiedSites.map(normalizeDomain).filter(Boolean))
    );
    const keepProxyString = activeProxy ? toPacProxyString(activeProxy, protocol) : '';

    const pacData = buildTestPacScript({
      proxyString: toPacProxyString(proxy, protocol),
      testHosts,
      keepProxyString,
      keepDomains,
      keepAllTraffic: !!settings.proxyAllTraffic,
    });

    log.debug('background: сессия проверки прокси', {
      proxy: formatProxyString(proxy),
      testHosts: testHosts.length,
      keepDomains: keepDomains.length,
      keepProxy: keepProxyString || '(нет)',
    });

    await chrome.proxy.settings.set({
      value: { mode: 'pac_script', pacScript: { data: pacData } },
      scope: 'regular',
    });

    /**
     * Запрос через открытую сессию прокси.
     * @param {string} url
     * @param {number} timeout
     * @returns {Promise<{ok: boolean, status: number, text: string, ms: number, error: string}>}
     */
    const request = async (url, timeout) => {
      // Запрос отменяется и по таймауту, и кнопкой «Остановить»: подписываемся
      // на общий контроллер проверки.
      const stopSignal = testAbortController ? testAbortController.signal : null;
      const controller = new AbortController();
      const onStop = () => controller.abort();
      if (stopSignal) {
        if (stopSignal.aborted) {
          controller.abort();
        } else {
          stopSignal.addEventListener('abort', onStop, { once: true });
        }
      }
      const timer = setTimeout(() => controller.abort(), timeout);
      const started = Date.now();
      try {
        const response = await fetch(url, {
          method: 'GET',
          cache: 'no-store',
          signal: controller.signal,
          redirect: 'follow',
        });
        const text = await response.text();
        return {
          ok: response.ok,
          status: response.status,
          text,
          ms: Date.now() - started,
          error: '',
        };
      } catch (error) {
        return {
          ok: false,
          status: 0,
          text: '',
          ms: Date.now() - started,
          error: String((error && error.name) || error),
        };
      } finally {
        clearTimeout(timer);
        if (stopSignal) stopSignal.removeEventListener('abort', onStop);
      }
    };

    try {
      return await handler(request);
    } finally {
      // Возвращаем рабочий PAC-скрипт после всех запросов сессии.
      await applyProxySettings();
    }
  });
}

// Простая очередь, чтобы не переключать прокси параллельно.
let proxyLock = Promise.resolve();

/**
 * Сериализует доступ к chrome.proxy.settings.
 * @param {Function} task
 * @returns {Promise<*>}
 */
function withProxyLock(task) {
  const run = proxyLock.then(task, task);
  proxyLock = run.catch(() => {});
  return run;
}

/**
 * Порядок прокси после проверки: сначала рабочие по возрастанию пинга, затем
 * требующие авторизации, затем непроверенные и недоступные.
 *
 * @param {Array<object>} proxies
 * @param {Object<string, object>} stats
 * @returns {Array<object>}
 */
function sortProxiesByPing(proxies, stats) {
  const rank = (proxy) => {
    const stat = stats[proxy.id] || {};
    if (stat.alive) return 0;
    if (stat.checkedAt && stat.needsAuth) return 1;
    if (stat.checkedAt) return 3;
    return 2;
  };
  const time = (proxy) => {
    const stat = stats[proxy.id] || {};
    const value = stat.ping != null ? stat.ping : stat.latency;
    return value != null ? value : Infinity;
  };

  return proxies.slice().sort((a, b) => {
    const ra = rank(a);
    const rb = rank(b);
    if (ra !== rb) return ra - rb;
    const ta = time(a);
    const tb = time(b);
    if (ta !== tb) return ta - tb;
    return formatProxyString(a).localeCompare(formatProxyString(b));
  });
}

/**
 * Запускает проверку прокси из списка с ограничением параллелизма.
 *
 * @param {Array<string>} [ids] id прокси, которые нужно проверить. Если список
 *   не передан или пуст, проверяется весь список: так работает фоновая
 *   проверка по расписанию и кнопка без выбранных чекбоксов.
 * @param {{auto?: boolean}} [options] auto - проверка запущена автоматически
 *   (по расписанию): к ней применяются настройки удаления недоступных и
 *   дозаливки новых прокси.
 * @returns {Promise<object>} итог проверки из runProxyTest
 */
async function testAllProxies(ids, options = {}) {
  if (testInProgress) {
    log.warn('background: проверка уже идёт - повторный запуск пропущен');
    // Запуск по расписанию пропущен - это тоже событие, и оно видно в журнале.
    // Иначе непонятно, работал авто-тест или нет.
    if (options.auto) {
      await addJournal('skip', 'Авто-тест пропущен', 'Предыдущая проверка ещё идёт.');
    }
    return { started: false, running: true };
  }

  testInProgress = true;
  // Контроллер создаётся на каждый запуск: по нему «Остановить» обрывает
  // начатые запросы.
  testAbortController = new AbortController();

  try {
    return await runProxyTest(ids, options);
  } finally {
    testInProgress = false;
    testAborted = false;
    testAbortController = null;
    checkingIds.clear();
    queuedIds.clear();
    checkProgress.running = false;
    // Прогон дошёл до конца, и неважно, остановили его вручную или нет: отметка
    // о нём больше не нужна. Следующий запуск service worker не должен считать
    // такой прогон прерванным.
    await setValue(AUTOTEST_RUN_KEY, null);
  }
}

// Разбор прерванного прогона выполняется один раз за запуск service worker,
// поэтому результат запоминается здесь.
let interruptedRunCleanup = null;

/**
 * Возвращает разбор прерванного авто-теста.
 *
 * Идемпотентна в пределах одного запуска service worker: параллельные вызовы
 * (инициализация и старт проверки) ждут один и тот же результат, поэтому список
 * прокси не читается и не пишется двумя разборами сразу.
 *
 * @returns {Promise<void>}
 */
function cleanupInterruptedAutoTest() {
  if (!interruptedRunCleanup) {
    interruptedRunCleanup = finishInterruptedAutoTest().catch((error) => {
      log.warn('background: разбор прерванного авто-теста', error);
    });
  }
  return interruptedRunCleanup;
}

/**
 * Разбирает следы прогона, который не дошёл до конца.
 *
 * Проверка сначала пополняет список прокси из источников, а потом прогоняет его
 * целиком. Если прогон обрывается (Chrome выгрузил service worker, браузер
 * закрыли, машина ушла в сон), остаются два следа.
 *
 * Первый - прокси без результата: в таблице они висят со статусом «не проверено»
 * до следующего удачного прогона, и отметка о прогоне (AUTOTEST_RUN_KEY)
 * позволяет их найти и удалить (у авто-теста).
 *
 * Второй - результаты, которые прогон всё-таки успел записать. Доверия они не
 * заслуживают: связь могла пропасть прямо во время проверки, а машина - уйти в
 * сон. Подтверждённые рабочие прокси остаются, остальные записи отбрасываются:
 * иначе отказ из сломанного прогона складывался бы с отказом следующего, и
 * рабочий прокси удалялся бы после двух провалов подряд, из которых первый
 * фиктивный.
 *
 * @returns {Promise<void>}
 */
async function finishInterruptedAutoTest() {
  const run = await getValue(AUTOTEST_RUN_KEY, null);
  if (!run) return;

  // Отметка относится к прошлому прогону: дальше её быть не должно.
  await setValue(AUTOTEST_RUN_KEY, null);

  const settings = await getSettings();
  const proxies = await getProxies();
  const stats = await getProxyStats();
  const ids = new Set((run.ids || []).map(String));
  const startedAt = Number(run.startedAt) || 0;

  // Если отметка не успела получить список прокси (прогон оборвался в самом
  // начале), прогоном считаем весь список: непроверенные и есть его след.
  const inRun = ids.size ? proxies.filter((proxy) => ids.has(String(proxy.id))) : proxies;

  // Прокси без результата и прокси с результатом прогона считаются по одной и
  // той же статистике - до того, как записи будут отброшены.
  const untested = inRun.filter((proxy) => {
    const stat = stats[proxy.id];
    return !stat || !stat.checkedAt;
  });

  const discarded = startedAt
    ? inRun.filter((proxy) => {
        const stat = stats[proxy.id];
        if (!stat || !stat.checkedAt || Number(stat.checkedAt) < startedAt) return false;
        return !(stat.alive && stat.siteLatency != null);
      })
    : [];

  if (discarded.length) {
    const nextStats = { ...stats };
    for (const proxy of discarded) delete nextStats[proxy.id];
    await setProxyStats(nextStats);
    log.info('background: результаты прерванного авто-теста отброшены', {
      discarded: discarded.length,
      total: proxies.length,
    });
  }

  // Дальше - только авто-тест: прокси без результата появились у него из-за
  // дозаливки перед прогоном. Ручная проверка идёт по выбранным прокси, и
  // трогать список за пользователя там нельзя.
  if (!run.auto) return;

  const testedCount = inRun.length - untested.length;
  const parts = [
    'Прошлый прогон по расписанию не дошёл до конца: service worker не пережил проверку.',
  ];
  if (startedAt) parts.push('Прогон начат ' + formatClockTime(startedAt) + '.');
  if (inRun.length) {
    parts.push(
      'Прокси в том прогоне: ' +
        inRun.length +
        ', результат получили ' +
        testedCount +
        ', осталось без результата ' +
        untested.length +
        '.'
    );
  }
  if (discarded.length) {
    parts.push(
      'Результаты прогона отброшены: ' +
        discarded.length +
        ' - эти прокси проверятся заново, подтверждённые рабочие оставлены.'
    );
  }

  const deleteUntested = settings.autoTestDeleteUntested !== false;
  let removed = 0;
  if (untested.length && deleteUntested) {
    const removeIds = new Set(untested.map((proxy) => String(proxy.id)));
    const kept = proxies.filter((proxy) => !removeIds.has(String(proxy.id)));
    await setProxies(kept);
    removed = proxies.length - kept.length;
    log.info('background: удалены непроверенные прокси прерванного авто-теста', {
      removed,
      left: kept.length,
    });
    if (removed) {
      await selectBestProxy();
      await applyProxySettings();
    }
  }

  if (removed) {
    parts.push('Удалено непроверенных: ' + removed + '.');
  } else if (untested.length) {
    parts.push('Непроверенные прокси оставлены: удаление непроверенных выключено.');
  } else {
    parts.push('Прокси без результата не осталось.');
  }

  await addJournal('warn', 'Авто-тест прерван', parts.join(' '));

  if (removed) {
    await addJournal(
      'remove',
      'Удалены непроверенные прокси',
      'Остались без результата после прерванного авто-теста: ' + journalProxyList(untested) + '.'
    );
  }
}

/**
 * Когда запись «Хранилища рабочих» трогали в последний раз.
 *
 * Берётся самая поздняя из известных дат: последняя проверка, удача, неудача. У
 * записей старых версий отдельных полей может не быть.
 *
 * @param {object} entry
 * @returns {number} отметка времени, мс (0 - данных нет)
 */
function archiveTouchTime(entry) {
  return (
    Number(entry.lastCheckAt) || Number(entry.lastOkAt) || Number(entry.lastFailAt) || 0
  );
}

/**
 * Ограничивает размер «Хранилища рабочих».
 *
 * При переполнении вытесняются записи, которые дольше всех не проверялись: свежие
 * адреса полезнее старых. Учитывается последнее касание вообще - удача или
 * неудача, - а не только удача: иначе записи про прокси, которые так и не
 * заработали, уходили бы из хранилища первыми, а они как раз и нужны, чтобы не
 * тестировать один и тот же мусор повторно.
 *
 * @param {Object<string, object>} archive
 * @returns {Object<string, object>} хранилище в пределах лимита
 */
function trimArchive(archive) {
  const keys = Object.keys(archive);
  if (keys.length <= ARCHIVE_MAX_ENTRIES) return archive;

  const result = {};
  for (const entry of keys
    .map((key) => archive[key])
    .sort((a, b) => archiveTouchTime(b) - archiveTouchTime(a))
    .slice(0, ARCHIVE_MAX_ENTRIES)) {
    result[`${entry.host}:${entry.port}`] = entry;
  }

  log.info('background: хранилище прокси обрезано по размеру', {
    was: keys.length,
    left: ARCHIVE_MAX_ENTRIES,
  });
  return result;
}

/**
 * Пополняет «Хранилище прокси» прокси, которые подтвердили работу в прогоне.
 *
 * Хранилище живёт отдельно от списка и авто-тестом не чистится: смысл в том,
 * чтобы удалённый из списка рабочий прокси можно было вернуть и проверить снова.
 * Ключ - адрес host:port, поэтому у записи копятся число удачных проверок
 * (okCount), время первой удачной (firstOkAt) и последней (lastOkAt).
 *
 * @param {Array<{proxy: object, result: object}>} found
 * @returns {Promise<void>}
 */
async function rememberWorkingProxies(found) {
  if (!found.length) return;
  try {
    const archive = await getProxyArchive();
    const now = Date.now();

    for (const item of found) {
      const key = `${item.proxy.host}:${item.proxy.port}`;
      const prev = archive[key] || {};
      archive[key] = {
        host: item.proxy.host,
        port: item.proxy.port,
        country: item.proxy.country || prev.country || '',
        exitCountry: item.result.exitCountry || prev.exitCountry || '',
        ping: item.result.ping != null ? item.result.ping : prev.ping != null ? prev.ping : null,
        siteLatency:
          item.result.siteLatency != null
            ? item.result.siteLatency
            : prev.siteLatency != null
              ? prev.siteLatency
              : null,
        firstOkAt: Number(prev.firstOkAt) || now,
        lastOkAt: now,
        lastCheckAt: now,
        okCount: (Number(prev.okCount) || 0) + 1,
      };
    }

    const result = trimArchive(archive);
    await setProxyArchive(result);
    log.debug('background: хранилище прокси обновлено', {
      added: found.length,
      total: Object.keys(result).length,
    });
  } catch (error) {
    log.warn('background: не удалось обновить хранилище прокси', error);
  }
}

/**
 * Сама проверка прокси: гоняет очередь через временную подмену PAC и пишет
 * статистику. Вызывается только через testAllProxies.
 *
 * @param {Array<string>} [ids]
 * @param {{auto?: boolean}} [options] auto - проверка запущена по расписанию
 * @returns {Promise<object>}
 */
async function runProxyTest(ids, options = {}) {
  // Прошлый прогон мог не дойти до конца: сначала разбираемся с его следами,
  // иначе непроверенные прокси так и останутся в списке.
  await cleanupInterruptedAutoTest();

  const settings = await getSettings();
  const isAutoRun = !!options.auto;
  const runStartedAt = Date.now();

  // Отметка о прогоне. Её увидит следующий запуск service worker, если этот
  // прогон прервётся. Список прокси дописывается ниже, когда он прочитан.
  await setValue(AUTOTEST_RUN_KEY, { auto: isAutoRun, startedAt: runStartedAt, ids: [] });

  // Запуск по расписанию мог опоздать: машина спала, была выключена или пропадал
  // интернет. Об этом сообщаем отдельной записью - иначе поздний запуск выглядел
  // бы как обычный.
  if (isAutoRun) await journalAutoTestDelay();

  // Связь проверяется до всего остального. Без интернета проверка прокси
  // бессмысленна, а её результат опасен: прогон пометил бы ограниченными и
  // удалил все прокси сразу - именно это и случилось ночью, когда ноутбук
  // ушёл в сон.
  const network = await checkNetwork(settings);
  const networkOk = network.ok;

  if (!networkOk) {
    log.warn('background: проверка прокси без связи с интернетом', { auto: isAutoRun });
    await addJournal(
      'skip',
      isAutoRun ? 'Авто-тест пропущен' : 'Проверка без интернета',
      'Интернет недоступен: проверка связи заняла ' +
        formatDuration(network.ms) +
        ' и перебрала ' +
        network.tried +
        ' адрес(а)' +
        (network.url ? ' (первый: ' + network.url + ')' : '') +
        '. Результат проверки прокси не записан, удаление отменено.'
    );
    if (isAutoRun) return { started: false, skipped: true, checked: 0, total: 0 };
  }

  // Авто-тест: сначала дозаливка из источников (функция прежней «Автозагрузки
  // по таймеру»), затем проверка всего списка - свежие прокси проверяются в
  // этом же запуске (функция прежней «Проверять после загрузки»).
  if (isAutoRun && settings.autoTestRefill && !(Array.isArray(ids) && ids.length)) {
    try {
      await refillProxiesFromSources(settings);
    } catch (error) {
      log.warn('background: дозаливка прокси перед авто-тестом не удалась', error);
    }
  }

  const all = await getProxies();
  const onlyIds = Array.isArray(ids) && ids.length ? new Set(ids.map(String)) : null;
  const proxies = onlyIds ? all.filter((proxy) => onlyIds.has(String(proxy.id))) : all;

  if (!proxies.length) {
    log.warn('background: список прокси пуст - проверка пропущена');
    await addJournal(
      'skip',
      isAutoRun ? 'Авто-тест пропущен' : 'Проверка пропущена',
      'Список прокси пуст: проверять нечего.'
    );
    return { started: true, checked: 0, total: 0 };
  }

  // Начало прогона по расписанию тоже попадает в журнал. Пара «начат» и
  // «завершён» показывает, что проверка дошла до конца: если начало есть, а итога
  // нет, прогон прервался (например расширение перезагрузили и service worker
  // перезапустился прямо во время проверки).
  if (isAutoRun) {
    await addJournal(
      'test',
      'Авто-тест начат',
      'Прокси в списке: ' + proxies.length + '. Связь: есть (' + formatDuration(network.ms) + ').'
    );
  }

  // Отметка о прогоне дополняется списком прокси: по нему следующий запуск
  // service worker поймёт, у кого результат так и не появился.
  await setValue(AUTOTEST_RUN_KEY, {
    auto: isAutoRun,
    startedAt: runStartedAt,
    ids: proxies.map((proxy) => String(proxy.id)),
  });

  // Тестовый URL берём из выбранной цели, если она задана.
  const targetUrl = TEST_TARGETS[settings.testTarget] || settings.testUrl;
  const effectiveSettings = { ...settings, testUrl: targetUrl };

  log.info('background: старт проверки прокси', {
    count: proxies.length,
    onlySelected: !!onlyIds,
    auto: isAutoRun,
    concurrency: settings.testConcurrency,
    timeout: settings.testTimeout,
    target: settings.testTarget,
    url: targetUrl,
  });

  checkProgress = {
    total: proxies.length,
    done: 0,
    running: true,
    alive: 0,
    limited: 0,
    dead: 0,
  };
  testAborted = false;
  checkingIds.clear();
  queuedIds.clear();
  for (const proxy of proxies) {
    queuedIds.add(proxy.id);
  }

  const stats = await getProxyStats();
  const queue = proxies.slice();
  // Итоги этого прогона для «Хранилища рабочих»: подтвердившие работу и те, что
  // её не подтвердили.
  const workingFound = [];
  const failedFound = [];
  const concurrency = Math.max(1, Math.min(settings.testConcurrency || 4, 16));

  /**
   * Обрабатывает один прокси из очереди.
   * @returns {Promise<void>}
   */
  async function worker() {
    while (queue.length) {
      if (testAborted) break;

      const proxy = queue.shift();
      if (!proxy) break;

      // Помечаем прокси как проверяемый - UI покажет «проверка…».
      queuedIds.delete(proxy.id);
      checkingIds.add(proxy.id);

      const result = await testProxy(proxy, effectiveSettings);

      // Проверка остановлена: недопроверенный прокси не получает ни статуса,
      // ни места в статистике - он останется «не проверено».
      if (result.aborted) {
        checkingIds.delete(proxy.id);
        log.debug('background: проверка прервана на прокси', formatProxyString(proxy));
        break;
      }

      // Прежний вердикт и счётчик провалов: одна неудачная проверка не должна
      // переводить рабочий прокси в «ограниченные».
      const prevStat = stats[proxy.id] || {};
      const nowWorks = !!(result.alive && result.siteLatency != null);
      const everWorked =
        nowWorks || prevStat.everWorked === true || !!(prevStat.alive && prevStat.siteLatency != null);
      const failStreak = nowWorks ? 0 : (Number(prevStat.failStreak) || 0) + 1;

      if (!nowWorks && everWorked && failStreak < FAIL_RUNS_BEFORE_VERDICT) {
        // Прокси уже работал раньше, а сейчас не ответил - это ещё не вердикт:
        // состояние оставляем прежним и только копим счётчик провалов.
        stats[proxy.id] = {
          ...prevStat,
          everWorked: true,
          failStreak,
          error: result.error,
          checkedAt: Date.now(),
        };
      } else {
        stats[proxy.id] = {
          alive: result.alive,
          // Явный признак «ограничен»: прокси не открыл тестовый сайт. Отдельный
          // флаг, а не «alive + пустой siteLatency»: при проверке по событию пинг
          // не проверяется, поэтому живость прокси может быть неизвестна.
          limited: result.alive && result.siteLatency == null,
          needsAuth: result.needsAuth,
          latency: result.latency,
          ping: result.ping,
          siteLatency: result.siteLatency,
          exitIp: result.exitIp,
          exitCountry: result.exitCountry,
          error: result.error,
          everWorked,
          failStreak,
          checkedAt: Date.now(),
        };
      }
      // Итоги проверки запоминаем для «Хранилища рабочих»: запись оттуда не
      // пропадает, даже если сам прокси позже будет удалён из списка.
      if (result.alive && result.siteLatency != null) {
        workingFound.push({ proxy, result });
      } else {
        // Отказ тоже важен: по нему видно, что прокси, который работал раньше,
        // больше не тянет - например после возврата из хранилища.
        failedFound.push({ proxy, result });
      }

      checkingIds.delete(proxy.id);
      checkProgress.done += 1;
      // Счётчики для строки прогресса. Рабочим считается только полностью
      // рабочий прокси - отвечающий и с открывшимся тестовым сайтом; «ограниченный»
      // идёт отдельным счётчиком, иначе он попадал в число рабочих.
      if (result.alive && result.siteLatency != null) {
        checkProgress.alive += 1;
      } else if (result.alive) {
        checkProgress.limited += 1;
      } else {
        checkProgress.dead += 1;
      }
      log.debug('background: прокси проверен', {
        proxy: formatProxyString(proxy),
        alive: result.alive,
        needsAuth: result.needsAuth,
        ping: result.ping,
        latency: result.latency,
        siteLatency: result.siteLatency,
        exitCountry: result.exitCountry,
        error: result.error,
        progress: `${checkProgress.done}/${checkProgress.total}`,
      });
      await setProxyStats(stats);
    }
  }

  const workers = [];
  for (let i = 0; i < concurrency; i += 1) {
    workers.push(worker());
  }
  await Promise.all(workers);

  // Рабочие прокси попадают в отдельное хранилище: оттуда их можно вернуть в
  // список и проверить снова, даже если авто-тест удалил их как нерабочие.
  await rememberWorkingProxies(workingFound);
  // Отказы тоже учитываются: у записи хранилища копится число неудачных проверок.
  await rememberFailedProxies(failedFound);

  // Удаляем нерабочие, если включено. Список читаем заново: пока шла проверка,
  // его могли изменить. Прокси, которых в проверке не было (проверяли
  // выбранные чекбоксами), не удаляются.
  //
  // deleteDead: «Удалять нерабочие» действует на любую проверку, а отдельная
  // галочка «Удалять недоступные при авто-тесте» - только на запуск по
  // расписанию.
  const deleteDead = settings.autoDeleteDead || (isAutoRun && settings.autoTestDeleteDead);
  // «Удалять ограниченные»: прокси, который не открыл тестовый сайт (работать
  // через него нельзя). По умолчанию включено, чтобы список не забивался.
  const deleteLimited = !!settings.autoTestDeleteLimited;
  // Сколько прокси удалено в этом прогоне: число попадает в итог журнала.
  let removedCount = 0;
  if ((deleteDead || deleteLimited) && !testAborted) {
    const fresh = await getProxies();

    // Прокси делятся на две группы, и правила для них разные.
    //
    // Недоступные (прокси не отвечает вообще) удаляются без сожаления и без
    // ограничения количества: работать через них нельзя, в списке они только
    // мешают. Исключение - прокси, которые раньше работали: их отказ проверяется
    // ещё раз по связи перед удалением (см. ниже).
    //
    // «Ограниченные» - те, что раньше работали, а сейчас не открыли тестовый
    // сайт. Одной неудачной проверки мало: нужна серия провалов (failStreak), а
    // массовая пометка таких прокси отменяется целиком - почти всегда это сбой
    // на нашей стороне (пропала связь, упал тестовый сайт).
    const doomedDead = [];
    const doomedLimited = [];

    for (const proxy of fresh) {
      if (onlyIds && !onlyIds.has(String(proxy.id))) continue;
      const stat = stats[proxy.id];
      if (!stat) continue;

      if (!isLimitedProxyStat(stat) && !stat.alive) {
        if (deleteDead) doomedDead.push(proxy);
        continue;
      }

      if (isLimitedProxyStat(stat) && deleteLimited) {
        if ((Number(stat.failStreak) || 0) >= FAIL_RUNS_BEFORE_DELETE) doomedLimited.push(proxy);
      }
    }

    const allowedLimited = Math.max(
      MIN_DELETE_PER_RUN,
      Math.ceil(fresh.length * MAX_DELETE_SHARE_PER_RUN)
    );

    // Прокси, которые раньше работали, а сейчас записаны недоступными. Их
    // удаление дополнительно проверяется по связи: она могла пропасть уже во
    // время проверки (машина ушла в сон, оборвался интернет), и тогда отказы
    // прокси ничего не доказывают. Прокси, которые не работали ни разу,
    // удаляются как обычно: они и так мусор.
    const workedDead = doomedDead.filter((proxy) => {
      const stat = stats[proxy.id];
      return !!stat && stat.everWorked === true;
    });

    let networkNow = networkOk;
    if (networkNow && deleteDead && workedDead.length) {
      networkNow = (await checkNetwork(settings)).ok;
      if (!networkNow) {
        log.warn('background: связь пропала во время проверки прокси', {
          workedDead: workedDead.length,
          doomedDead: doomedDead.length,
        });
      }
    }

    let removeDead = doomedDead;
    let removeLimited = doomedLimited;
    let cancelTitle = '';
    let cancelText = '';

    if (!networkOk) {
      // Связи нет - отказ прокси ничего не доказывает, поэтому в этом прогоне не
      // удаляется ничего (см. проверку связи выше).
      removeDead = [];
      removeLimited = [];
      cancelTitle = 'Удаление прокси отменено';
      cancelText =
        'Проверка шла без интернета: ' +
        (doomedDead.length + doomedLimited.length) +
        ' прокси не удалены.';
    } else if (!networkNow) {
      // Проверка началась со связью, а закончилась без неё: рабочие прокси,
      // записанные недоступными, оставляем - их отказ был измерен уже без сети.
      const workedIds = new Set(workedDead.map((proxy) => proxy.id));
      removeDead = doomedDead.filter((proxy) => !workedIds.has(proxy.id));
      cancelTitle = 'Удаление рабочих прокси отменено';
      cancelText =
        'Связь пропала во время проверки: ' +
        workedDead.length +
        ' прокси, которые работали раньше, оставлены. Удалено недоступных: ' +
        removeDead.length +
        '.';
    } else if (doomedLimited.length > allowedLimited) {
      // Недоступные прокси удаляются как обычно: они мёртвые и в списке не
      // нужны. А рабочие прокси, которых проверка разом записала в ограниченные,
      // остаются: такое поведение почти всегда означает проблему со связью.
      removeLimited = [];
      cancelTitle = 'Удаление рабочих прокси отменено';
      cancelText =
        'Под удаление попадало ' +
        doomedLimited.length +
        ' рабочих прокси из ' +
        fresh.length +
        ', а за один прогон разрешено не больше ' +
        allowedLimited +
        '. Недоступные прокси при этом удалены: ' +
        removeDead.length +
        '.';
    }

    const removed = [...removeDead, ...removeLimited];
    removedCount = removed.length;
    if (removed.length) {
      const removedIds = new Set(removed.map((proxy) => proxy.id));
      await setProxies(fresh.filter((proxy) => !removedIds.has(proxy.id)));
      log.info('background: удалено прокси', {
        total: removed.length,
        limited: removeLimited.length,
        dead: removeDead.length,
      });

      // Недоступные прокси в журнал не пишутся: их заведомо много, а решения по
      // ним не принимается. Пишутся те, что были рабочими.
      if (removeLimited.length) {
        await addJournal(
          'remove',
          'Удалены ограниченные прокси',
          'Не открыли тестовый сайт ' +
            FAIL_RUNS_BEFORE_DELETE +
            ' проверки подряд: ' +
            journalProxyList(removeLimited) +
            '.' +
            (removeDead.length
              ? ' Кроме них удалено недоступных: ' + removeDead.length + '.'
              : '')
        );
      }
    }

    if (cancelText) {
      log.warn('background: удаление прокси отменено', {
        title: cancelTitle,
        text: cancelText,
      });
      await addJournal('warn', cancelTitle, cancelText);
    }
  }

  // Сразу упорядочиваем список по пингу: самый быстрый рабочий прокси
  // оказывается первым, и в настройках он виден сверху без ручной сортировки.
  const ordered = sortProxiesByPing(await getProxies(), stats);
  await setProxies(ordered);
  log.info('background: список отсортирован по пингу', { count: ordered.length });

  // Фильтр по стране выхода применяется только сейчас: до проверки страна
  // выхода неизвестна.
  if (
    !testAborted &&
    settings.countryFilterAuto &&
    settings.countryFilterMode !== 'off' &&
    settings.countryFilterBase === 'exit'
  ) {
    const before = ordered.length;
    const kept = ordered.filter((proxy) =>
      passesCountryFilter(proxy, settings, stats[proxy.id])
    );
    if (kept.length !== before) {
      await setProxies(kept);
      log.info('background: фильтр по стране выхода удалил прокси', before - kept.length);
      await addJournal(
        'remove',
        'Фильтр стран удалил прокси',
        'Удалено при проверке (фильтр по стране выхода): ' + (before - kept.length) + '.'
      );
    }
  }

  const aborted = testAborted;
  const aliveCount = Object.values(stats).filter((s) => s && s.alive).length;
  log.info('background: проверка завершена', {
    alive: aliveCount,
    total: proxies.length,
    checked: checkProgress.done,
    aborted,
  });

  // Итоги применяем в любом случае: активный прокси и PAC должны вернуться в
  // рабочее состояние даже после остановки.
  await selectBestProxy();
  await applyProxySettings();

  // Итог прогона пишется в журнал всегда. Без этой записи успешный авто-тест
  // ничем себя не проявляет: он ничего не удаляет и не меняет прокси, поэтому по
  // журналу нельзя понять, работает расписание или нет.
  const finishedAt = Date.now();
  // Итог считаем по ходу проверки, а не по оставшемуся списку: недоступные
  // прокси к этому моменту уже удалены, поэтому в прежнем варианте строка
  // читалась как «недоступно 0, удалено 27» - цифры не сходились, и было
  // непонятно, куда делись прокси.
  const summary = {
    working: checkProgress.alive,
    limited: checkProgress.limited,
    dead: checkProgress.dead,
  };

  const activeNow = await getActiveProxy();
  await addJournal(
    'test',
    isAutoRun ? 'Авто-тест завершён' : 'Проверка прокси завершена',
    [
      'Проверено ' +
        checkProgress.done +
        ' из ' +
        proxies.length +
        ': работает ' +
        summary.working +
        ', ограничено ' +
        summary.limited +
        ', недоступно ' +
        summary.dead,
      removedCount ? 'Удалено: ' + removedCount : '',
      'Связь: есть (' + formatDuration(network.ms) + ')',
      'Активный прокси: ' + (activeNow ? formatProxyString(activeNow) : 'нет'),
      'Заняло ' + formatDuration(finishedAt - runStartedAt),
      aborted ? 'Прогон остановлен' : '',
    ]
      .filter(Boolean)
      .join('. ') + '.'
  );

  return { started: true, aborted, checked: checkProgress.done, total: proxies.length };
}

/**
 * Дозаливка списка прокси из источников.
 *
 * Выполняет роль прежней «Автозагрузки по таймеру»: запускается в начале
 * авто-теста, чтобы список был наполнен до проверки. Настройки берутся из
 * раздела «Свой прокси»: источники (URL-ы), лимит прокси и фильтр стран.
 *
 * Дозаливка идёт, пока рабочих прокси меньше лимита: нерабочие и непроверенные
 * лимит не занимают - иначе список, забитый мусором, перекрывал бы добор. Без
 * лимита (0) ориентира по рабочим нет, поэтому добираем лишь при полностью
 * пустом списке (или когда рабочих прокси не осталось совсем).
 *
 * Отдельный случай - список упёрся в предел по строкам (двойной лимит), а
 * рабочих прокси в нём нет: место освобождают непроверенные прокси
 * (см. dropUntestedProxies), иначе дозаливка ничего не добавит.
 *
 * @param {object} settings
 * @returns {Promise<void>}
 */
async function refillProxiesFromSources(settings) {
  const sources = await getProxySources();
  if (!sources.length) {
    log.debug('background: дозаливка пропущена - источники не заданы');
    return;
  }

  const proxies = await getProxies();
  const limit = Math.max(0, parseInt(settings.sourcesLimit, 10) || 0);

  // Лимит - это число РАБОЧИХ прокси, а не строк в списке. Поэтому дозаливка
  // нужна, пока рабочих прокси меньше лимита: нерабочие и непроверенные в лимит
  // не считаются, иначе список, забитый мусором, навсегда перекрыл бы дозаливку.
  // При нулевом лимите ориентира по рабочим нет, поэтому повод прежний: список
  // пуст или рабочих не осталось совсем.
  const stats = await getProxyStats();
  const working = countWorkingProxies(proxies, stats);

  const needMore = limit > 0 ? working < limit : proxies.length === 0;
  if (!needMore && working > 0) return;

  // Общий размер списка тоже ограничен (см. fetchProxySources): если он уже
  // упёрся в предел, а рабочих прокси в нём нет, дозаливка ничего не добавит -
  // место освобождают непроверенные прокси.
  const atTotalCap = limit > 0 && proxies.length >= limit * 2;
  if (atTotalCap && !working && settings.autoTestDeleteUntested !== false) {
    const freed = await dropUntestedProxies(proxies, stats, 'дозаливка из источников');
    if (!freed) {
      // Непроверенных нет: список занят проверенными, но нерабочими прокси.
      // Их удалит сама проверка, если включено удаление недоступных.
      log.info('background: дозаливка пропущена - места в списке нет', {
        current: proxies.length,
        limit,
      });
      return;
    }
  }

  log.info('background: дозаливка прокси из источников', {
    current: proxies.length,
    working,
    limit,
    sources: sources.length,
  });
  await fetchProxySources();
}

/**
 * Отмечает в «Хранилище прокси» неудачные проверки.
 *
 * Записи для прокси, которые не работали ни разу, не создаются: хранилище - это
 * список тех, что когда-то работали. Но если адрес оттуда вернули в список (или
 * он просто попал в прогон снова) и проверка его не подтвердила, отказ
 * запоминается. По счётчику неудач видно, что адрес уже не тот, а по датам -
 * когда он перестал работать.
 *
 * @param {Array<{proxy: object, result: object}>} failed
 * @returns {Promise<void>}
 */
async function rememberFailedProxies(failed) {
  if (!failed.length) return;
  try {
    const archive = await getProxyArchive();
    const now = Date.now();
    let changed = false;
    let added = 0;

    for (const item of failed) {
      const key = `${item.proxy.host}:${item.proxy.port}`;
      const prev = archive[key];
      // Для адреса, который не работал ни разу, запись создаётся: именно по таким
      // записям дозаливка понимает, что из источника этот прокси брать не надо.
      if (!prev) added += 1;

      const base = prev || {
        host: item.proxy.host,
        port: item.proxy.port,
        country: item.proxy.country || '',
        exitCountry: '',
        ping: null,
        siteLatency: null,
        firstOkAt: 0,
        lastOkAt: 0,
        okCount: 0,
        failCount: 0,
      };

      archive[key] = {
        ...base,
        failCount: (Number(base.failCount) || 0) + 1,
        lastFailAt: now,
        lastFailError: String(
          item.result.error || (item.result.needsAuth ? 'auth' : 'site_not_opened')
        ),
        lastCheckAt: now,
      };
      changed = true;
    }

    if (changed) {
      const result = trimArchive(archive);
      await setProxyArchive(result);
      log.debug('background: в хранилище отмечены неудачные проверки', {
        checked: failed.length,
        added,
        total: Object.keys(result).length,
      });
    }
  } catch (error) {
    log.warn('background: не удалось отметить неудачные проверки', error);
  }
}

/**
 * Считает полностью рабочие прокси: отвечают и открывают тестовый сайт.
 *
 * Число нужно лимиту прокси: он задаёт, сколько РАБОЧИХ прокси держать, а не
 * сколько строк в списке.
 *
 * @param {Array<object>} proxies
 * @param {Object<string, object>} stats
 * @returns {number}
 */
function countWorkingProxies(proxies, stats) {
  return (proxies || []).filter((proxy) => {
    const stat = stats[proxy.id];
    return stat && stat.alive && stat.siteLatency != null && !stat.limited;
  }).length;
}

/**
 * Освобождает место в списке: удаляет прокси без результата проверки.
 *
 * Нужна дозаливке. Если список занят до лимита, а рабочих прокси в нём нет,
 * добавлять новые некуда - список остаётся набором непроверенных строк, и так
 * продолжается до тех пор, пока хотя бы один прогон не дойдёт до конца.
 * Непроверенные прокси здесь и есть тот мусор, который занимает место: рабочие
 * не трогаются, а адреса, которые когда-либо работали, остаются в «Хранилище
 * рабочих».
 *
 * @param {Array<object>} proxies текущий список
 * @param {Object<string, object>} stats статистика проверок
 * @param {string} reason причина удаления (для лога и журнала)
 * @returns {Promise<number>} сколько прокси удалено
 */
async function dropUntestedProxies(proxies, stats, reason) {
  const untested = proxies.filter((proxy) => {
    const stat = stats[proxy.id];
    return !stat || !stat.checkedAt;
  });
  if (!untested.length) return 0;

  const removeIds = new Set(untested.map((proxy) => proxy.id));
  const kept = proxies.filter((proxy) => !removeIds.has(proxy.id));
  await setProxies(kept);
  log.info('background: удалены непроверенные прокси', {
    removed: untested.length,
    left: kept.length,
    reason,
  });

  // Удаление видно в журнале: список может опустеть до нуля, и без записи это
  // выглядело бы как потеря прокси.
  await addJournal(
    'remove',
    'Удалены непроверенные прокси',
    'Освобождено место под новые прокси: удалено ' + untested.length + ', осталось ' + kept.length + '.'
  );
  return untested.length;
}

/**
 * Выбирает рабочий прокси и делает его активным.
 *
 * Правила по порядку:
 *  1. ручной выбор пользователя (кнопка «Использовать» в настройках или клик по
 *     прокси в попапе) не перебивается, пока прокси есть в списке и не признан
 *     недоступным последней проверкой;
 *  2. активный прокси, который продолжает работать, остаётся активным: сервер не
 *     меняется «просто так» после фоновых проверок;
 *  3. только если активного прокси нет или он перестал работать, берётся самый
 *     быстрый полностью рабочий.
 *
 * @returns {Promise<void>}
 */
async function selectBestProxy() {
  const proxies = await getProxies();
  const stats = await getProxyStats();
  const current = await getActiveProxy();
  const settings = await getSettings();

  // Приоритет ручного выбора.
  if (settings.manualProxyId) {
    const manual = proxies.find((proxy) => proxy.id === settings.manualProxyId);
    if (!manual) {
      // Прокси удалён из списка - приоритет больше не нужен.
      log.info('background: ручной прокси удалён из списка - приоритет снят');
      await setSettings({ ...settings, manualProxyId: '' });
    } else {
      const stat = stats[manual.id];
      const dead = !!(stat && stat.checkedAt && !stat.alive);
      if (!dead) {
        if (!current || current.id !== manual.id) {
          log.info('background: оставляем выбранный вручную прокси', formatProxyString(manual));
          await setActiveProxy(manual);
        }
        return;
      }
      // Ручной прокси перестал работать - дальше работает авто-выбор.
      log.info('background: ручной прокси недоступен - переключаемся автоматически');
      await setSettings({ ...settings, manualProxyId: '' });
    }
  }

  // Активный прокси, который ещё работает, остаётся активным. Раньше здесь
  // каждый раз выбирался самый быстрый по пингу, поэтому сервер менялся сам
  // собой после любой фоновой проверки - даже когда пользователь этого не
  // просил и смотрел сайт, который идёт напрямую.
  if (current && proxies.some((proxy) => proxy.id === current.id)) {
    const currentStat = stats[current.id];
    if (
      currentStat &&
      currentStat.alive &&
      currentStat.siteLatency != null &&
      !isLimitedProxyStat(currentStat)
    ) {
      return;
    }
  }

  // По умолчанию активным становится только полностью рабочий прокси: тот,
  // через который открылся тестовый сайт. «Ограниченный» прокси (сайт через
  // него не открылся) может быть быстрее по пингу - и всё равно по умолчанию
  // не выбирается.
  const works = proxies
    .filter((proxy) => {
      const stat = stats[proxy.id];
      return stat && stat.alive && stat.siteLatency != null;
    })
    .sort((a, b) => {
      const la = (stats[a.id] && stats[a.id].latency) || Infinity;
      const lb = (stats[b.id] && stats[b.id].latency) || Infinity;
      return la - lb;
    });

  if (works.length) {
    const best = works[0];
    if (!current || current.id !== best.id) {
      log.info('background: выбран лучший рабочий прокси', formatProxyString(best));
      await setActiveProxy(best);
    }
    return;
  }

  // Если проверенных нет - берём первый из списка.
  if (!current && proxies.length) {
    log.info('background: активный прокси не проверен, берём первый');
    await setActiveProxy(proxies[0]);
  }
}

// ---------------------------------------------------------------------------
// Отключаться от нерабочих
// ---------------------------------------------------------------------------
// Настройка disableOnDeadProxy. Когда она включена, активный прокси проверяется
// только по событию: при переходе на сайт из списка (открытие вкладки или
// обновление страницы) и при запуске браузера. Постоянных проверок в фоне нет -
// если прокси откажет во время работы, достаточно обновить страницу.
//
// Если прокси не открыл тестовый сайт, он помечается «ограниченным» (сайт через
// него не открылся) и включается следующий прокси, чтобы работа продолжилась.
// Настройка не зависит от авто-тестирования прокси.

// Когда последний раз проверяли активный прокси по событию (антиспам).
let lastActiveProxyCheckAt = 0;

// Минимальный интервал между такими проверками, мс: проверка не должна
// превращаться в постоянный фоновый процесс.
const ACTIVE_PROXY_CHECK_INTERVAL = 45000;

// Антиспам для мгновенной реакции на ошибку прокси от Chrome: повторные
// ошибки ТОГО ЖЕ прокси не должны запускать замену в цикле. Ошибка другого
// (только что включённого) прокси обрабатывается сразу.
const PROXY_ERROR_CHECK_INTERVAL = 15000;
let lastProxyErrorCheckAt = 0;
let lastProxyErrorProxyId = '';

// Антиспам для реакции на не открывшуюся страницу проксируемого сайта: одна и та
// же неудача приходит пачками (несколько вкладок, повторные загрузки), а вердикт
// по ней выносится один раз.
const TAB_FAILURE_CHECK_INTERVAL = 10000;
let lastTabFailureCheckAt = 0;
let lastTabFailureProxyId = '';

// Окно сразу после смены прокси. Браузер ещё досылает ошибки прежнего прокси, а
// страница-ошибка прежнего прокси как раз в это время завершает загрузку. Всё
// это относится к прежнему прокси, поэтому в окне новые вердикты не выносятся -
// иначе рабочий прокси, только что включённый на замену, попадал в
// «ограниченные» сразу после включения.
const PROXY_SWITCH_GRACE = 10000;
let lastProxySwitchAt = 0;

// Когда началась загрузка во вкладке: по этой отметке видно, шла ли страница
// через прежний прокси (тогда её ошибка к текущему прокси не относится).
const tabLoadStartedAt = new Map();

// Последний известный настоящий адрес вкладки: на странице с ошибкой Chrome
// держит в tab.url служебный chrome-error://..., а не адрес сайта.
const tabLastUrl = new Map();

// Сколько попыток делает проверка активного прокси, прежде чем признать его
// нерабочим, и пауза между попытками. Одной попытки мало: рабочий, но
// медленный или «дёргающийся» прокси помечался «ограниченным», а это меняло
// активный прокси на другой. Скоростью здесь жертвуем осознанно.
const ACTIVE_PROXY_CHECK_ATTEMPTS = 2;
const ACTIVE_PROXY_CHECK_RETRY_DELAY = 2000;

// Идёт ли такая проверка прямо сейчас.
let activeProxyCheckRunning = false;

// Пришла ошибка прокси от Chrome, пока шла подтверждающая проверка: повторять
// попытки не нужно, ошибку уже сообщил браузер.
let activeProxyErrorDuringCheck = false;

/**
 * Статистика «ограничен»: прокси не открыл тестовый сайт. Именно в это состояние
 * переводится прокси, который не открыл страницу.
 *
 * «Ограничен» не значит «живой»: при смене прокси по ошибке страницы пинг не
 * проверяется, поэтому признак живости берётся из прежней статистики, а не
 * выставляется принудительно.
 *
 * @param {object} stat предыдущая статистика прокси
 * @param {string} error причина
 * @returns {object}
 */
function limitedProxyStat(stat, error) {
  const prev = stat || {};
  const latency = prev.latency != null ? prev.latency : prev.ping != null ? prev.ping : null;
  return {
    alive: prev.alive === true,
    limited: true,
    needsAuth: false,
    latency,
    ping: prev.ping != null ? prev.ping : latency,
    siteLatency: null,
    exitIp: prev.exitIp || null,
    exitCountry: prev.exitCountry || '',
    error: error || 'site_not_opened',
    checkedAt: Date.now(),
  };
}

/**
 * Прокси помечен «ограниченным»: тестовый сайт через него не открылся.
 * Состояние не зависит от того, отвечает ли прокси на пинг.
 *
 * @param {object} stat
 * @returns {boolean}
 */
function isLimitedProxyStat(stat) {
  if (!stat || !stat.checkedAt) return false;
  // Явный флаг есть в новых записях. Старые записи (без флага) распознаём по
  // прежнему признаку: живой прокси без открывшегося тестового сайта.
  if (typeof stat.limited === 'boolean') return stat.limited;
  return !!(stat.alive && stat.siteLatency == null);
}

/** Прокси помечен «недоступным». */
function isDeadProxyStat(stat) {
  return !!(stat && stat.checkedAt && !stat.alive);
}

/**
 * Подбирает следующий прокси для замены.
 *
 * Порядок: сначала полностью рабочие (по возрастанию задержки), затем
 * непроверенные, затем прочие. «Ограниченные» и «недоступные» идут последними -
 * но если других нет, берём и их, чтобы не остаться без прокси совсем.
 *
 * @param {string} excludeId id прокси, который выведен из работы
 * @param {Object<string, object>} stats статистика по id
 * @returns {Promise<object|null>}
 */
async function pickReplacementProxy(excludeId, stats) {
  const proxies = (await getProxies()).filter((proxy) => proxy.id !== excludeId);
  if (!proxies.length) return null;

  const rank = (proxy) => {
    const stat = stats[proxy.id];
    if (isLimitedProxyStat(stat) || isDeadProxyStat(stat)) return 3;
    if (stat && stat.alive && stat.siteLatency != null) return 0;
    if (!stat || !stat.checkedAt) return 1;
    return 2;
  };
  const time = (proxy) => {
    const stat = stats[proxy.id] || {};
    const value = stat.latency != null ? stat.latency : stat.ping;
    return value != null ? value : Infinity;
  };

  return proxies
    .slice()
    .sort((a, b) => {
      const ra = rank(a);
      const rb = rank(b);
      if (ra !== rb) return ra - rb;
      const ta = time(a);
      const tb = time(b);
      if (ta !== tb) return ta - tb;
      return formatProxyString(a).localeCompare(formatProxyString(b));
    })[0];
}

/**
 * Выводит прокси из работы: помечает «ограниченным» и включает следующий.
 *
 * Общая часть для всех сценариев - ошибка от Chrome (ERR_PROXY_CONNECTION_FAILED
 * и подобные) и не открывшаяся страница. Вердикт к этому моменту уже подтверждён
 * вызывающим кодом, поэтому здесь только последствия: статистика, следующий
 * прокси, сообщение в попапе и применение настроек прокси.
 *
 * @param {object} proxy прокси, который выводится из работы
 * @param {string} errorText причина
 * @param {string} reason источник события (для лога)
 * @param {{startedAt?: number, detectedAt?: number, netCheckMs?: number}} [timing]
 *   хронометраж для журнала: когда началась загрузка проксируемой страницы, когда
 *   замечен сбой и сколько заняла проверка связи
 * @returns {Promise<void>}
 */
async function disableActiveProxy(proxy, errorText, reason, timing = null) {
  if (!proxy) return;

  // Прокси мог смениться, пока шла проверка: тогда выводить нечего.
  const current = await getActiveProxy();
  if (!current || current.id !== proxy.id) return;

  const stats = await getProxyStats();
  const alreadyLimited = isLimitedProxyStat(stats[proxy.id]);

  // Включаем следующий прокси, чтобы работа продолжилась.
  const replacement = await pickReplacementProxy(proxy.id, stats);
  const replacementIsBad =
    !replacement || isLimitedProxyStat(stats[replacement.id]) || isDeadProxyStat(stats[replacement.id]);

  // Прокси уже выведен из работы, и замена не лучше (все оставшиеся тоже
  // ограниченные или недоступные): ничего не меняем, иначе настройки прокси
  // пересобирались бы по кругу на каждую повторную ошибку, а прокси просто
  // менялись бы местами без пользы.
  if (alreadyLimited && replacementIsBad) {
    log.debug('background: прокси уже ограничен, замены лучше нет', {
      proxy: formatProxyString(proxy),
      reason,
    });
    return;
  }

  stats[proxy.id] = limitedProxyStat(stats[proxy.id], errorText || 'site_not_opened');
  await setProxyStats(stats);
  log.warn('background: прокси выведен из работы', {
    proxy: formatProxyString(proxy),
    reason,
    error: errorText || null,
  });

  if (replacement) {
    await setActiveProxy(replacement);
    // Ручной выбор больше не актуален: тот прокси признан нерабочим.
    const fresh = await getSettings();
    if (fresh.manualProxyId) await setSettings({ ...fresh, manualProxyId: '' });
    log.info('background: включён следующий прокси', formatProxyString(replacement));
  } else {
    log.warn('background: других прокси для замены нет');
  }

  // Видимый сигнал: на иконке расширения появится «!», в попапе - сообщение.
  setActionBadge('!');
  await setProxyNotice({
    at: Date.now(),
    from: formatProxyString(proxy),
    to: replacement ? formatProxyString(replacement) : '',
  });

  // Каждая автоматическая замена попадает в журнал: по нему видно, что
  // произошло и почему, без чтения консоли service worker.
  //
  // Хронометраж считаем здесь, после applyProxySettings: это и есть момент, когда
  // новый прокси реально встал в работу.
  const switchedAt = Date.now();
  await addJournal(
    'switch',
    'Автоматическая замена прокси',
    [
      'Причина: ' + reason,
      'Заменён: ' +
        formatProxyString(proxy) +
        ' -> ' +
        (replacement ? formatProxyString(replacement) : 'замены нет'),
      errorText ? 'Ошибка: ' + errorText : '',
      timing ? formatSwitchTiming(timing, switchedAt) : '',
    ]
      .filter(Boolean)
      .join('. '),
    formatProxyString(proxy)
  );

  // Началась жизнь под новым прокси: ошибки и страницы прежнего прокси, которые
  // ещё прилетят, к нему уже не относятся.
  lastProxySwitchAt = Date.now();
  await applyProxySettings();
  // Иконка вкладки могла остаться серой от страницы с ошибкой: пересчитываем.
  await refreshActiveTabIcon(true);
}

/**
 * Немедленная реакция на сетевую ошибку прокси от Chrome.
 *
 * Никакой подтверждающей проверки нет: пользователь уже видит страницу с
 * ошибкой ERR_PROXY_CONNECTION_FAILED, поэтому прокси сразу выводится из
 * работы, а проверка этого же прокси не продолжается. Повторные события по тому
 * же прокси (о проблеме сообщают несколько вкладок) гасятся по времени, а другой
 * прокси обрабатывается сразу.
 *
 * @param {string} errorText текст ошибки от Chrome
 * @returns {Promise<void>}
 */
async function handleProxyErrorImmediate(errorText, details, eventAt = 0) {
  const settings = await getSettings();
  if (!settings.enabled || !settings.disableOnDeadProxy) return;
  // Во время пакетной проверки прокси меняет только она сама.
  if (testInProgress) return;

  // Ошибка относится к конкретному запросу. Если запрос шёл напрямую, прокси тут
  // не при чём: без этой проверки расширение меняло сервер из-за любой сетевой
  // ошибки - в том числе на сайте, который прокси не использует.
  const errorUrl = details && details.details ? String(details.details.url || '') : '';
  const errorHost = hostFromUrl(errorUrl);
  if (!errorHost) {
    log.debug('background: ошибка прокси без адреса запроса - прокси не меняем');
    return;
  }
  if (!settings.proxyAllTraffic) {
    const sites = await getProxiedSites();
    if (!isProxied(errorHost, sites)) {
      log.debug('background: ошибка прокси на сайте, который идёт напрямую', {
        host: errorHost,
      });
      return;
    }
  }

  const now = Date.now();
  // Сразу после смены прокси браузер ещё досылает ошибки прежнего прокси: это не
  // про текущий прокси, поэтому такие события пропускаем.
  if (now - lastProxySwitchAt < PROXY_SWITCH_GRACE) return;

  const active = await getActiveProxy();
  if (!active) return;

  if (
    lastProxyErrorProxyId === active.id &&
    now - lastProxyErrorCheckAt < PROXY_ERROR_CHECK_INTERVAL
  ) {
    return;
  }
  lastProxyErrorProxyId = active.id;
  lastProxyErrorCheckAt = now;

  // Подтверждающая проверка этого же прокси уже идёт: повторять попытки не
  // нужно - ошибку сообщил сам браузер, повтор только тянет время.
  if (activeProxyCheckRunning) {
    activeProxyErrorDuringCheck = true;
    return;
  }

  log.warn('background: меняем прокси из-за ошибки прокси', {
    proxy: formatProxyString(active),
    error: errorText || null,
  });

  // Хронометраж: ошибку сообщил Chrome (момент события), а загрузка страницы
  // началась раньше - по этой отметке в журнале видно полное время реакции.
  const errorTabId = details && details.details ? Number(details.details.tabId) : NaN;
  const timing = {
    startedAt: Number.isFinite(errorTabId) ? tabLoadStartedAt.get(errorTabId) || 0 : 0,
    detectedAt: Number(eventAt) || Date.now(),
  };

  await withProxyLock(() =>
    disableActiveProxy(active, errorText || 'proxy_error', 'ошибка прокси от Chrome', timing)
  );
}

/**
 * Проверяет активный прокси и при неудаче переводит его в «ограниченные»,
 * включая следующий прокси.
 *
 * @param {string} reason причина запуска (для лога)
 * @param {{attempts?: number, retryDelay?: number, force?: boolean, timeout?: number}} [options]
 *   attempts - сколько попыток делать (по умолчанию ACTIVE_PROXY_CHECK_ATTEMPTS);
 *   retryDelay - пауза между попытками (по умолчанию
 *   ACTIVE_PROXY_CHECK_RETRY_DELAY); force - не учитывать ограничение по частоте
 *   (страница не открылась); timeout - таймаут одного запроса, мс: нужен, чтобы
 *   вердикт по не открывшейся странице выносился за секунды, а не за минуту;
 *   timing - хронометраж для журнала (когда началась загрузка страницы и когда
 *   замечен сбой).
 * @returns {Promise<void>}
 */
async function maybeCheckActiveProxy(reason, options = {}) {
  if (activeProxyCheckRunning) return;

  const settings = await getSettings();
  if (!settings.disableOnDeadProxy) return;
  if (!settings.enabled) return;
  // Во время пакетной проверки не мешаем: её PAC уже активен.
  if (testInProgress) return;

  const attempts = Math.max(1, Number(options.attempts) || ACTIVE_PROXY_CHECK_ATTEMPTS);
  const retryDelay =
    options.retryDelay != null
      ? Math.max(0, Number(options.retryDelay))
      : ACTIVE_PROXY_CHECK_RETRY_DELAY;
  const force = !!options.force;

  // Короткий таймаут для быстрых вердиктов: обычный таймаут проверки рассчитан
  // на медленные публичные прокси и здесь только затягивал бы замену.
  const shortTimeout = Number(options.timeout) > 0 ? Number(options.timeout) : 0;
  const checkSettings = shortTimeout
    ? {
        ...settings,
        testTimeout: Math.min(Number(settings.testTimeout) || shortTimeout, shortTimeout),
      }
    : settings;

  const now = Date.now();
  // Проверка по событию ограничена по частоте, принудительная - нет: там уже
  // известно, что страница не открылась, и ждать нечего.
  if (!force && now - lastActiveProxyCheckAt < ACTIVE_PROXY_CHECK_INTERVAL) return;
  lastActiveProxyCheckAt = now;

  const active = await getActiveProxy();
  if (!active) return;

  activeProxyCheckRunning = true;
  activeProxyErrorDuringCheck = false;
  try {
    // Проверяем внимательно: та же проверка, что и в списке (пинг цели,
    // открытие тестового сайта, страна выхода), и при неудаче - повтор.
    // Один неудачный запрос не повод считать рабочий прокси «ограниченным»:
    // публичные прокси часто отвечают с задержкой или пропускают первый
    // запрос, а ошибка меняет активный прокси. Скоростью жертвуем осознанно.
    let result = null;
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
      result = await testProxy(active, checkSettings);
      if (result.aborted) return;
      if (result.alive && result.siteLatency != null) {
        // Прокси работает: снимаем значок «!», но только если он всё ещё
        // относится к этому же прокси и сообщение о замене уже закрыто.
        const currentProxy = await getActiveProxy();
        if (currentProxy && currentProxy.id === active.id) {
          await clearActionBadgeIfNoNotice();
        }
        log.debug('background: активный прокси работает', {
          proxy: formatProxyString(active),
          reason,
          attempt,
        });
        return;
      }

      log.warn('background: попытка проверки активного прокси не удалась', {
        proxy: formatProxyString(active),
        reason,
        attempt,
        attempts,
        error: result.error || null,
      });

      // Chrome уже сообщил об ошибке прокси: повторять бессмысленно, прокси всё
      // равно будет выведен из работы.
      if (activeProxyErrorDuringCheck) {
        log.warn('background: во время проверки пришла ошибка прокси - повтор не нужен');
        break;
      }

      // Небольшая пауза перед повтором: даём каналу и прокси «продышаться».
      if (attempt < attempts && retryDelay) {
        await new Promise((resolve) => setTimeout(resolve, retryDelay));
      }
    }

    // Пока мы проверяли, могла начаться проверка по расписанию - её и слушаем.
    if (testInProgress) return;

    // Проверка не удалась - но, возможно, из-за отсутствия связи, а не из-за
    // самого прокси. Тогда вердикт не выносим: прокси остаётся активным, а
    // событие попадает в журнал.
    const network = await checkNetwork(settings);
    if (!network.ok) {
      log.warn('background: вердикт по активному прокси не вынесен - нет связи', { reason });
      await addJournal(
        'skip',
        'Прокси оставлен без изменений',
        'Причина: ' +
          reason +
          '. Интернет недоступен (проверка связи ' +
          formatDuration(network.ms) +
          '), поэтому считать прокси нерабочим нельзя.'
      );
      return;
    }

    await disableActiveProxy(active, result && result.error, reason, options.timing || null);
  } catch (error) {
    log.warn('background: проверка активного прокси по событию не удалась', error);
  } finally {
    activeProxyCheckRunning = false;
  }
}

/**
 * Открылась ли страница во вкладке.
 *
 * На странице ошибки (ERR_PROXY_CONNECTION_FAILED и подобных) выполнить скрипт
 * нельзя - chrome.scripting выбрасывает исключение. Это и есть признак того, что
 * сайт через прокси не открылся. Ложное срабатывание не опасно: следом идёт
 * обычная проверка прокси, и рабочий прокси остаётся активным.
 *
 * @param {number} tabId
 * @returns {Promise<boolean>}
 */
async function isTabLoaded(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, func: () => true });
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Проверяет загрузку страницы вкладки, идущей через прокси.
 *
 * Вызывается при завершении загрузки, и сценариев два:
 *
 *  1. Браузер показал страницу с ошибкой (chrome-error://...): это
 *     ERR_CONNECTION_RESET и подобные, то есть сайт через прокси не открылся.
 *     Сигнал первичный - прокси меняется сразу, без подтверждающих проверок:
 *     пользователь уже смотрит на ошибку, ждать десятки секунд незачем.
 *  2. Страница завершилась без ошибки, но выполнить на ней скрипт нельзя. Тут
 *     сигнал слабее (так бывает и у PDF-просмотрщика), поэтому сначала одна
 *     короткая проверка прокси.
 *
 * @param {chrome.tabs.Tab} tab
 * @param {number} [loadStartedAt] когда началась загрузка этой страницы
 * @param {{url?: string, errorPage?: boolean}} [options] url - адрес, который
 *   открывался (на странице с ошибкой в tab.url его нет), errorPage - браузер
 *   показал страницу с ошибкой
 * @returns {Promise<void>}
 */
async function verifyProxiedTabLoad(tab, loadStartedAt = 0, options = {}) {
  if (!tab || tab.id == null || tab.incognito) return;

  const url = String(options.url || tab.url || '');
  // Ошибка загрузки важна только для http/https: у служебных страниц и
  // PDF-просмотрщика выполнить скрипт нельзя, а через прокси они не идут.
  if (!/^https?:/i.test(url)) return;

  const now = Date.now();
  // Сразу после смены прокси страница-ошибка прежнего прокси как раз завершает
  // загрузку: к текущему прокси это не относится.
  if (now - lastProxySwitchAt < PROXY_SWITCH_GRACE) return;
  // Загрузка началась до смены прокси - страницу открывал прежний прокси.
  if (loadStartedAt && loadStartedAt < lastProxySwitchAt) return;

  const settings = await getCachedSettings();
  if (!settings.enabled || !settings.disableOnDeadProxy) return;

  const host = normalizeDomain(url);
  if (!host) return;

  if (!settings.proxyAllTraffic) {
    const sites = await getCachedProxiedSites();
    if (!isProxied(host, sites)) return;
  }

  if (options.errorPage) {
    // Браузер сам сообщил, что соединение не состоялось: подтверждать нечего.
    log.warn('background: проксируемый сайт не открылся - меняем прокси сразу', { url });
    await handleProxiedTabFailure({ url, tabId: tab.id });
    return;
  }

  const loaded = await isTabLoaded(tab.id);
  if (loaded) return;

  log.warn('background: на странице не выполнился скрипт - проверяем активный прокси', {
    url,
  });
  // Одна проверка с коротким таймаутом: страница могла не открыться из-за
  // осевшего запроса, но и затягивать вердикт нельзя - иначе замена приходила бы
  // через минуту, когда ошибка висит на экране уже давно.
  await maybeCheckActiveProxy('страница не открылась', {
    attempts: 1,
    retryDelay: 0,
    force: true,
    timeout: 6000,
    // Хронометраж для журнала: от начала загрузки этой страницы до замены.
    timing: {
      startedAt: loadStartedAt || tabLoadStartedAt.get(tab.id) || 0,
      detectedAt: Date.now(),
    },
  });
}

/**
 * Меняет активный прокси из-за не открывшейся страницы проксируемого сайта.
 *
 * Подтверждающих проверок здесь нет: ошибку сообщил сам браузер, и пользователь
 * её видит. Задача - как можно скорее включить другой прокси, а не убеждаться в
 * очевидном. Проверяется только одно: есть ли вообще связь с интернетом, иначе
 * сбой сети выглядел бы как отказ прокси.
 *
 * @param {{url?: string, tabId?: number}} info
 * @returns {Promise<void>}
 */
async function handleProxiedTabFailure(info) {
  const settings = await getSettings();
  if (!settings.enabled || !settings.disableOnDeadProxy) return;
  // Пакетная проверка выносит вердикты сама, а подтверждающая уже идёт.
  if (testInProgress || activeProxyCheckRunning) return;

  const active = await getActiveProxy();
  if (!active) return;

  const now = Date.now();
  // Только что меняли прокси: страница с ошибкой относится к прежнему серверу.
  if (now - lastProxySwitchAt < PROXY_SWITCH_GRACE) return;
  // Одна и та же неудача приходит пачками - вердикт по ней один.
  if (
    lastTabFailureProxyId === active.id &&
    now - lastTabFailureCheckAt < TAB_FAILURE_CHECK_INTERVAL
  ) {
    return;
  }
  lastTabFailureProxyId = active.id;
  lastTabFailureCheckAt = now;

  const url = String(info.url || '');

  // Хронометраж: начало загрузки проксируемой страницы - точка отсчёта, момент
  // обнаружения сбоя - это текущее время.
  const startedAt = info.tabId != null ? tabLoadStartedAt.get(info.tabId) || 0 : 0;
  const detectedAt = Date.now();

  // Сеть могла пропасть целиком - тогда ошибка не про прокси.
  const network = await checkNetwork(settings);
  const netCheckMs = network.ms;
  const networkOk = network.ok;

  if (!networkOk) {
    log.warn('background: прокси оставлен - сайт не открылся без интернета', { url });
    await addJournal(
      'skip',
      'Прокси оставлен без изменений',
      'Причина: не открылся сайт ' +
        (url || '(адрес неизвестен)') +
        '. Интернет недоступен (проверка связи ' +
        formatDuration(network.ms) +
        '), поэтому считать прокси нерабочим нельзя.' +
        (startedAt
          ? ' Хронометраж: загрузка ' +
            formatClockTime(startedAt) +
            ', сбой ' +
            formatClockTime(detectedAt) +
            '.'
          : '')
    );
    return;
  }

  log.warn('background: меняем прокси из-за не открывшейся страницы', {
    url,
    proxy: formatProxyString(active),
  });

  await withProxyLock(() =>
    disableActiveProxy(active, '', 'сайт не открылся во вкладке', {
      startedAt,
      detectedAt,
      netCheckMs,
    })
  );

  // Страница с ошибкой осталась на экране: перезагружаем её, чтобы новый прокси
  // сразу показал результат, а не ждал ручного обновления страницы.
  if (info.tabId != null) {
    try {
      const current = await chrome.tabs.get(info.tabId);
      if (current && /^chrome-error:/i.test(current.url || '')) {
        await chrome.tabs.reload(info.tabId, { bypassCache: true });
      }
    } catch (error) {
      log.debug('background: не удалось перезагрузить страницу с ошибкой', error);
    }
  }
}

// ---------------------------------------------------------------------------
// Служебные обработчики
// ---------------------------------------------------------------------------

/**
 * Разбирает список времён авто-теста в массив { hours, minutes, key }.
 *
 * Принимает массив строк или одну строку с разделителями (запятая, точка с
 * запятой, пробел, перевод строки). Формат времени - «HH:MM» (допускается
 * «H:MM» и «HH.MM»). Некорректные значения отбрасываются, дубликаты
 * убираются, результат сортируется по возрастанию времени суток.
 *
 * @param {Array<string>|string} value
 * @returns {Array<{hours: number, minutes: number, key: string}>}
 */
function parseAutoTestTimes(value) {
  const raw = Array.isArray(value) ? value : String(value || '').split(/[,\s;]+/);
  const seen = new Set();
  const times = [];
  for (const item of raw) {
    const match = String(item).trim().match(/^([01]?\d|2[0-3])[:.]([0-5]\d)$/);
    if (!match) continue;
    const hours = parseInt(match[1], 10);
    const minutes = parseInt(match[2], 10);
    const key = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
    if (seen.has(key)) continue;
    seen.add(key);
    times.push({ hours, minutes, key });
  }
  times.sort((a, b) => a.hours * 60 + a.minutes - (b.hours * 60 + b.minutes));
  return times;
}

/**
 * Ближайшее время из расписания, строго позже указанного момента.
 *
 * Если все времена на сегодня уже прошли, возвращается первое время на
 * завтра. Возвращает null, если расписание пусто.
 *
 * @param {Array<{hours: number, minutes: number}>} times
 * @param {Date} from
 * @returns {Date|null}
 */
function nextAutoTestDate(times, from) {
  if (!times.length) return null;
  const base = from instanceof Date ? from : new Date();
  const ahead = base.getTime() + 1000;
  for (const item of times) {
    const candidate = new Date(
      base.getFullYear(),
      base.getMonth(),
      base.getDate(),
      item.hours,
      item.minutes,
      0,
      0
    );
    if (candidate.getTime() > ahead) return candidate;
  }
  const first = times[0];
  return new Date(
    base.getFullYear(),
    base.getMonth(),
    base.getDate() + 1,
    first.hours,
    first.minutes,
    0,
    0
  );
}

/**
 * Планирует авто-тест на ближайшее точное время из расписания.
 *
 * Основной режим - точные времена суток (настройка autoTestTimes, их может
 * быть несколько). Alarm создаётся одноразовым (when), а следующее время
 * планирует обработчик onAlarm - так работает любое количество времён в сутки.
 *
 * Если времена не заданы, работает прежний режим по интервалу в минутах
 * (autoTestInterval): это совместимость со старыми сохранениями, где
 * интервал был единственной настройкой расписания.
 *
 * @param {string} [reason] причина постановки расписания: попадает в журнал, чтобы
 *   было видно, почему время проверки изменилось
 * @returns {Promise<void>}
 */
async function scheduleAutoTest(reason = '') {
  const settings = await getSettings();

  const times = parseAutoTestTimes(settings.autoTestTimes);
  const interval = parseInt(settings.autoTestInterval, 10);
  const periodInMinutes = Math.max(1, interval);

  // Ключ расписания (для сравнения) и его описание (для журнала).
  const wanted = !settings.autoTestEnabled
    ? 'off'
    : times.length
      ? 'times:' + times.map((item) => item.key).join(',')
      : interval > 0
        ? 'every:' + periodInMinutes
        : 'none';

  const scheduleText = !settings.autoTestEnabled
    ? 'Проверка прокси в фоне выключена'
    : times.length
      ? 'Проверка по времени: ' + times.map((item) => item.key).join(', ')
      : interval > 0
        ? 'Проверка каждые ' + periodInMinutes + ' мин'
        : 'Включено «Проверять прокси автоматически в фоне», но не задано ни «Время проверок», ни «Интервал проверки (мин)»';

  // Что стоит на самом деле прямо сейчас: сам alarm и его ключ в storage. Пока
  // ничего не изменилось, alarm не трогаем - иначе отсчёт начинался бы заново.
  // Если alarm пропал (Chrome мог его сбросить), проверка `existing` его создаст.
  const storedKey = await getValue('autoTestScheduled', '');
  const existing = await chrome.alarms.get(ALARM_TEST_PROXIES);

  if (existing && storedKey === wanted) {
    // Обычный ход расписания: после прогона время ушло вперёд на интервал. В
    // журнал об этом не пишем - иначе на каждый прогон была бы лишняя запись.
    if (reason === AUTOTEST_AFTER_RUN) {
      if (existing.scheduledTime) await setValue('autoTestExpectedAt', existing.scheduledTime);
      return;
    }

    // Расписание то же и alarm на месте: не пересоздаём (иначе отсчёт начался бы
    // заново), но время проверки сверяем с журналом. Сдвинуть его может и сам
    // Chrome - например при перезагрузке расширения он ставит периодический
    // alarm заново от момента загрузки. Без этой сверки время уезжало бы молча,
    // и выглядело бы это как поломка таймера.
    await noteAutoTestSchedule(reason, scheduleText, existing.scheduledTime || 0);
    return;
  }

  await chrome.alarms.clear(ALARM_TEST_PROXIES);
  await setValue('autoTestScheduled', wanted);

  if (wanted === 'off' || wanted === 'none') {
    if (wanted === 'none') {
      log.warn('background: авто-тест включён, но ни время, ни интервал не заданы');
    }
    await noteAutoTestSchedule(reason, scheduleText, 0);
    return;
  }

  if (times.length) {
    const next = nextAutoTestDate(times, new Date());
    if (!next) return;
    chrome.alarms.create(ALARM_TEST_PROXIES, { when: next.getTime() });
    log.debug('background: авто-тест запланирован по времени', {
      next: next.toLocaleString(),
      times: times.map((item) => item.key),
    });
    await noteAutoTestSchedule(reason, scheduleText, next.getTime());
    return;
  }

  // Интервал в минутах: работает, когда точное время не задано. Значение
  // должно быть положительным - иначе расписание не строим, иначе проверка
  // запускалась бы каждую минуту.
  chrome.alarms.create(ALARM_TEST_PROXIES, { periodInMinutes });
  log.debug('background: авто-тест запланирован по интервалу', { periodInMinutes });

  // Ближайшее время берём у самого alarm: это то время, которое видит Chrome,
  // поэтому по журналу сразу понятно, когда ждать проверку. Оно же нужно для
  // записи об опоздании (сон, гибернация).
  const alarm = await chrome.alarms.get(ALARM_TEST_PROXIES);
  const planned =
    alarm && alarm.scheduledTime ? alarm.scheduledTime : Date.now() + periodInMinutes * 60000;
  await noteAutoTestSchedule(reason, scheduleText, planned);
}

/**
 * Доводит сохранённые настройки до текущей версии набора.
 *
 * Новые настройки (их у пользователя быть не могло - в интерфейсе их раньше не
 * было) включаем: «Отключаться от нерабочих», «Удалять недоступные при
 * авто-тесте», «Дозагружать новые прокси». Устаревшие настройки убираем.
 * Дальше пользователь меняет всё сам, и миграция больше не выполняется -
 * версия уже текущая.
 *
 * @returns {Promise<void>}
 */
async function migrateSettings() {
  const settings = await getSettings();
  const version = Number(settings.settingsVersion) || 0;
  if (version >= SETTINGS_VERSION) return;

  const next = {
    ...settings,
    disableOnDeadProxy: true,
    autoTestDeleteDead: true,
    autoTestRefill: true,
    // Версия 4: «Удалять ограниченные» - включено по умолчанию.
    autoTestDeleteLimited: true,
    // Версия 5: «Удалять непроверенные» - включено по умолчанию.
    autoTestDeleteUntested: true,
    settingsVersion: SETTINGS_VERSION,
  };
  // Версия 3: «Автозагрузка по таймеру» и «Проверять после загрузки» больше не
  // используются - их функции выполняют авто-тест (расписание) и дозаливка.
  delete next.sourcesEnabled;
  delete next.sourcesInterval;
  delete next.sourcesAutoTest;
  // Лимит прокси: у старых профилей там 0 (прежнее значение по умолчанию) -
  // подставляем новый дефолт 50. Дальше пользователь меняет его сам.
  if (!next.sourcesLimit) next.sourcesLimit = 50;

  await setSettings(next);
  log.info('background: настройки обновлены до версии', {
    from: version,
    to: SETTINGS_VERSION,
  });
}

/**
 * Инициализация при установке/обновлении.
 * @param {object} details
 * @returns {Promise<void>}
 */
async function onInstalled(details) {
  await migrateSettings();
  const settings = await getSettings();
  await setSettings(settings);
  await scheduleAutoTest('установка или обновление расширения');
  await selectBestProxy();
  await applyProxySettings();

  if (details && details.reason === 'install') {
    chrome.tabs.create({ url: 'options.html' });
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  onInstalled(details).catch((error) => log.error('background: onInstalled', error));
});

chrome.runtime.onStartup.addListener(() => {
  (async () => {
    await scheduleAutoTest('запуск браузера');
    await selectBestProxy();
    await applyProxySettings();
  })().catch((error) => log.error('background: onStartup', error));

  // «Отключаться от нерабочих»: после запуска браузера проверяем активный
  // прокси один раз.
  maybeCheckActiveProxy('запуск браузера').catch((error) =>
    log.debug('background: проверка активного прокси при старте', error)
  );
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_TEST_PROXIES) {
    (async () => {
      try {
        // auto: true - проверка запущена по расписанию. К ней применяются
        // отдельные настройки: удаление недоступных и дозаливка новых прокси.
        await testAllProxies(undefined, { auto: true });
      } catch (error) {
        log.error('background: autoTest', error);
      } finally {
        // Alarm одноразовый (when) - планируем следующее время из расписания.
        await scheduleAutoTest(AUTOTEST_AFTER_RUN);
      }
    })();
  }
});

// Реакция на изменения настроек.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;

  // Кэш настроек и сайтов сбрасываем всегда: он используется иконкой вкладки,
  // а событий вкладок много - без сброса иконка показывала бы старое состояние.
  if ('settings' in changes) settingsCache = null;
  if ('proxiedSites' in changes) proxiedSitesCache = null;

  const relevant = ['proxies', 'proxiedSites', 'settings', 'activeProxy'];
  if (relevant.some((key) => key in changes)) {
    applyProxySettings().catch((error) => log.error('background: storage change', error));
  }
  if ('settings' in changes) {
    scheduleAutoTest('изменение настроек').catch((error) =>
      log.error('background: schedule', error)
    );
  }
});

// ---------------------------------------------------------------------------
// Сообщения от UI
// ---------------------------------------------------------------------------

/**
 * Обрабатывает сообщения от popup/options.
 * @param {object} message
 * @param {object} sender
 * @param {Function} sendResponse
 * @returns {boolean}
 */
function handleMessage(message, sender, sendResponse) {
  const { type } = message || {};
  log.debug('background: получено сообщение', type, message);

  (async () => {
    switch (type) {
      case 'getState': {
        const [settings, proxies, proxiedSites, activeProxy, stats, notice, journal, archive] =
          await Promise.all([
            getSettings(),
            getProxies(),
            getProxiedSites(),
            getActiveProxy(),
            getProxyStats(),
            getProxyNotice(),
            getJournal(),
            getProxyArchive(),
          ]);

        // Состояние таймера авто-теста: в настройках по нему видно, когда ждать
        // следующую проверку. Спрашиваем именно у Chrome (alarms.get), а не у
        // storage: важно то, что стоит на самом деле, а не что мы записали.
        let autoTest = null;
        try {
          const alarm = await chrome.alarms.get(ALARM_TEST_PROXIES);
          autoTest = {
            enabled: settings.autoTestEnabled !== false,
            plannedAt: Number(await getValue('autoTestExpectedAt', 0)) || 0,
            scheduledTime: alarm && alarm.scheduledTime ? alarm.scheduledTime : 0,
            periodInMinutes: alarm && alarm.periodInMinutes ? alarm.periodInMinutes : 0,
          };
        } catch (error) {
          log.debug('background: не удалось прочитать состояние таймера', error);
        }
        sendResponse({
          settings,
          proxies,
          proxiedSites,
          activeProxy,
          stats,
          notice,
          journal,
          archive,
          autoTest,
          incognito: incognitoState,
        });
        break;
      }
      case 'getIncognitoState': {
        const allowed = await isIncognitoAllowed();
        if (allowed !== null) incognitoState = allowed ? 'allowed' : 'denied';
        sendResponse({ ok: true, incognito: incognitoState });
        break;
      }
      case 'applyProxySettings': {
        await applyProxySettings();
        sendResponse({ ok: true });
        break;
      }
      case 'testAllProxies': {
        await testAllProxies(message.ids);
        sendResponse({ ok: true });
        break;
      }
      case 'selectBestProxy': {
        await selectBestProxy();
        await applyProxySettings();
        sendResponse({ ok: true });
        break;
      }
      case 'isProxied': {
        const hostname = normalizeDomain(message.hostname);
        const proxiedSites = await getProxiedSites();
        const proxied = self.QProxyStorage.isProxied(hostname, proxiedSites);
        sendResponse({ proxied });
        break;
      }
      case 'setSiteProxied': {
        const hostname = normalizeDomain(message.hostname);
        const proxied = !!message.proxied;
        const proxiedSites = await getProxiedSites();
        let next;
        if (proxied) {
          next = Array.from(new Set([...proxiedSites, hostname]));
        } else {
          next = proxiedSites.filter((site) => normalizeDomain(site) !== hostname);
        }
        await setProxiedSites(next);
        await applyProxySettings();
        log.info('background: сайт', hostname, proxied ? 'добавлен в проксируемые' : 'убран из проксируемых');
        sendResponse({ ok: true, proxied, count: next.length });
        break;
      }
      case 'addProxiedSites': {
        const domains = (message.domains || []).map(normalizeDomain).filter(Boolean);
        const proxiedSites = await getProxiedSites();
        const merged = Array.from(new Set([...proxiedSites, ...domains]));
        await setProxiedSites(merged);
        await applyProxySettings();
        log.info('background: добавлено доменов', domains.length);
        sendResponse({ ok: true, count: merged.length });
        break;
      }
      case 'removeProxiedSite': {
        const domain = normalizeDomain(message.domain);
        const proxiedSites = await getProxiedSites();
        await setProxiedSites(proxiedSites.filter((item) => normalizeDomain(item) !== domain));
        await applyProxySettings();
        sendResponse({ ok: true });
        break;
      }
      case 'setProxiedSites': {
        const domains = Array.from(
          new Set((message.domains || []).map(normalizeDomain).filter(Boolean))
        );
        await setProxiedSites(domains);
        await applyProxySettings();
        log.info('background: список сайтов сохранён', domains.length);
        sendResponse({ ok: true, count: domains.length });
        break;
      }
      case 'setProxies': {
        // Страховка от дубликатов: двух одинаковых host:port в списке быть не
        // может, даже если они пришли из интерфейса.
        await setProxies(dedupeProxies(message.proxies || []));
        await selectBestProxy();
        await applyProxySettings();
        sendResponse({ ok: true });
        break;
      }
      case 'addProxiesFromText': {
        const parsed = parseProxyList(message.text || '');
        const existing = await getProxies();
        const existingKeys = new Set(existing.map((p) => `${p.host}:${p.port}`));
        const fresh = [];
        for (const item of parsed) {
          const key = `${item.host}:${item.port}`;
          if (existingKeys.has(key)) continue;
          existingKeys.add(key);
          fresh.push({ id: generateProxyId(), name: '', ...item });
        }
        const merged = dedupeProxies([...existing, ...fresh]);
        await setProxies(merged);
        await selectBestProxy();
        await applyProxySettings();

        // Определяем страны добавленных прокси, чтобы в таблице настроек не
        // было прочерков. Первые 200 - сразу, остальные дозаполняются в фоне.
        if (fresh.length) {
          try {
            await detectCountries({ limit: 200 });
          } catch (error) {
            log.warn('background: определение стран после импорта', error);
          }
        }

        log.info('background: добавлено прокси из текста', {
          parsed: parsed.length,
          added: fresh.length,
          total: merged.length,
        });
        sendResponse({ ok: true, parsed: parsed.length, added: fresh.length, total: merged.length });
        break;
      }
      case 'removeUntestedProxies': {
        const proxies = await getProxies();
        const stats = await getProxyStats();
        const kept = proxies.filter((proxy) => stats[proxy.id] && stats[proxy.id].checkedAt);
        await setProxies(kept);
        await selectBestProxy();
        await applyProxySettings();
        log.info('background: удалено непроверенных', proxies.length - kept.length);
        sendResponse({ ok: true, removed: proxies.length - kept.length, total: kept.length });
        break;
      }
      case 'removeDeadProxies': {
        const proxies = await getProxies();
        const stats = await getProxyStats();
        const kept = proxies.filter((proxy) => {
          const stat = stats[proxy.id];
          return !stat || !stat.checkedAt || stat.alive;
        });
        await setProxies(kept);
        await selectBestProxy();
        await applyProxySettings();
        log.info('background: удалено нерабочих', proxies.length - kept.length);
        sendResponse({ ok: true, removed: proxies.length - kept.length, total: kept.length });
        break;
      }
      case 'archiveRestore': {
        // Возврат прокси из «Хранилища рабочих» в список с повторной проверкой:
        // в хранилище попадают только те, что уже подтверждали работу.
        //
        // Адреса приходят из интерфейса: только он знает, как отсортирована
        // таблица и сколько строк сверху нужно, поэтому «сверху» на экране и
        // «сверху» в возврате - одно и то же. Без списка адресов берём первые
        // по пингу: так работал бы вызов без сортировки в интерфейсе.
        const archive = await getProxyArchive();
        const requested = Array.isArray(message.addresses)
          ? message.addresses.map((value) => String(value).trim()).filter(Boolean)
          : [];

        let picked = [];
        if (requested.length) {
          for (const address of requested) {
            const entry = archive[address];
            if (entry) picked.push(entry);
          }
        } else {
          const limit = Math.max(0, parseInt(message.limit, 10) || 0);
          const entries = Object.keys(archive)
            .map((key) => archive[key])
            .sort((a, b) => {
              const av = a.ping != null ? a.ping : Infinity;
              const bv = b.ping != null ? b.ping : Infinity;
              if (av !== bv) return av - bv;
              return (b.lastOkAt || 0) - (a.lastOkAt || 0);
            });
          picked = limit ? entries.slice(0, limit) : entries;
        }

        const existing = await getProxies();
        const known = new Set(existing.map((proxy) => `${proxy.host}:${proxy.port}`));
        const fresh = [];
        for (const entry of picked) {
          const key = `${entry.host}:${entry.port}`;
          if (known.has(key)) continue;
          known.add(key);
          fresh.push({
            id: generateProxyId(),
            name: '',
            host: entry.host,
            port: entry.port,
            country: entry.country || '',
          });
        }
        if (fresh.length) await setProxies(dedupeProxies([...existing, ...fresh]));

        log.info('background: возврат прокси из хранилища прокси', {
          picked: picked.length,
          added: fresh.length,
          total: existing.length + fresh.length,
        });
        sendResponse({
          ok: true,
          picked: picked.length,
          added: fresh.length,
          addresses: picked.map((entry) => `${entry.host}:${entry.port}`),
        });

        // Проверку запускаем после ответа: она идёт минутами, а страница
        // настроек следит за ходом по прогрессу.
        if (fresh.length) {
          testAllProxies(fresh.map((proxy) => proxy.id)).catch((error) =>
            log.warn('background: проверка возвращённых из хранилища прокси', error)
          );
        }
        break;
      }
      case 'archivePrune': {
        // Удаление неудачных записей из «Хранилища рабочих» по кнопке: убираются
        // записи, у которых неудачных проверок не меньше порога. Само расширение
        // такое удаление не выполняет - только по нажатию кнопки в настройках.
        const limit = Math.max(0, parseInt(message.limit, 10) || 0);
        if (!limit) {
          sendResponse({ ok: true, removed: 0, left: 0, limit: 0 });
          break;
        }

        const archive = await getProxyArchive();
        const removed = [];
        for (const key of Object.keys(archive)) {
          if ((Number(archive[key].failCount) || 0) >= limit) {
            removed.push(archive[key]);
            delete archive[key];
          }
        }

        if (removed.length) {
          await setProxyArchive(archive);
          log.info('background: из хранилища прокси удалены неудачные записи', {
            removed: removed.length,
            limit,
          });
          await addJournal(
            'remove',
            'Удалены неудачные прокси из хранилища',
            'Неудачных проверок ' +
              limit +
              ' и больше: ' +
              removed.length +
              ' записей (' +
              journalProxyList(removed) +
              ').'
          );
        }

        sendResponse({
          ok: true,
          removed: removed.length,
          left: Object.keys(archive).length,
          limit,
        });
        break;
      }
      case 'archiveClear': {
        await setProxyArchive({});
        log.info('background: хранилище прокси очищено');
        sendResponse({ ok: true });
        break;
      }
      case 'fetchProxySources': {
        const result = await fetchProxySources();
        sendResponse({ ok: true, ...result });
        break;
      }
      case 'detectCountries': {
        // limit приходит из UI: при больших списках страны дозаполняются по
        // частям, чтобы не запускать тысячи внешних запросов разом.
        const result = await detectCountries({ limit: message.limit });
        sendResponse({ ok: true, ...result });
        break;
      }
      case 'applyCountryFilter': {
        const settings = await getSettings();
        const stats = await getProxyStats();
        const proxies = await getProxies();
        const kept = proxies.filter((proxy) => passesCountryFilter(proxy, settings, stats[proxy.id]));
        await setProxies(kept);
        await selectBestProxy();
        await applyProxySettings();
        log.info('background: фильтр стран применён', {
          removed: proxies.length - kept.length,
          kept: kept.length,
        });
        if (proxies.length !== kept.length) {
          await addJournal(
            'remove',
            'Фильтр стран удалил прокси',
            'Применён по кнопке: удалено ' +
              (proxies.length - kept.length) +
              ', осталось ' +
              kept.length +
              '.'
          );
        }
        sendResponse({ ok: true, removed: proxies.length - kept.length, kept: kept.length });
        break;
      }
      case 'keepOnlyCountry': {
        const country = String(message.country || '').toUpperCase();
        const settings = await getSettings();
        const stats = await getProxyStats();
        const proxies = await getProxies();
        const kept = proxies.filter(
          (proxy) => getFilterCountry(proxy, settings, stats[proxy.id]) === country
        );
        await setProxies(kept);
        await selectBestProxy();
        await applyProxySettings();
        log.info('background: оставлена только страна', country, { kept: kept.length });
        if (proxies.length !== kept.length) {
          await addJournal(
            'remove',
            'Оставлена одна страна',
            'Оставлено ' +
              kept.length +
              ' прокси (' +
              country +
              '), удалено ' +
              (proxies.length - kept.length) +
              '.'
          );
        }
        sendResponse({ ok: true, removed: proxies.length - kept.length, kept: kept.length });
        break;
      }
      case 'getProgress': {
        sendResponse({
          ok: true,
          progress: {
            ...checkProgress,
            checking: Array.from(checkingIds),
            queued: Array.from(queuedIds),
          },
        });
        break;
      }
      case 'stopTestProxies': {
        testAborted = true;
        // Обрываем уже начатые запросы: без этого остановка ждала бы таймаута
        // текущего прокси - до нескольких десятков секунд.
        if (testAbortController) testAbortController.abort();
        log.info('background: проверка остановлена пользователем', {
          running: testInProgress,
        });
        sendResponse({ ok: true, running: testInProgress });
        break;
      }
      case 'getProxySources': {
        const sources = await getProxySources();
        sendResponse({ ok: true, sources });
        break;
      }
      case 'setProxySources': {
        const sources = (message.sources || [])
          .map((s) => String(s).trim())
          .filter(Boolean);
        await setProxySources(sources);
        sendResponse({ ok: true, count: sources.length });
        break;
      }
      case 'setActiveProxy': {
        // Прокси выбран пользователем (попап или кнопка «Использовать» в
        // настройках): запоминаем ручной выбор, чтобы авто-выбор после
        // проверок его не перебивал.
        const chosen = message.proxy || null;
        await setActiveProxy(chosen);
        // Пользователь сам выбрал прокси - значок «была замена» убираем.
        setActionBadge('');
        const settings = await getSettings();
        await setSettings({ ...settings, manualProxyId: chosen ? chosen.id : '' });
        await applyProxySettings();
        log.info('background: ручной выбор прокси', chosen ? formatProxyString(chosen) : '(сброс)');
        sendResponse({ ok: true });
        break;
      }
      case 'clearProxyNotice': {
        // Крестик в уведомлении попапа: убираем уведомление и значок «!»
        // с иконки расширения, а иконку активной вкладки пересчитываем: она
        // могла остаться серой от страницы с ошибкой прежнего прокси.
        await setProxyNotice(null);
        setActionBadge('');
        await refreshActiveTabIcon(true);
        log.info('background: уведомление о замене прокси закрыто пользователем');
        sendResponse({ ok: true });
        break;
      }
      case 'clearJournal': {
        await setJournal([]);
        log.info('background: журнал очищен пользователем');
        sendResponse({ ok: true });
        break;
      }
      case 'setSettings': {
        const current = await getSettings();
        const next = { ...current, ...(message.settings || {}) };
        await setSettings(next);
        await scheduleAutoTest('изменение настроек');
        await applyProxySettings();
        sendResponse({ ok: true, settings: next });
        break;
      }
      case 'diagnose': {
        const [settings, proxies, proxiedSites, activeProxy] = await Promise.all([
          getSettings(),
          getProxies(),
          getProxiedSites(),
          getActiveProxy(),
        ]);
        const actual = await chrome.proxy.settings.get({ incognito: false });

        // Отдельно смотрим скоуп инкогнито: если прокси в приватных окнах
        // контролирует другое расширение, сайты там будут падать с
        // ERR_PROXY_CONNECTION_FAILED.
        let incognitoReport = null;
        try {
          const incognitoActual = await chrome.proxy.settings.get({ incognito: true });
          incognitoReport = {
            levelOfControl: incognitoActual.levelOfControl,
            mode: incognitoActual.value && incognitoActual.value.mode,
          };
        } catch (error) {
          incognitoReport = {
            error: String(error && error.message ? error.message : error),
          };
        }

        const report = {
          settings,
          proxiesCount: proxies.length,
          proxiedSites,
          activeProxy,
          proxyString: activeProxy ? formatProxyString(activeProxy) : null,
          levelOfControl: actual.levelOfControl,
          mode: actual.value && actual.value.mode,
          incognitoState,
          incognito: incognitoReport,
          pacPreview:
            actual.value && actual.value.pacScript
              ? actual.value.pacScript.data.slice(0, 400)
              : null,
        };
        log.info('background: диагностика', report);
        sendResponse({ ok: true, report });
        break;
      }
      default:
        log.warn('background: неизвестный тип сообщения', type);
        sendResponse({ ok: false, error: 'unknown_message' });
    }
  })().catch((error) => {
    log.error('background: handleMessage', error);
    sendResponse({ ok: false, error: String(error && error.message ? error.message : error) });
  });

  return true;
}

chrome.runtime.onMessage.addListener(handleMessage);

// Первичная инициализация при старте service worker.
(async () => {
  // Миграция настроек нужна и здесь: service worker может подняться без
  // события onInstalled (например, после перезапуска браузера).
  await migrateSettings();
  // Разбор прерванного авто-теста: если прошлый прогон не дошёл до конца, в
  // списке могли остаться прокси без результата.
  await cleanupInterruptedAutoTest();
  await scheduleAutoTest('старт service worker');
  await selectBestProxy();
  await applyProxySettings();
})().catch((error) => log.error('background: init', error));
