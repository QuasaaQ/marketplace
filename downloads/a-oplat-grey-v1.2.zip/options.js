// ==================== Вспомогательные функции для авто расчёта ====================
function getPreviousWorkday() {
    const today = new Date();
    let day = today.getDay();
    let offset = 1;
    if (day === 1) offset = 3;
    if (day === 0) offset = 2;
    if (day === 6) offset = 1;
    const prev = new Date(today);
    prev.setDate(today.getDate() - offset);
    while (prev.getDay() === 0 || prev.getDay() === 6) {
        prev.setDate(prev.getDate() - 1);
    }
    return prev.toISOString().split('T')[0];
}

function calculateEndDate(startDateStr) {
    const start = new Date(startDateStr);
    if (start.getDay() === 5) {
        const end = new Date(start);
        end.setDate(start.getDate() + 2);
        return end.toISOString().split('T')[0];
    }
    return startDateStr;
}

// Список подразделений по умолчанию (если не сохранён)
const DEFAULT_PAIRS = [
    "КЦЕ_НП_Е_Тула_БИТ_Е",
    "КЦЕ_НП_Е_Тула_ТКЦ1_ГБ",
    "АП_НП_П_Москва_ГПНК1_ГБ_УД",
    "АП_НП_П_Краснодар_ГПНК1_ГБ_УД",
    "КЦЕ_НП_Е_Тула_ТКЦ2_БУХ",
    "КЦЕ_НП_Е_Тула_ТКЦ3_ФД",
    "КЦЕ_НП_Е_Тула_ТКЦ4_ГБ",
    "КЦЕ_НП_Е_Тула_ТКЦ5_ПР_КиHR",
    "КЦЕ_НП_Е_Тула_ТКЦ7_ГБ",
    "КЦЕ_НП_Е_Тула_ТКЦ8_БУХ"
];

// Загрузка настроек
async function loadSettings() {
    const storage = await chrome.storage.sync.get(['autoDates', 'startDate', 'endDate', 'pairs']);
    
    const autoDates = storage.autoDates !== undefined ? storage.autoDates : true;
    document.getElementById('autoDates').checked = autoDates;
    
    if (storage.startDate) document.getElementById('startDate').value = storage.startDate;
    if (storage.endDate) document.getElementById('endDate').value = storage.endDate;
    
    // Список подразделений: если есть сохранённый, берём его, иначе DEFAULT_PAIRS
    let pairsList = DEFAULT_PAIRS;
    if (storage.pairs && storage.pairs.length > 0) {
        pairsList = storage.pairs;
    }
    document.getElementById('pairsList').value = pairsList.join('\n');
    
    if (autoDates) {
        const computedStart = getPreviousWorkday();
        const computedEnd = calculateEndDate(computedStart);
        document.getElementById('startDate').placeholder = `Авто: ${computedStart}`;
        document.getElementById('endDate').placeholder = `Авто: ${computedEnd}`;
    }
}

// Сохранение
document.getElementById('saveBtn').addEventListener('click', async () => {
    const autoDates = document.getElementById('autoDates').checked;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const pairsText = document.getElementById('pairsList').value;
    const pairs = pairsText.split(/\r?\n/).filter(s => s.trim().length > 0);
    
    if (!autoDates) {
        if (!startDate || !endDate) {
            document.getElementById('status').innerText = '❌ При выключенном авто расчёте укажите обе даты';
            return;
        }
        if (pairs.length === 0) {
            document.getElementById('status').innerText = '❌ Укажите хотя бы одно подразделение';
            return;
        }
    } else {
        if (pairs.length === 0) {
            document.getElementById('status').innerText = '❌ Укажите хотя бы одно подразделение';
            return;
        }
    }
    
    await chrome.storage.sync.set({
        autoDates,
        startDate: autoDates ? '' : startDate,
        endDate: autoDates ? '' : endDate,
        pairs
    });
    document.getElementById('status').innerText = '✅ Настройки сохранены';
    setTimeout(() => document.getElementById('status').innerText = '', 2000);
});

// Версия берётся из manifest.json, чтобы не расходиться с реальной
const footerVersion = document.getElementById('footerVersion');
if (footerVersion) {
    footerVersion.textContent = 'Версия ' + chrome.runtime.getManifest().version;
}

document.addEventListener('DOMContentLoaded', loadSettings);