/**
 * Q.Proxy - общий модуль работы с настройками.
 *
 * Модель простая: сайт либо проксируется, либо нет.
 *  - список проксируемых сайтов (мой список);
 *  - список своих прокси;
 *  - настройки авто-тестирования прокси.
 *
 * Модуль используется и в service worker (background.js), и в UI-страницах.
 *
 * ВАЖНО: весь код обёрнут в IIFE, чтобы не создавать глобальных `const`
 * (иначе повторное объявление в popup.js/options.js ломает скрипты).
 */

(function () {
  'use strict';

  const STORAGE_KEYS = {
    PROXIES: 'proxies',
    PROXIED_SITES: 'proxiedSites',
    SETTINGS: 'settings',
    ACTIVE_PROXY: 'activeProxy',
    PROXY_STATS: 'proxyStats',
    // «Хранилище прокси»: все проверенные прокси, рабочие и неудачные. Живёт
    // отдельно от списка прокси и авто-тестом не чистится.
    PROXY_ARCHIVE: 'proxyArchive',
    PROXY_SOURCES: 'proxySources',
    PROXY_NOTICE: 'proxyNotice',
    JOURNAL: 'journal',
  };

  // Сколько записей журнала хранить. Запас с большим избытком: одна запись
  // занимает пару сотен байт, поэтому даже длинный журнал - это доли мегабайта,
  // а расширение и так запрашивает unlimitedStorage. Старые записи вытесняются.
  const JOURNAL_MAX_ENTRIES = 2000;

  // Общий протокол для всего списка прокси.
  const PROXY_PROTOCOLS = ['socks5', 'socks4', 'http', 'https'];

  // Готовый список сервисов ИИ: добавляется в проксируемые сайты одной кнопкой,
  // чтобы не набирать домены руками. Список не обязателен - какие сайты
  // открывать через прокси, пользователь решает сам и может его изменить.
  const AI_SITES = [
    'chatgpt.com',
    'claude.ai',
    'gemini.google.com',
    'grok.com',
    'accounts.x.ai',
    'perplexity.ai',
    'copilot.microsoft.com',
  ];

  // Тестовые цели для проверки прокси.
  const TEST_TARGETS = {
    google: 'https://www.google.com/generate_204',
    cloudflare: 'https://cloudflare.com/cdn-cgi/trace',
    amazon: 'https://checkip.amazonaws.com',
    azure: 'https://azure.microsoft.com/robots.txt',
  };

  // Сервисы определения страны по IP (страна размещения прокси).
  //
  // Проверены на живые ответы и на заголовок Access-Control-Allow-Origin: *
  // (без него запрос из service worker блокируется браузером).
  // Прежние сервисы ipapi.co и ipinfo.io отвечали 403 и 429 - из-за этого
  // колонка «Страна» оставалась с прочерками.
  const GEOIP_SERVICES = [
    'https://ipwho.is/{ip}',
    'https://api.country.is/{ip}',
    'https://freeipapi.com/api/json/{ip}',
    'https://ip2c.org/{ip}',
  ];

  // IP-echo сервисы для определения страны выхода (запрос ЧЕРЕЗ прокси).
  const IP_ECHO_SERVICES = [
    'https://api.ipify.org?format=json',
    'https://ipwho.is/',
    'https://ipinfo.io/json',
  ];

  const DEFAULT_SETTINGS = {
    enabled: true,
    // Общий протокол для всех прокси из списка.
    proxyProtocol: 'socks5',
    // Авто-тестирование прокси в фоне. По умолчанию выключено: проверка
    // запускается вручную кнопкой «Проверить все». Расписание (точное время
    // или интервал) включается пользователем отдельно.
    autoTestEnabled: false,
    // Точное время авто-тестирования: массив строк «HH:MM». Интервалов может
    // быть несколько (например ['09:00', '15:30', '21:00']). Пустой список -
    // расписание не задано, авто-тест по таймеру не запускается.
    autoTestTimes: [],
    // Устаревшая настройка (периодический интервал в минутах). Оставлена для
    // совместимости со старыми сохранениями, в интерфейсе не используется.
    autoTestInterval: 15,
    // Удалять нерабочие прокси автоматически.
    autoDeleteDead: true,
    // Удалять недоступные прокси после АВТО-теста (запуск по расписанию).
    autoTestDeleteDead: true,
    // Удалять ограниченные прокси: те, что не открыли тестовый сайт.
    // По умолчанию включено: такие прокси занимают место в списке, а работать
    // через них нельзя. Настройка действует на любую проверку списка.
    autoTestDeleteLimited: true,
    // Удалять непроверенные прокси, оставшиеся после прерванного авто-теста.
    // Список пополняется из источников перед проверкой, и если прогон не дожил
    // до конца (Chrome выгрузил service worker, браузер закрыли), дозалитые
    // прокси висят со статусом «не проверено». По умолчанию включено.
    autoTestDeleteUntested: true,
    // Дозаливать новые прокси после авто-теста по настройкам раздела
    // «Свой прокси»: источники, лимит прокси, фильтр стран.
    autoTestRefill: true,
    // Отключаться от нерабочих: если сайт из списка не открылся при открытии
    // вкладки или обновлении страницы, активный прокси помечается
    // «ограниченным» и включается следующий рабочий прокси. Проверка идёт
    // только по этим событиям, поэтому настройка не зависит от авто-теста.
    // По умолчанию включено: прокси меняется на рабочий без участия человека.
    disableOnDeadProxy: true,
    // Ручной выбор прокси из UI. Пока этот прокси есть в списке и не признан
    // недоступным проверкой, авто-выбор его не перебивает.
    manualProxyId: '',
    // Тестовая цель: google | cloudflare | amazon | azure.
    testTarget: 'google',
    // Тестовый URL для проверки прокси (пинг прокси).
    testUrl: 'https://www.google.com/generate_204',
    // URL тестового сайта (второй пинг - время открытия сайта).
    siteTestUrl: 'https://www.google.com/',
    // Таймаут проверки одного прокси, мс. Медленные публичные прокси
    // (2-5 секунд на запрос) при 8 секундах часто не успевали ответить.
    testTimeout: 12000,
    // Максимум одновременных проверок.
    testConcurrency: 8,
    // Проксировать весь трафик (а не только сайты из списка).
    proxyAllTraffic: false,
    // Лимит РАБОЧИХ прокси в списке (0 - без лимита). По нему считается дозаливка
    // из источников: и при загрузке вручную, и во время авто-теста. Нерабочие и
    // непроверенные в лимит не считаются: иначе список, забитый мусором,
    // перекрывал бы дозаливку.
    sourcesLimit: 50,
    // Качать списки через активный прокси.
    sourcesUseProxy: false,
    // Фильтр по странам: off | block | allow. Поведение как в версии 1.0:
    // по умолчанию включено удаление прокси из перечисленных ниже стран.
    countryFilterMode: 'block',
    // Список стран для фильтра (ISO-коды). Это стартовый набор, который
    // задаёт пользователь: список можно изменить, расширить или очистить
    // прямо в настройках (раздел «Фильтр прокси по странам»).
    countryFilterList: [
      'RU',
      'BY',
      'IR',
      'CN',
      'HK',
      'MO',
      'KP',
      'CU',
      'SY',
      'AF',
      'VE',
      'LY',
      'SD',
      'SS',
      'SO',
      'YE',
      'ER',
      'BI',
      'CF',
    ],
    // Удалять также прокси с неизвестной страной.
    countryFilterUnknown: false,
    // Применять фильтр автоматически: после загрузки источников, а в режиме
    // по стране выхода - по завершении проверки прокси.
    countryFilterAuto: true,
    // Порог неудач для кнопки «Удалить неудачные» в «Хранилище прокси»: записи
    // с таким числом неудачных проверок и больше удаляются по нажатию кнопки.
    // 0 - не удалять. Само расширение это не делает: удаление запускает
    // пользователь.
    archiveFailLimit: 3,
    // База фильтра: proxy - страна размещения прокси, exit - страна выхода.
    // По умолчанию учитывается страна выхода: именно её видят сайты.
    countryFilterBase: 'exit',
  };

  /**
   * Читает значение из chrome.storage.local.
   * @param {string} key
   * @param {*} fallback
   * @returns {Promise<*>}
   */
  async function getValue(key, fallback) {
    const result = await chrome.storage.local.get(key);
    return result[key] === undefined ? fallback : result[key];
  }

  /**
   * Записывает значение в chrome.storage.local.
   * @param {string} key
   * @param {*} value
   * @returns {Promise<void>}
   */
  async function setValue(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }

  /**
   * Возвращает список прокси.
   * @returns {Promise<Array<object>>}
   */
  async function getProxies() {
    return getValue(STORAGE_KEYS.PROXIES, []);
  }

  /**
   * Сохраняет список прокси.
   * @param {Array<object>} proxies
   * @returns {Promise<void>}
   */
  async function setProxies(proxies) {
    await setValue(STORAGE_KEYS.PROXIES, proxies);
  }

  /**
   * Возвращает список проксируемых сайтов (мой список).
   * @returns {Promise<Array<string>>}
   */
  async function getProxiedSites() {
    return getValue(STORAGE_KEYS.PROXIED_SITES, []);
  }

  /**
   * Сохраняет список проксируемых сайтов.
   * @param {Array<string>} sites
   * @returns {Promise<void>}
   */
  async function setProxiedSites(sites) {
    await setValue(STORAGE_KEYS.PROXIED_SITES, sites);
  }

  /**
   * Возвращает список источников прокси (URL-ов).
   * @returns {Promise<Array<string>>}
   */
  async function getProxySources() {
    return getValue(STORAGE_KEYS.PROXY_SOURCES, []);
  }

  /**
   * Сохраняет список источников прокси.
   * @param {Array<string>} sources
   * @returns {Promise<void>}
   */
  async function setProxySources(sources) {
    await setValue(STORAGE_KEYS.PROXY_SOURCES, sources);
  }

  /**
   * Возвращает настройки расширения, объединённые со значениями по умолчанию.
   * @returns {Promise<object>}
   */
  async function getSettings() {
    const stored = await getValue(STORAGE_KEYS.SETTINGS, {});
    return { ...DEFAULT_SETTINGS, ...stored };
  }

  /**
   * Сохраняет настройки расширения.
   * @param {object} settings
   * @returns {Promise<void>}
   */
  async function setSettings(settings) {
    await setValue(STORAGE_KEYS.SETTINGS, settings);
  }

  /**
   * Возвращает активный прокси (объект) или null.
   * @returns {Promise<object|null>}
   */
  async function getActiveProxy() {
    return getValue(STORAGE_KEYS.ACTIVE_PROXY, null);
  }

  /**
   * Сохраняет активный прокси.
   * @param {object|null} proxy
   * @returns {Promise<void>}
   */
  async function setActiveProxy(proxy) {
    await setValue(STORAGE_KEYS.ACTIVE_PROXY, proxy);
  }

  /**
   * Возвращает статистику проверок прокси: { "<id>": { alive, latency, checkedAt } }.
   * @returns {Promise<Object<string, object>>}
   */
  async function getProxyStats() {
    return getValue(STORAGE_KEYS.PROXY_STATS, {});
  }

  /**
   * Сохраняет статистику проверок прокси.
   * @param {Object<string, object>} stats
   * @returns {Promise<void>}
   */
  async function setProxyStats(stats) {
    await setValue(STORAGE_KEYS.PROXY_STATS, stats);
  }

  /**
   * Возвращает «Хранилище прокси»: { "<host>:<port>": { host, port, ... } }.
   *
   * Ключ - адрес прокси, поэтому запись живёт, даже когда сам прокси удалён из
   * списка проверкой: ради этого хранилище и нужно.
   *
   * @returns {Promise<Object<string, object>>}
   */
  async function getProxyArchive() {
    return getValue(STORAGE_KEYS.PROXY_ARCHIVE, {});
  }

  /**
   * Сохраняет «Хранилище прокси».
   * @param {Object<string, object>} archive
   * @returns {Promise<void>}
   */
  async function setProxyArchive(archive) {
    await setValue(STORAGE_KEYS.PROXY_ARCHIVE, archive);
  }

  /**
   * Запись «Хранилища прокси» считается рабочей, если прокси хотя бы раз
   * подтвердил работу - то есть есть удачные проверки.
   *
   * Такие записи добору не мешают: прокси может вернуться и снова заработать,
   * поэтому из источников его взять можно. «Другие» - записи без единой удачи:
   * именно их дозаливка пропускает, чтобы один и тот же мусор не тестировался
   * снова и снова.
   *
   * Правило согласовано с колонкой «Удачных» и с фильтром «Рабочие / Другие»:
   * ноль в этой колонке и есть запись в «Других». Раньше состояние считалось по
   * последней проверке, из-за чего записи с удачами, но свежим провалом,
   * попадали в «Другие» - это путало.
   *
   * @param {object} entry
   * @returns {boolean}
   */
  function isArchiveWorking(entry) {
    if (!entry) return false;
    return (Number(entry.okCount) || 0) > 0;
  }

  /**
   * Возвращает последнее уведомление о замене прокси (или null).
   * @returns {Promise<object|null>}
   */
  async function getProxyNotice() {
    return getValue(STORAGE_KEYS.PROXY_NOTICE, null);
  }

  /**
   * Сохраняет уведомление о замене прокси.
   * @param {object|null} notice
   * @returns {Promise<void>}
   */
  async function setProxyNotice(notice) {
    await setValue(STORAGE_KEYS.PROXY_NOTICE, notice);
  }

  /**
   * Возвращает журнал событий: записи идут от свежих к старым.
   * @returns {Promise<Array<object>>}
   */
  async function getJournal() {
    return getValue(STORAGE_KEYS.JOURNAL, []);
  }

  /**
   * Сохраняет журнал событий.
   * @param {Array<object>} entries
   * @returns {Promise<void>}
   */
  async function setJournal(entries) {
    await setValue(STORAGE_KEYS.JOURNAL, Array.isArray(entries) ? entries : []);
  }

  /**
   * Добавляет запись в журнал.
   *
   * Запись описывает одно действие расширения: автоматическую замену прокси,
   * удаление прокси после проверки, пропуск проверки. Недоступные прокси в
   * журнал не пишутся: такие события повторяются пачками и только засоряют
   * список.
   *
   * @param {{kind?: string, title?: string, text?: string, proxy?: string}} entry
   * @returns {Promise<void>}
   */
  async function addJournalEntry(entry) {
    const current = await getJournal();
    const list = [
      {
        at: Date.now(),
        kind: entry && entry.kind ? String(entry.kind) : 'info',
        title: entry && entry.title ? String(entry.title) : '',
        text: entry && entry.text ? String(entry.text) : '',
        proxy: entry && entry.proxy ? String(entry.proxy) : '',
      },
      ...(Array.isArray(current) ? current : []),
    ];
    if (list.length > JOURNAL_MAX_ENTRIES) list.length = JOURNAL_MAX_ENTRIES;
    await setJournal(list);
  }

  /**
   * Очищает журнал событий.
   * @returns {Promise<void>}
   */
  async function clearJournal() {
    await setJournal([]);
  }

  /**
   * Нормализует домен: убирает схему, путь, порт, www и приводит к нижнему регистру.
   * @param {string} input
   * @returns {string}
   */
  function normalizeDomain(input) {
    if (!input) return '';
    let value = String(input).trim().toLowerCase();
    if (!value) return '';
    // Убираем схему.
    value = value.replace(/^[a-z][a-z0-9+.-]*:\/\//, '');
    // Убираем учётные данные.
    value = value.replace(/^[^@/]*@/, '');
    // Убираем путь, параметры и якорь.
    value = value.split('/')[0].split('?')[0].split('#')[0];
    // Убираем порт.
    value = value.replace(/:\d+$/, '');
    // Убираем завершающую точку и www.
    value = value.replace(/\.$/, '');
    value = value.replace(/^www\./, '');
    return value;
  }

  /**
   * Проверяет, относится ли домен к правилу (сам домен или его поддомен).
   * @param {string} hostname
   * @param {string} ruleDomain
   * @returns {boolean}
   */
  function domainMatches(hostname, ruleDomain) {
    const host = normalizeDomain(hostname);
    const rule = normalizeDomain(ruleDomain);
    if (!host || !rule) return false;
    return host === rule || host.endsWith('.' + rule);
  }

  /**
   * Проверяет, входит ли домен в список проксируемых сайтов.
   * @param {string} hostname
   * @param {Array<string>} proxiedSites
   * @returns {boolean}
   */
  function isProxied(hostname, proxiedSites) {
    const host = normalizeDomain(hostname);
    if (!host) return false;
    for (const site of proxiedSites || []) {
      if (domainMatches(host, site)) return true;
    }
    return false;
  }

  /**
   * Генерирует уникальный идентификатор прокси.
   * @returns {string}
   */
  function generateProxyId() {
    return 'p_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  /**
   * Разбирает строку прокси в объект.
   *
   * Принимает простой формат `host:port` (основной), а также
   * `[user:pass@]host:port` и, для совместимости, со схемой впереди
   * (`socks5://host:port`) - схема при этом игнорируется, так как
   * протокол задаётся общим переключателем.
   *
   * @param {string} raw
   * @returns {object|null}
   */
  function parseProxyString(raw) {
    if (!raw) return null;
    let value = String(raw).trim();
    if (!value) return null;

    // Отбрасываем схему, если она указана.
    value = value.replace(/^[a-z][a-z0-9+.-]*:\/\//i, '');

    const match = value.match(/^(?:([^:@/]+)(?::([^@/]*))?@)?([^:/@\s]+):(\d+)$/);
    if (!match) return null;

    const [, username, password, host, port] = match;
    const portNumber = parseInt(port, 10);
    if (!host || !Number.isInteger(portNumber) || portNumber < 1 || portNumber > 65535) {
      return null;
    }

    return {
      host,
      port: portNumber,
      username: username || '',
      password: password || '',
    };
  }

  /**
   * Формирует строку прокси из объекта (без схемы).
   * @param {object} proxy
   * @returns {string}
   */
  function formatProxyString(proxy) {
    if (!proxy) return '';
    const auth = proxy.username
      ? `${proxy.username}${proxy.password ? ':' + proxy.password : ''}@`
      : '';
    return `${auth}${proxy.host}:${proxy.port}`;
  }

  /**
   * Разбирает многострочный текст со списком прокси.
   *
   * Поддерживает строки вида `host:port`, `user:pass@host:port`,
   * а также со схемой впереди. Игнорирует пустые строки и комментарии.
   *
   * @param {string} text
   * @returns {Array<object>}
   */
  function parseProxyList(text) {
    if (!text) return [];
    const result = [];
    const seen = new Set();

    const lines = String(text).split(/[\r\n,;]+/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#') || trimmed.startsWith('//')) continue;

      const parsed = parseProxyString(trimmed);
      if (!parsed) continue;

      const key = `${parsed.host}:${parsed.port}`;
      if (seen.has(key)) continue;
      seen.add(key);

      result.push(parsed);
    }
    return result;
  }

  /**
   * Удаляет дубликаты прокси по host:port.
   * @param {Array<object>} proxies
   * @returns {Array<object>}
   */
  function dedupeProxies(proxies) {
    const seen = new Set();
    const result = [];
    for (const proxy of proxies || []) {
      const key = `${proxy.host}:${proxy.port}`;
      if (seen.has(key)) continue;
      seen.add(key);
      result.push(proxy);
    }
    return result;
  }

  /**
   * Возвращает страну прокси по выбранной базе фильтра.
   *
   * @param {object} proxy
   * @param {object} settings
   * @param {object} [stat] статистика проверки прокси (нужна для страны выхода)
   * @returns {string} код страны или пустая строка
   */
  function getFilterCountry(proxy, settings, stat) {
    const base = settings && settings.countryFilterBase === 'exit' ? 'exit' : 'proxy';
    const raw = base === 'exit' ? stat && stat.exitCountry : proxy && proxy.country;
    return raw ? String(raw).toUpperCase() : '';
  }

  /**
   * Проверяет, подходит ли прокси под фильтр стран.
   *
   * База фильтра задаётся настройкой countryFilterBase: по стране размещения
   * прокси (proxy) или по стране выхода (exit). Страна выхода известна только
   * после проверки, поэтому в этом режиме фильтр применяется после неё.
   *
   * @param {object} proxy
   * @param {object} settings
   * @param {object} [stat] статистика проверки прокси
   * @returns {boolean} true, если прокси нужно оставить
   */
  function passesCountryFilter(proxy, settings, stat) {
    const mode = settings.countryFilterMode || 'off';
    if (mode === 'off') return true;

    const list = (settings.countryFilterList || []).map((c) => String(c).toUpperCase());
    if (!list.length) return true;

    const country = getFilterCountry(proxy, settings, stat);
    if (!country) {
      // Неизвестная страна: удаляем, если включена соответствующая опция.
      return !settings.countryFilterUnknown;
    }

    const inList = list.includes(country);
    return mode === 'allow' ? inList : !inList;
  }

  /**
   * Возвращает список уникальных стран из прокси по выбранной базе фильтра.
   *
   * @param {Array<object>} proxies
   * @param {Object<string, object>} [stats] статистика проверок по id прокси
   * @param {string} [base] proxy | exit
   * @returns {Array<string>}
   */
  function collectCountries(proxies, stats, base) {
    const set = new Set();
    const useExit = base === 'exit';
    for (const proxy of proxies || []) {
      const stat = useExit && stats ? stats[proxy.id] : null;
      const raw = useExit ? stat && stat.exitCountry : proxy.country;
      if (raw) set.add(String(raw).toUpperCase());
    }
    return Array.from(set).sort();
  }

  // Экспорт для service worker (importScripts) и для UI (window).
  const QProxyStorage = {
    STORAGE_KEYS,
    DEFAULT_SETTINGS,
    PROXY_PROTOCOLS,
    AI_SITES,
    TEST_TARGETS,
    GEOIP_SERVICES,
    IP_ECHO_SERVICES,
    getValue,
    setValue,
    getProxies,
    setProxies,
    getProxiedSites,
    setProxiedSites,
    getProxySources,
    setProxySources,
    getSettings,
    setSettings,
    getActiveProxy,
    setActiveProxy,
    getProxyStats,
    setProxyStats,
    getProxyArchive,
    setProxyArchive,
    isArchiveWorking,
    getProxyNotice,
    setProxyNotice,
    JOURNAL_MAX_ENTRIES,
    getJournal,
    setJournal,
    addJournalEntry,
    clearJournal,
    normalizeDomain,
    domainMatches,
    isProxied,
    generateProxyId,
    parseProxyString,
    formatProxyString,
    parseProxyList,
    dedupeProxies,
    passesCountryFilter,
    getFilterCountry,
    collectCountries,
  };

  if (typeof self !== 'undefined') {
    self.QProxyStorage = QProxyStorage;
  }
  if (typeof window !== 'undefined') {
    window.QProxyStorage = QProxyStorage;
  }
})();
