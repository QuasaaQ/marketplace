(() => {
  'use strict';

  const RATE_KEY = 'yenToRubRate';
  const MARKER_ATTR = 'data-yen-to-rub';
  const SCALE_ATTR = 'data-yen-to-rub-scale';
  const BLOCK_SCALE = 0.8;
  const DEFAULT_RATE = 13.7;

  let rate = DEFAULT_RATE;

  const fmtRub = (value) => {
    try {
      return new Intl.NumberFormat('ru-RU', {
        style: 'currency',
        currency: 'RUB',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(value);
    } catch {
      return '₽' + value.toFixed(2).replace('.', ',');
    }
  };

  const parseYen = (text) => {
    if (!text) return null;
    let m = text.match(/¥\s*([\d\s.,]+)/);
    if (!m) m = text.match(/([\d\s.,]+)\s*¥/);
    if (!m) return null;
    const num = parseFloat(m[1].replace(/[\s,]/g, ''));
    return Number.isFinite(num) && num > 0 ? num : null;
  };

  // Уменьшает шрифт блока и его элементов на 20%, чтобы рублёвая цена
  // помещалась в блок и не ломала вёрстку. Исходные размеры сохраняются
  // в атрибуте SCALE_ATTR, чтобы reset() мог вернуть всё как было.
  const scaleBlock = (elements) => {
    const unique = [];
    for (const el of elements) {
      if (el && !el.hasAttribute(SCALE_ATTR) && unique.indexOf(el) === -1) unique.push(el);
    }

    // Размеры считаем до изменений, иначе em-размеры уменьшатся дважды.
    const originals = unique.map((el) => parseFloat(getComputedStyle(el).fontSize));

    unique.forEach((el, i) => {
      const size = originals[i];
      if (!Number.isFinite(size) || size <= 0) return;
      el.setAttribute(SCALE_ATTR, String(size));
      el.style.fontSize = (size * BLOCK_SCALE).toFixed(2) + 'px';
    });
  };

  const restoreScale = () => {
    document.querySelectorAll(`[${SCALE_ATTR}]`).forEach((el) => {
      el.style.removeProperty('font-size');
      el.removeAttribute(SCALE_ATTR);
    });
  };

  const convert = () => {
    const nodes = document.querySelectorAll('span[data-usage-layout-font="value"]');
    for (const el of nodes) {
      if (el.hasAttribute(MARKER_ATTR)) continue;

      const yen = parseYen(el.textContent);
      if (yen === null) continue;

      // Контейнер с ценой и единицей измерения (CNY): в него вставляем цену справа
      const container = el.parentElement;
      const unit = container
        ? container.querySelector('[data-usage-layout-font="unit"]')
        : null;
      const anchor = unit || el;

      const price = document.createElement('span');
      price.className = 'yen-to-rub-price';
      price.setAttribute(MARKER_ATTR, '1');
      price.textContent = fmtRub(yen * rate);
      anchor.insertAdjacentElement('afterend', price);

      el.setAttribute(MARKER_ATTR, '1');

      // Шрифт блока уменьшаем на 20%, чтобы рублёвая цена помещалась
      scaleBlock([container, el, unit]);
    }
  };

  const reset = () => {
    document.querySelectorAll('.yen-to-rub-price').forEach((e) => e.remove());
    document.querySelectorAll(`[${MARKER_ATTR}]`).forEach((e) => e.removeAttribute(MARKER_ATTR));
    restoreScale();
    convert();
  };

  const style = document.createElement('style');
  style.textContent = `
    .yen-to-rub-price {
      margin-left: 6px;
      color: #9b1c1c;
      font-weight: 500;
      white-space: nowrap;
    }
  `;
  document.head.appendChild(style);

  const observer = new MutationObserver(() => convert());
  observer.observe(document.body, { childList: true, subtree: true });

  const init = async () => {
    const data = await chrome.storage.sync.get(RATE_KEY);
    const v = parseFloat(data[RATE_KEY]);
    if (Number.isFinite(v) && v > 0) rate = v;
    convert();
  };

  init();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes[RATE_KEY]) {
      const v = parseFloat(changes[RATE_KEY].newValue);
      if (Number.isFinite(v) && v > 0) rate = v;
      reset();
    }
  });
})();
